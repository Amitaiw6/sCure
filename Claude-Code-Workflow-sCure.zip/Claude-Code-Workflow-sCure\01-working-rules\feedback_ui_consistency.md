---
name: feedback_ui_consistency
description: Keep a consistent visual language across the whole app; titles are white, not blue
metadata:
  type: feedback
---

The user wants a **consistent visual language across the entire app** — don't let individual screens drift in styling.

Concrete rule established so far: **modal/page titles must be white** (the default `DialogTitle` color, which inherits `text-popover-foreground`), NOT `text-primary` (blue). Most titles already follow this (Import from CSV, Abort Cure Process?, Static IP Configuration); `CsvBuilderModal` ("Build Cure Program") and `StepModal` ("Add/Edit Step") were the blue outliers and were corrected.

**Why:** the user explicitly asked to keep a uniform language throughout the app and flagged the blue title as inconsistent.

**How to apply:** when adding/editing any screen, match the established patterns (white titles, shared component styles) rather than introducing new colors/styles. `text-primary` blue is for accents (e.g. small "Step N" labels), not for titles. When in doubt, mirror an existing screen.

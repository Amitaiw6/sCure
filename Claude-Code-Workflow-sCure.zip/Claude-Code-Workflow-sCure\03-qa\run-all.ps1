<#
.SYNOPSIS
  Full sCureBox QA: build, unit + integration tests, then the headless API QA against a live simulated server.

.DESCRIPTION
  1. dotnet build SCureBox.sln (warnings are errors)
  2. dotnet test for the four test projects (Domain, Hardware, Application, Api) — a hung test host is
     aborted after -HangTimeout (default 3 min) and counts as FAIL instead of blocking the pipeline
  3. start src/SCureBox.Api in simulation (SCURE_SIMULATE=1) on a free port with a temp data dir
  4. wait for /api/state, run  node qa/run-qa.mjs --api http://127.0.0.1:<port>
  5. stop the server, print PASS/FAIL and exit 0/1

.PARAMETER Port
  Port for the QA server (default 3111).
.PARAMETER SkipBuild
  Reuse the existing build output.
.PARAMETER SkipTests
  Skip dotnet test (only the live QA).
.PARAMETER HangTimeout
  Per test project hang timeout (dotnet test --blame-hang-timeout), default "3m".
.PARAMETER SkipUi
  Skip the native UI stage (scurebox-ui window + native_ui QA category).
.PARAMETER ExcludeTests
  Test project names to skip, e.g. -ExcludeTests SCureBox.Application.Tests (the skip is listed in the summary).
#>
[CmdletBinding()]
param(
    [int]$Port = 3111,
    [switch]$SkipBuild,
    [switch]$SkipTests,
    [string]$HangTimeout = '3m',
    [string[]]$ExcludeTests = @(),
    [switch]$SkipUi
)

$ErrorActionPreference = 'Continue'
$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
$env:DOTNET_NOLOGO = '1'

$repo = Split-Path -Parent $PSScriptRoot
$dotnet = Join-Path $env:LOCALAPPDATA 'Microsoft\dotnet\dotnet.exe'
if (-not (Test-Path $dotnet)) { $dotnet = 'dotnet' }
$summary = New-Object System.Collections.Specialized.OrderedDictionary
$overall = $true

function Banner([string]$name) {
    Write-Host ''
    Write-Host ('=' * 70)
    Write-Host "  $name"
    Write-Host ('=' * 70)
}

# Run a native command as one pipeline step; PASS when its exit code is 0.
function Step([string]$name, [string]$exe, [string[]]$arguments) {
    Banner $name
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    & $exe @arguments
    $code = $LASTEXITCODE
    $sw.Stop()
    $ok = ($code -eq 0)
    $secs = [int]$sw.Elapsed.TotalSeconds
    $script:summary[$name] = if ($ok) { "PASS ($secs s)" } else { "FAIL exit $code ($secs s)" }
    if (-not $ok) { $script:overall = $false }
    return $ok
}

# --- 1. build -------------------------------------------------------------
if (-not $SkipBuild) {
    $built = Step 'Build SCureBox.sln' $dotnet @('build', (Join-Path $repo 'SCureBox.sln'), '-nologo', '-v', 'q')
    if (-not $built) { Write-Host 'Build failed - stopping.' -ForegroundColor Red; exit 1 }
}

# --- 2. tests -------------------------------------------------------------
if (-not $SkipTests) {
    foreach ($proj in 'SCureBox.Domain.Tests', 'SCureBox.Hardware.Tests', 'SCureBox.Application.Tests', 'SCureBox.Api.Tests') {
        if ($ExcludeTests -contains $proj) { $summary["dotnet test $proj"] = 'SKIPPED (-ExcludeTests)'; continue }
        $path = Join-Path $repo "tests\$proj\$proj.csproj"
        [void](Step "dotnet test $proj" $dotnet @('test', $path, '-nologo', '-v', 'q', '--no-build', '--blame-hang', '--blame-hang-timeout', $HangTimeout))
    }
}

# --- 3. live server in simulation ---------------------------------------
$apiDll = Join-Path $repo 'src\SCureBox.Api\bin\Debug\net8.0\scurebox.dll'
if (-not (Test-Path $apiDll)) { Write-Host "API build output not found: $apiDll" -ForegroundColor Red; exit 1 }
$dataDir = Join-Path ([System.IO.Path]::GetTempPath()) ('scurebox-qa-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force $dataDir | Out-Null
$logFile = Join-Path $dataDir 'server.log'
$errFile = Join-Path $dataDir 'server.err.log'

$env:SCURE_SIMULATE = '1'
$env:SCURE_SIM_TC08 = '1'
$env:SCURE_DATA_DIR = $dataDir
$env:SCURE_UI_DIR = Join-Path $repo 'ui\dist'
$env:PORT = "$Port"
$env:ASPNETCORE_URLS = ''
$env:DOTNET_ROOT = Split-Path -Parent $dotnet

Banner "Live QA server on port $Port (simulation, data $dataDir)"
$server = Start-Process -FilePath $dotnet -ArgumentList @($apiDll) -WorkingDirectory (Split-Path -Parent $apiDll) -PassThru -NoNewWindow -RedirectStandardOutput $logFile -RedirectStandardError $errFile

$apiUrl = "http://127.0.0.1:$Port"
$ready = $false
$probe = New-Object System.Net.WebClient
for ($i = 0; $i -lt 180; $i++) {
    Start-Sleep -Milliseconds 500
    if ($server.HasExited) { break }
    try {
        $body = $probe.DownloadString("$apiUrl/api/state")
        if ($body -like '*"hwSource"*') { $ready = $true; break }
    } catch { }
}

if (-not $ready) {
    Write-Host 'Server did not answer /api/state within 90 s' -ForegroundColor Red
    if (Test-Path $logFile) { Get-Content $logFile -Tail 30 }
    if (Test-Path $errFile) { Get-Content $errFile -Tail 30 }
    $summary['Headless QA (run-qa.mjs)'] = 'FAIL (server not ready)'
    $overall = $false
} else {
    Write-Host "server ready after $([int]($i * 0.5)) s"
    $jsonOut = Join-Path $dataDir 'qa-report.json'
    [void](Step 'Headless QA (run-qa.mjs)' 'node' @((Join-Path $PSScriptRoot 'run-qa.mjs'), '--api', $apiUrl, '--json', $jsonOut))
    if (Test-Path $jsonOut) { Copy-Item $jsonOut (Join-Path $PSScriptRoot 'last-qa-report.json') -Force }
}

# --- 4. stop the server ---------------------------------------------------
if (-not $server.HasExited) {
    Stop-Process -Id $server.Id -Force -Confirm:$false
    $server.WaitForExit(5000) | Out-Null
}
if (Test-Path $errFile) {
    $err = Get-Content $errFile -ErrorAction SilentlyContinue
    if ($err) { Write-Host 'server stderr:' -ForegroundColor Yellow; $err | Select-Object -Last 20 }
}
try { Remove-Item -Recurse -Force $dataDir -ErrorAction Stop } catch { }


# --- 5. native UI host (Step B): scurebox-ui in a desktop window, the native_ui QA category ----
$uiDll = Join-Path $repo 'src\SCureBox.Ui\bin\Debug\net8.0\scurebox-ui.dll'
if (-not $SkipUi -and (Test-Path $uiDll)) {
    Banner 'Native UI QA (scurebox-ui + run-qa.mjs --category native_ui)'
    $uiPort = $Port + 1
    $uiData = Join-Path ([System.IO.Path]::GetTempPath()) ('scurebox-uiqa-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Force -Path $uiData | Out-Null
    $env:SCURE_SIMULATE = '1'; $env:SCURE_SIM_TC08 = '1'; $env:SCURE_UI_WINDOW = '1'; $env:PORT = "$uiPort"; $env:SCURE_DATA_DIR = $uiData
    $uiLog = Join-Path $uiData 'ui.log'; $uiErr = Join-Path $uiData 'ui.err'
    $ui = Start-Process -FilePath $dotnet -ArgumentList @($uiDll) -WorkingDirectory (Split-Path -Parent $uiDll) -PassThru -NoNewWindow -RedirectStandardOutput $uiLog -RedirectStandardError $uiErr
    $uiUrl = "http://127.0.0.1:$uiPort"
    $uiReady = $false
    for ($i = 0; $i -lt 240; $i++) {
        Start-Sleep -Milliseconds 500
        if ($ui.HasExited) { break }
        try { $body = $probe.DownloadString("$uiUrl/api/ui/route"); if ($body -like '*"route"*') { $uiReady = $true; break } } catch { }
    }
    if (-not $uiReady) {
        Write-Host 'Native UI did not answer /api/ui/route within 120 s' -ForegroundColor Red
        if (Test-Path $uiErr) { Get-Content $uiErr -Tail 30 }
        $summary['Native UI QA'] = 'FAIL (ui not ready)'; $overall = $false
    } else {
        Start-Sleep -Seconds 8   # boot screen
        [void](Step 'Native UI QA' 'node' @((Join-Path $PSScriptRoot 'run-qa.mjs'), '--api', $uiUrl, '--category', 'native_ui'))
    }
    if (-not $ui.HasExited) { Stop-Process -Id $ui.Id -Force -Confirm:$false; $ui.WaitForExit(5000) | Out-Null }
    Remove-Item $uiData -Recurse -Force -ErrorAction SilentlyContinue
} elseif (-not $SkipUi) {
    $summary['Native UI QA'] = 'SKIP (scurebox-ui not built)'
}

# --- 5. summary -----------------------------------------------------------
Banner 'sCureBox QA summary'
foreach ($k in $summary.Keys) {
    $color = if ($summary[$k] -like 'PASS*') { 'Green' } elseif ($summary[$k] -like 'SKIPPED*') { 'Yellow' } else { 'Red' }
    Write-Host ('  {0,-40} {1}' -f $k, $summary[$k]) -ForegroundColor $color
}
Write-Host ''
if ($overall) { Write-Host '  OVERALL: PASS' -ForegroundColor Green; exit 0 }
else { Write-Host '  OVERALL: FAIL' -ForegroundColor Red; exit 1 }

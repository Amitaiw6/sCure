/*
 * sCureBox QA test table — shared by the browser tool (qa-tool.html) and the headless runner (run-qa.mjs).
 * Plain script, no dependencies: defines globalThis.SCURE_QA = { CATEGORIES, CHECKS, runTest }.
 *
 * Record shape (same as the original sCure QA tool):
 *   { id, name, desc, endpoint, method, body, expect | expectArray | check, code?, url? }
 *   expect: 'ok'      → response.ok === true
 *   expect: '<field>' → response[field] !== undefined
 *   expectArray: true → response is an array
 *   check: '<name>'   → CHECKS[name](ctx, test, response) decides (status pass|fail|warn|skip, msg)
 *   url: '/config/x'  → fetched from the API origin without the /api prefix (static asset)
 *
 * ctx = { apiUrl, fetch, timeoutMs }
 */
(function (root) {
  'use strict';

  const RUN_ID = 'qa-test-run';
  const RECIPE_RUN_ID = 'qa-recipe-run';
  const STATE_KEYS = [
    'chamberTemp', 'targetTemp', 'internetOk', 'doorClosed', 'doorAborted', 'isHeating', 'isCooling', 'coolingMode',
    'uvOn', 'uvIntensity', 'uvWavelength', 'uvOutputs', 'ventOn', 'damperOpen', 'damperDriver', 'fans', 'fanRpm',
    'fanRpmEach', 'fanOverride', 'stripMode', 'uiAlerts', 'ledTemps', 'nitrogenActive', 'n2Pressure', 'n2LinePressure',
    'bofaOn', 'atTemp', 'heaterPwm', 'heaterOut', 'coolingRate', 'coolingFanPwm', 'faults', 'sensors', 'fanHealth',
    'ledHealth', 'ledChecksEnabled', 'alerts', 'alertDetails', 'hwSource', 'counters', 'cloudSync', 'nfcEnabled', 'nfcReader', 'recipe',
  ];
  const FANS = ['FAN_HEATER', 'FAN_DOOR', 'FAN_RIGHT', 'FAN_LEFT', 'FAN_BACK', 'FAN_COOLING'];

  // ------------------------------------------------------------------ helpers
  const pass = (msg) => ({ status: 'pass', msg });
  const fail = (msg) => ({ status: 'fail', msg });
  const warn = (msg) => ({ status: 'warn', msg });
  const skip = (msg) => ({ status: 'skip', msg });
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const short = (v, n = 60) => { const s = typeof v === 'string' ? v : JSON.stringify(v); return s && s.length > n ? s.slice(0, n) + '…' : s; };
  const hasKeys = (obj, keys) => keys.filter((k) => !obj || !Object.prototype.hasOwnProperty.call(obj, k));

  async function call(ctx, path, opts = {}) {
    const url = (opts.absolute ? '' : ctx.apiUrl) + path;
    const init = { method: opts.method || 'GET', signal: AbortSignal.timeout(opts.timeout || ctx.timeoutMs || 10000) };
    if (opts.body !== undefined) {
      init.headers = { 'Content-Type': 'application/json' };
      init.body = JSON.stringify(opts.body);
    }
    const res = await ctx.fetch(url, init);
    const text = await res.text();
    let data = null;
    try { data = text.length ? JSON.parse(text) : null; } catch (e) { data = null; }
    return { status: res.status, data, text, contentType: res.headers.get('content-type') || '' };
  }
  const get = (ctx, path, o) => call(ctx, path, Object.assign({ method: 'GET' }, o));
  const post = (ctx, path, body, o) => call(ctx, path, Object.assign({ method: 'POST', body }, o));
  const state = async (ctx) => (await get(ctx, '/api/state')).data;

  async function waitState(ctx, predicate, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    let s = await state(ctx);
    while (!predicate(s) && Date.now() < deadline) { await sleep(300); s = await state(ctx); }
    return s;
  }

  async function isSimulation(ctx) { const s = await state(ctx); return s && s.hwSource === 'simulation'; }
  async function isWindowsHost(ctx) { const v = (await get(ctx, '/api/system/version')).data; return !!(v && v.os && /windows/i.test(v.os)); }

  function envelope(res, expectedCode) {
    const d = res.data;
    if (!d || typeof d.ok !== 'boolean') return fail('no {ok} envelope: ' + short(res.text));
    if (d.ok) return fail('accepted but expected a refusal: ' + short(res.text));
    if (expectedCode !== undefined && d.code !== expectedCode) return fail(`code ${d.code} (expected ${expectedCode}): ${d.message}`);
    return pass(`${d.code !== undefined ? d.code + ' ' : ''}${d.message}`);
  }

  // ------------------------------------------------------------------ checks
  const CHECKS = {
    async not_found_json(ctx) {
      const r = await get(ctx, '/api/no-such-route-qa');
      if (r.status !== 404) return fail(`HTTP ${r.status} (expected 404)`);
      if (!r.data || r.data.ok !== false) return fail('404 body is not {ok:false}: ' + short(r.text));
      return pass('404 ' + r.data.message);
    },
    state_keys(ctx, test, res) {
      const missing = hasKeys(res.data, STATE_KEYS);
      return missing.length ? fail('missing: ' + missing.join(', ')) : pass(`all ${STATE_KEYS.length} keys present (hwSource=${res.data.hwSource})`);
    },
    async state_nested(ctx, test, res) {
      // sensors / fanHealth / ledHealth are filled by the 1 Hz supervision tick — wait for the first one after boot
      const s = res.data && res.data.sensors && res.data.sensors.chamber ? res.data : await waitState(ctx, (x) => x && x.sensors && x.sensors.chamber, 5000);
      const problems = [];
      ['led_cooling', 'chamber_intake', 'chamber_heating'].forEach((g) => { if (!s.fans || s.fans[g] === undefined) problems.push('fans.' + g); if (!s.fanRpm || s.fanRpm[g] === undefined) problems.push('fanRpm.' + g); });
      FANS.forEach((f) => { if (!s.fanRpmEach || s.fanRpmEach[f] === undefined) problems.push('fanRpmEach.' + f); });
      ['left', 'right', 'back', 'door', 'left2', 'right2'].forEach((z) => { if (!s.ledTemps || s.ledTemps[z] === undefined) problems.push('ledTemps.' + z); });
      ['heater', 'cooling', 'led'].forEach((k) => { if (!s.faults || s.faults[k] === undefined) problems.push('faults.' + k); });
      ['led405', 'led450', 'coolingFan', 'heater', 'heaterFan'].forEach((k) => { if (!s.counters || s.counters[k] === undefined) problems.push('counters.' + k); });
      ['enabled', 'lastSyncOk', 'error'].forEach((k) => { if (!s.cloudSync || s.cloudSync[k] === undefined) problems.push('cloudSync.' + k); });
      ['detected', 'port', 'model', 'serial', 'usbId', 'seenSinceBoot'].forEach((k) => { if (!s.nfcReader || s.nfcReader[k] === undefined) problems.push('nfcReader.' + k); });
      if (!Array.isArray(s.alerts)) problems.push('alerts[]');
      if (!s.alertDetails || typeof s.alertDetails !== 'object') problems.push('alertDetails{}');
      ['chamber', 'left', 'right', 'back', 'door'].forEach((k) => { const v = s.sensors && s.sensors[k]; if (!v) problems.push('sensors.' + k); else ['sensor', 'ok', 'openSec', 'critical'].forEach((f) => { if (v[f] === undefined) problems.push(`sensors.${k}.${f}`); }); });
      FANS.forEach((f) => { const v = s.fanHealth && s.fanHealth[f]; if (!v) problems.push('fanHealth.' + f); else if (!['idle', 'ok', 'warn', 'critical', 'warn-pending', 'critical-pending', 'overridden'].includes(v.status)) problems.push(`fanHealth.${f}.status=${v.status}`); });
      ['LED_LEFT', 'LED_RIGHT'].forEach((l) => { const v = s.ledHealth && s.ledHealth[l]; if (!v) problems.push('ledHealth.' + l); else if (!['off', 'low', 'warming', 'ok', 'fail', 'drop', 'no-sensor'].includes(v.status)) problems.push(`ledHealth.${l}.status=${v.status}`); });
      return problems.length ? fail(problems.join(', ')) : pass('nested shapes OK');
    },
    async state_sim(ctx, test, res) {
      const s = res.data;
      if (s.hwSource !== 'simulation') return skip('real IO board (hwSource=' + s.hwSource + ')');
      const p = s.n2Pressure || {};
      if (s.n2LinePressure !== 6 || p.mpa !== 0.6 || p.bar !== 6 || p.mode !== 'analog_voltage') return fail('simulation N2 values: ' + short(s.n2Pressure));
      return pass('n2LinePressure 6.0, n2Pressure 0.6 MPa analog_voltage');
    },
    async heating_on(ctx) {
      const s = await waitState(ctx, (x) => x && x.isHeating, 4000);
      return s.isHeating ? pass(`isHeating, target ${s.targetTemp}°C, chamber ${s.chamberTemp}°C`) : fail('isHeating stayed false');
    },
    async uv_on_405(ctx) {
      const s = await waitState(ctx, (x) => x && x.uvOn, 4000);
      return s.uvOn && s.uvWavelength === 405 ? pass(`uvOn @ ${s.uvIntensity}% 405 nm, outputs ${short(s.uvOutputs)}`) : fail(`uvOn=${s.uvOn} wavelength=${s.uvWavelength}`);
    },
    async cooling_on(ctx) {
      const s = await waitState(ctx, (x) => x && x.isCooling, 4000);
      return s.isCooling ? pass(`isCooling (${s.coolingMode}), fan pwm ${s.coolingFanPwm}`) : fail('isCooling stayed false');
    },
    async all_off(ctx) {
      const s = await waitState(ctx, (x) => x && !x.isHeating && !x.isCooling && !x.uvOn && !x.nitrogenActive, 4000);
      const off = !s.isHeating && !s.isCooling && !s.uvOn && !s.nitrogenActive;
      return off ? pass('heater, cooling, UV and N2 all off') : fail(`isHeating=${s.isHeating} isCooling=${s.isCooling} uvOn=${s.uvOn} n2=${s.nitrogenActive}`);
    },
    reject(ctx, test, res) { return envelope(res, test.code); },
    reject_nocode(ctx, test, res) {
      const d = res.data;
      if (!d || d.ok !== false) return fail('expected {ok:false}: ' + short(res.text));
      if (d.code !== undefined) return fail(`unexpected code ${d.code}`);
      return pass(d.message);
    },
    stop_message(ctx, test, res) {
      const d = res.data;
      return d && d.ok === true && /All cure outputs stopped/.test(d.message || '') ? pass(d.message) : fail(short(res.text));
    },
    async fan_duty(ctx) {
      const s = await waitState(ctx, (x) => x && x.fans && x.fans.chamber_intake === 40, 3000);
      const duty = s.fans && s.fans.chamber_intake;
      await post(ctx, '/api/fans/chamber_intake?speed=0');
      return duty === 40 ? pass(`fans.chamber_intake = 40 %, rpm ${s.fanRpm && s.fanRpm.chamber_intake}`) : warn(`duty ${duty} (a loop may own the intake fan)`);
    },
    override_unknown(ctx, test, res) {
      const d = res.data;
      return d && d.ok === false && /unknown fan/.test(d.message || '') ? pass(d.message) : fail(short(res.text));
    },
    envelope_ok(ctx, test, res) {
      const d = res.data;
      return d && typeof d.ok === 'boolean' && 'message' in d ? (d.ok ? pass(d.message || 'ok') : warn(d.message)) : fail(short(res.text));
    },
    async door_cycle(ctx) {
      const sim = await isSimulation(ctx);
      const r = await post(ctx, '/api/door/open');
      if (!r.data || r.data.ok !== true || r.data.message !== 'Door opened') return fail('door/open: ' + short(r.text));
      const opened = await waitState(ctx, (x) => x && x.doorClosed === false, 3000);
      if (opened.doorClosed !== false) return sim ? fail('doorClosed did not read false after door/open') : warn('door did not read open (magnet released, door still closed?)');
      if (!sim) return pass('door reads open — close it to continue');
      const closed = await waitState(ctx, (x) => x && x.doorClosed === true, 8000);
      return closed.doorClosed === true ? pass('door read open, re-closed within 5 s (simulation)') : fail('door did not re-close within 8 s');
    },
    fan_test_shape(ctx, test, res) {
      const d = res.data;
      if (!d || d.ok !== true) return fail(short(res.text));
      const missing = hasKeys(d, ['rpm', 'status', 'fans', 'message']);
      if (missing.length) return fail('missing ' + missing.join(', '));
      const fans = FANS.filter((f) => !d.fans[f] || d.fans[f].rpm === undefined || !d.fans[f].status);
      if (fans.length) return fail('fans missing/incomplete: ' + fans.join(', '));
      if (d.status !== 'OK') return warn(`status ${d.status}: ${d.message}`);
      return pass(`${d.status}, worst ${d.rpm} rpm`);
    },
    fan_test_unknown(ctx, test, res) {
      const d = res.data;
      return d && d.ok === true && d.status === 'FAIL' && d.rpm === 0 && /unknown fan/.test(d.message || '') ? pass(d.message) : fail(short(res.text));
    },
    led_test_shape(ctx, test, res) {
      const d = res.data;
      if (!d || d.ok !== true) return fail(short(res.text));
      const missing = hasKeys(d, ['status', 'stage', 'seconds', 'wavelength', 'precooled', 'intensity', 'min_rise_c', 'results', 'message']);
      if (missing.length) return fail('missing ' + missing.join(', '));
      if (!Array.isArray(d.results)) return fail('results is not an array');
      const bad = d.results.filter((e) => hasKeys(e, ['name', 'start', 'temp', 'rise', 'status']).length);
      if (bad.length) return fail('result entries incomplete');
      return d.status === 'OK' ? pass(`OK (${d.stage}, ${d.results.length} sensors)`) : warn(`${d.status} at stage ${d.stage}: ${d.message}`);
    },
    async materials_roundtrip(ctx) {
      const before = (await get(ctx, '/api/materials/user')).data;
      if (!Array.isArray(before)) return fail('GET user materials is not an array');
      const mat = { id: 'qa-material', name: 'QA Material', isPreset: false, createdAt: new Date().toISOString(), totalDuration: 20,
        steps: [{ step: 1, process: 'Heating', temperature: 50, intensity: null, time: 10 }, { step: 2, process: 'Cooling', temperature: 30, intensity: null, time: 0, coolingMode: 'medium' }] };
      const saved = await post(ctx, '/api/materials/user', before.concat([mat]));
      if (!saved.data || saved.data.ok !== true) return fail('POST failed: ' + short(saved.text));
      const after = (await get(ctx, '/api/materials/user')).data;
      const found = Array.isArray(after) && after.some((m) => m.id === 'qa-material' && m.steps && m.steps[1].coolingMode === 'medium');
      const restored = await post(ctx, '/api/materials/user', before);
      if (!found) return fail('saved material not returned by GET');
      return restored.data && restored.data.ok ? pass(`saved + read back (${after.length} programs), list restored`) : warn('read back OK but restore failed');
    },
    async print_roundtrip(ctx) {
      const before = (await get(ctx, '/api/print-history')).data;
      if (!Array.isArray(before)) return fail('GET print history is not an array');
      const rec = { id: 'qa-print', printName: 'QA print', materialName: 'ST45', printerName: 'QA', date: new Date().toISOString(), duration: 120, status: 'completed', steps: 3, csvFile: 'qa.csv' };
      const saved = await post(ctx, '/api/print-history', [rec].concat(before));
      if (!saved.data || saved.data.ok !== true) return fail('POST failed: ' + short(saved.text));
      const after = (await get(ctx, '/api/print-history')).data;
      const found = Array.isArray(after) && after.some((p) => p.id === 'qa-print' && p.duration === 120);
      await post(ctx, '/api/print-history', before);
      return found ? pass('saved + read back, list restored') : fail('saved print not returned by GET');
    },
    async cure_run_roundtrip(ctx) {
      const start = await post(ctx, `/api/cure-runs/${RUN_ID}/start`, { materialName: 'QA', steps: 2, phases: ['Heating', 'Cooling'], targetTemp: 50, serialNumber: 'QA-SN' });
      if (!start.data || start.data.ok !== true) return fail('start: ' + short(start.text));
      const tel = await post(ctx, `/api/cure-runs/${RUN_ID}/telemetry`, { t: 0, chamberTemp: 24.5, uvOn: false, uvType: null, fanRpm: { FAN_HEATER: 0 }, ledTemps: { right: 25, left: 25, door: 25, back: 25 } });
      if (!tel.data || tel.data.ok !== true) return fail('telemetry: ' + short(tel.text));
      const unknown = await post(ctx, '/api/cure-runs/qa-no-such-run/telemetry', { t: 5, chamberTemp: 24, uvOn: false });
      if (!unknown.data || unknown.data.ok !== false) return fail('telemetry for an unknown run should be {ok:false}');
      const fin = await post(ctx, `/api/cure-runs/${RUN_ID}/finish`, { status: 'completed', stepsCompleted: 2 });
      if (!fin.data || fin.data.ok !== true || !Array.isArray(fin.data.sensorIssues) || !Array.isArray(fin.data.fanIssues)) return fail('finish: ' + short(fin.text));
      const hist = (await get(ctx, '/api/cure-history')).data;
      const run = Array.isArray(hist) && hist.find((r) => r.id === RUN_ID);
      if (!run) return fail('run missing from cure-history');
      if (run.status !== 'completed' || run.stepsCompleted !== 2) return fail(`history status ${run.status}, stepsCompleted ${run.stepsCompleted}`);
      const missing = hasKeys(run, ['materialName', 'steps', 'startedAt', 'endedAt', 'duration', 'phases', 'targetTemp', 'sensorIssues', 'fanIssues', 'serialNumber', 'telemetry']);
      if (missing.length) return fail('history record missing ' + missing.join(', '));
      const save = await post(ctx, `/api/cure-runs/${RUN_ID}/report`, { content: '<html>qa</html>', summary: { steps: 2 }, format: 'html' });
      if (!save.data || save.data.ok !== true || save.data.reportId === undefined) return fail('report save: ' + short(save.text));
      const rep = await get(ctx, `/api/cure-runs/${RUN_ID}/report`);
      if (rep.status !== 200 || !rep.data || rep.data.content !== '<html>qa</html>' || rep.data.format !== 'html') return fail('report get: ' + short(rep.text));
      return pass(`start → telemetry → finish → report OK (duration ${run.duration}s, ${run.telemetry.length} sample)`);
    },
    async report_404(ctx) {
      const r = await get(ctx, '/api/cure-runs/qa-no-such-run/report');
      return r.status === 404 && r.data && r.data.ok === false ? pass('404 ' + r.data.message) : fail(`HTTP ${r.status}: ${short(r.text)}`);
    },
    async phase_timing_400(ctx) {
      const bad = await post(ctx, `/api/cure-runs/${RUN_ID}/phase`, { program: 'QA', step: 1 });
      if (bad.status !== 400 || !bad.data || bad.data.ok !== false) return fail(`HTTP ${bad.status}: ${short(bad.text)}`);
      const ok = await post(ctx, `/api/cure-runs/${RUN_ID}/phase`, { program: 'QA', step: 1, process: 'Heating', targetTemp: 50, plannedMin: 10, seconds: 612, rampSeconds: 300, tempStart: 24, tempEnd: 50 });
      if (!ok.data || ok.data.ok !== true || typeof ok.data.count !== 'number') return fail('valid phase refused: ' + short(ok.text));
      return pass(`400 "${bad.data.message}" / valid record accepted (count ${ok.data.count})`);
    },
    version_keys(ctx, test, res) {
      const missing = hasKeys(res.data, ['appVersion', 'gitCommit', 'gitDate', 'lastBoot', 'os', 'kernel', 'python', 'runtime', 'emmcSerial']);
      if (missing.length) return fail('missing ' + missing.join(', '));
      if (!/^\d+\.\d+\.\d+/.test(res.data.appVersion || '')) return fail('appVersion is not x.y.z: ' + res.data.appVersion);
      return pass(`v${res.data.appVersion} on ${res.data.os || '?'} (${res.data.runtime || '?'})`);
    },
    datetime_invalid(ctx, test, res) {
      const d = res.data;
      return d && d.ok === false && d.message === 'Invalid date/time format' ? pass(d.message) : fail(short(res.text));
    },
    async datetime_valid(ctx) {
      if (!(await isWindowsHost(ctx))) return skip('would set the machine clock (timedatectl) — run off-device only');
      const now = new Date();
      const pad = (n) => String(n).padStart(2, '0');
      const r = await post(ctx, '/api/system/datetime', { date: `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`, time: `${pad(now.getHours())}:${pad(now.getMinutes())}` });
      return r.data && r.data.ok === true ? pass(r.data.message) : fail(short(r.text));
    },
    export_or_9081(ctx, test, res) {
      const d = res.data;
      if (!d || typeof d.ok !== 'boolean') return fail(short(res.text));
      if (d.ok) return pass(`${d.message} (${d.path || 'no path'})`);
      if (d.code === 9081) return pass('9081 no USB drive — correct refusal');
      if (d.code === 9082) return warn('9082 write failed: ' + d.message);
      return fail(short(res.text));
    },
    ok_or_9083(ctx, test, res) {
      const d = res.data;
      if (!d) return fail(short(res.text));
      return d.ok ? pass(d.message) : d.code === 9083 ? pass('9083 ' + d.message) : fail(short(res.text));
    },
    async manifest_404_or_ok(ctx) {
      const r = await get(ctx, '/api/system/update/manifest');
      if (r.status === 200 && r.data && r.data.ok && r.data.sha256) return pass(`package ${r.data.version} sha256 ${short(r.data.sha256, 16)}`);
      if (r.status === 404 && r.data && r.data.ok === false && [9081, 9086, 9087].includes(r.data.code)) return pass(`404 ${r.data.code} ${r.data.message}`);
      return fail(`HTTP ${r.status}: ${short(r.text)}`);
    },
    never_run(ctx, test) { return skip(test.reason || 'not executed by QA'); },
    async cloud_config_400(ctx) {
      const r = await post(ctx, '/api/cloud/config', { url: 'https://portal.example' });
      return r.status === 400 && r.data && r.data.ok === false ? pass('400 ' + r.data.message) : fail(`HTTP ${r.status}: ${short(r.text)}`);
    },
    net_status_shape(ctx, test, res) {
      const d = res.data;
      const missing = hasKeys(d, ['connected', 'ip', 'mac', 'gateway', 'interfaces', 'internet', 'wireguardIp']);
      if (missing.length) return fail('missing ' + missing.join(', '));
      if (typeof d.wireguardIp !== 'string') return fail('wireguardIp is not a string');
      if (!Array.isArray(d.interfaces)) return fail('interfaces is not an array');
      const bad = d.interfaces.filter((i) => !i.name || !['UP', 'DOWN'].includes(i.status) || i.ip === undefined);
      if (bad.length) return fail('interface rows incomplete');
      return pass(`connected=${d.connected} ip=${d.ip} internet=${d.internet} (${d.interfaces.length} interfaces)`);
    },
    net_unknown_tool(ctx, test, res) {
      const d = res.data;
      return d && d.ok === false && d.code === 9080 ? pass('9080 ' + d.result) : fail(short(res.text));
    },
    net_injection(ctx, test, res) {
      const d = res.data;
      if (!d || d.ok !== false) return fail('injection string was accepted: ' + short(res.text));
      return d.code === 9085 ? pass('9085 ' + short(d.result)) : warn(`refused with code ${d.code}`);
    },
    net_ping(ctx, test, res) {
      const d = res.data;
      if (!d || typeof d.ok !== 'boolean' || d.result === undefined) return fail(short(res.text));
      return d.ok ? pass(short(d.result.trim().split('\n').pop(), 70)) : d.code === 9085 ? warn('9085 ' + short(d.result)) : fail(short(res.text));
    },
    nfc_shape(ctx, test, res) {
      const d = res.data;
      if (!d || d.ok !== true || typeof d.enabled !== 'boolean' || !d.reader) return fail(short(res.text));
      const missing = hasKeys(d.reader, ['detected', 'port', 'model', 'serial', 'usbId']);
      return missing.length ? fail('reader missing ' + missing.join(', ')) : pass(`enabled=${d.enabled} detected=${d.reader.detected}`);
    },
    nfc_on(ctx, test, res) {
      const d = res.data;
      if (!d || typeof d.ok !== 'boolean' || d.enabled === undefined || !d.reader) return fail(short(res.text));
      if (d.ok) return pass(`${d.message} (${d.reader.model || d.reader.port})`);
      return d.code === 9052 ? pass('9052 refused without a reader') : fail(short(res.text));
    },
    async led_cal_save(ctx) {
      const before = (await get(ctx, '/api/dev/led-calibration')).data;
      const r = await post(ctx, '/api/dev/led-calibration', { factors: { back: 0.9, door: 1.1, left: 1.0, right: 0.8 } });
      if (r.status !== 200 || !r.data || r.data.ok !== true) return fail(short(r.text));
      const got = (await get(ctx, '/api/dev/led-calibration')).data;
      const ok = got && got.factors && got.factors.back === 0.9 && got.factors.right === 0.8;
      if (before && before.factors) await post(ctx, '/api/dev/led-calibration', { factors: before.factors });
      return ok ? pass('saved and read back, previous factors restored') : fail('read back: ' + short(got));
    },
    async led_cal_invalid(ctx) {
      const r = await post(ctx, '/api/dev/led-calibration', { factors: { back: 2.0, door: 1.0, left: 1.0, right: 1.0 } });
      if (r.status !== 400 || !r.data || r.data.ok !== false) return fail(`HTTP ${r.status}: ${short(r.text)}`);
      const r2 = await post(ctx, '/api/dev/led-calibration', { factors: { back: 1.0 } });
      return r2.status === 400 ? pass('400 ' + r.data.message) : fail('missing zones accepted');
    },
    led_cal_reset(ctx, test, res) {
      const d = res.data;
      const ok = d && d.ok === true && d.factors && ['back', 'door', 'left', 'right'].every((z) => d.factors[z] === 1);
      return ok ? pass('all factors back to 1.0') : fail(short(res.text));
    },
    async led_power_bad(ctx) {
      const r = await post(ctx, '/api/dev/led-power', { power: 101 });
      return r.status === 400 && r.data && r.data.ok === false ? pass('400 ' + r.data.message) : fail(`HTTP ${r.status}: ${short(r.text)}`);
    },
    led_power_ok(ctx, test, res) {
      const d = res.data;
      return d && d.ok === true && d.outputs && d.outputs.back !== undefined ? pass('outputs ' + short(d.outputs)) : fail(short(res.text));
    },
    picolog_shape(ctx, test, res) {
      const missing = hasKeys(res.data, ['connected', 'ch1Available', 'temperature', 'deviceInfo', 'error']);
      return missing.length ? fail('missing ' + missing.join(', ')) : pass(`connected=${res.data.connected} ch1=${res.data.ch1Available} ${res.data.temperature !== null ? res.data.temperature + '°C' : ''}`);
    },
    hdt_shape(ctx, test, res) {
      const d = res.data;
      const missing = hasKeys(d, ['state', 'running', 'finalStatus', 'message', 'hdtC', 'safetyMarginC', 'currentPower', 'stepIndex', 'totalSteps', 'rawTemp', 'rateCPerMin', 'avgTemp', 'stepElapsedSec', 'totalElapsedSec', 'startedAt', 'endedAt', 'picolog', 'factors', 'outputs', 'results', 'recommendedPower', 'boost', 'maxMeasuredTemp', 'heaterFanPwm', 'config', 'sampleCount']);
      if (missing.length) return fail('missing ' + missing.join(', '));
      if (d.totalSteps !== 9 || !d.config || !Array.isArray(d.config.powerLevels)) return fail(`totalSteps ${d.totalSteps}, powerLevels ${short(d.config && d.config.powerLevels)}`);
      return pass(`state ${d.state}, ${d.totalSteps} power levels`);
    },
    hdt_reset(ctx, test, res) {
      const d = res.data;
      if (!d || typeof d.ok !== 'boolean') return fail(short(res.text));
      return d.ok ? pass('reset to IDLE') : d.message === 'Calibration is running' ? warn(d.message) : fail(short(res.text));
    },
    dvt_meter(ctx, test, res) {
      const d = res.data;
      if (!d || typeof d.present !== 'boolean') return fail(short(res.text));
      if (!d.present) return warn('no StarBright on the machine: ' + d.message);
      const missing = hasKeys(d, ['head', 'wavelength_nm', 'unit_name', 'reading_mw_cm2']);
      return missing.length ? fail('missing ' + missing.join(', ')) : pass(`${d.head} set to ${d.wavelength_nm} nm, ${d.reading_mw_cm2} mW/cm2`);
    },
    dvt_sweep_shape(ctx, test, res) {
      const missing = hasKeys(res.data, ['ok', 'running', 'status', 'phase', 'config', 'steps', 'error', 'meter', 'meter_wavelength_verified', 'dark_mw_cm2', 'n_samples']);
      return missing.length ? fail('missing ' + missing.join(', ')) : pass(`status ${res.data.status}, phase ${res.data.phase}`);
    },
    dvt_uv_off_shape(ctx, test, res) {
      const missing = hasKeys(res.data, ['ok', 'running', 'status', 'phase', 'mode', 'plateau_mw_cm2', 'uv_off_time_s', 'uv_off_before_door_open', 'release_to_off_s', 'residual_mw_cm2', 'program_end', 'alerts_after', 'n_samples']);
      return missing.length ? fail('missing ' + missing.join(', ')) : pass(`status ${res.data.status}, phase ${res.data.phase}`);
    },
    dvt_refused_intensity(ctx, test, res) {
      const d = res.data;
      return d && d.ok === false && String(d.message).startsWith('intensity must be 10-100') ? pass(d.message) : fail(short(res.text));
    },
    dvt_refused(ctx, test, res) {
      const d = res.data;
      return d && d.ok === false && String(d.message).startsWith('wavelength must be 405 or 450') ? pass(d.message) : fail(short(res.text));
    },
    recipe_idle_shape(ctx, test, res) {
      const d = res.data;
      const missing = hasKeys(d, ['state', 'runId', 'materialId', 'materialName', 'stepIndex', 'totalSteps', 'process', 'phase', 'targetTemp', 'stepElapsedSec', 'stepRemainingSec', 'totalElapsedSec', 'estimatedTotalSec', 'startedAt', 'endedAt', 'message', 'errorCode']);
      if (missing.length) return fail('missing ' + missing.join(', '));
      return ['idle', 'completed', 'aborted', 'error'].includes(d.state) ? pass(`state ${d.state}`) : warn(`a program is ${d.state} (${d.materialName}) — recipe tests will be refused`);
    },
    async recipe_start(ctx) {
      await post(ctx, '/api/cure/stop?immediate=1');
      const r = await post(ctx, '/api/recipe/start', { materialId: 'preset-ST45', runId: RECIPE_RUN_ID, serialNumber: 'QA' }, { timeout: 20000 });
      if (!r.data || r.data.ok !== true) return fail('start: ' + short(r.text));
      const deadline = Date.now() + 10000;
      let s = (await get(ctx, '/api/recipe/status')).data;
      while (s && s.state !== 'running' && Date.now() < deadline) { await sleep(300); s = (await get(ctx, '/api/recipe/status')).data; }
      if (!s || s.state !== 'running') return fail(`state ${s && s.state}: ${s && s.message}`);
      const st = await state(ctx);
      if (!st.recipe || st.recipe.state !== 'running') return fail('/api/state.recipe does not show the run');
      return pass(`running '${s.materialName}' step ${s.stepIndex + 1}/${s.totalSteps} ${s.process} (${s.phase}), est. ${Math.round(s.estimatedTotalSec / 60)} min`);
    },
    async recipe_double_start(ctx) {
      const r = await post(ctx, '/api/recipe/start', { materialId: 'preset-ST45' }, { timeout: 20000 });
      return envelope(r, 6015);
    },
    async recipe_pause_resume(ctx) {
      const p = await post(ctx, '/api/recipe/pause');
      if (!p.data || p.data.ok !== true) return fail('pause: ' + short(p.text));
      let s = (await get(ctx, '/api/recipe/status')).data;
      if (!s || s.state !== 'paused') return fail(`state after pause: ${s && s.state}`);
      const r = await post(ctx, '/api/recipe/resume', undefined, { timeout: 20000 });
      if (!r.data || r.data.ok !== true) return fail('resume: ' + short(r.text));
      s = (await get(ctx, '/api/recipe/status')).data;
      return s && s.state === 'running' ? pass('paused → running') : fail(`state after resume: ${s && s.state}`);
    },
    async recipe_abort(ctx) {
      const r = await post(ctx, '/api/recipe/abort');
      if (!r.data || r.data.ok !== true) return fail('abort: ' + short(r.text));
      const s = (await get(ctx, '/api/recipe/status')).data;
      await post(ctx, '/api/cure/stop?immediate=1');
      const hist = (await get(ctx, '/api/cure-history')).data;
      const run = Array.isArray(hist) && hist.find((x) => x.id === RECIPE_RUN_ID);
      if (!s || s.state !== 'aborted') return fail(`state after abort: ${s && s.state}`);
      return run && run.status === 'aborted' ? pass('aborted; cure-history records the run as aborted') : warn('aborted, but the run is not in cure-history');
    },
    async recipe_bad_material(ctx) {
      const unknown = await post(ctx, '/api/recipe/start', { materialId: 'qa-no-such-material' });
      if (!unknown.data || unknown.data.ok !== false) return fail('unknown material accepted');
      const bad = await post(ctx, '/api/recipe/start', { material: { id: 'qa-bad', name: 'Bad', steps: [{ step: 1, process: 'Heating', temperature: 99, time: 10 }] } });
      return envelope(bad, 7001);
    },
    errors_json(ctx, test, res) {
      const d = res.data;
      const list = Array.isArray(d) ? d : d && Array.isArray(d.errors) ? d.errors : null;
      if (!list) return fail('no error records: ' + short(res.text));
      const bad = list.filter((e) => hasKeys(e, ['code', 'key', 'severity', 'category', 'layer', 'message', 'description', 'troubleshooting', 'supportUrl']).length);
      if (bad.length) return fail(`${bad.length} records incomplete`);
      const codes = list.map((e) => e.code);
      const need = [6015, 6016, 7001, 7002, 7003, 9001, 9002, 9052, 9081].filter((c) => !codes.includes(c));
      if (need.length) return fail('registry missing codes ' + need.join(', '));
      return pass(`${list.length} records`);
    },
    json_object(ctx, test, res) {
      return res.status === 200 && res.data && typeof res.data === 'object' ? pass(`${Object.keys(res.data).length} keys`) : fail(`HTTP ${res.status}: ${short(res.text)}`);
    },
    async ui_index(ctx) {
      const r = await call(ctx, '/', { method: 'GET' });
      if (r.status === 404 && r.data && r.data.message) return warn('UI not built: ' + r.data.message);
      return r.status === 200 && /<div id="root"/.test(r.text) ? pass('index.html served') : fail(`HTTP ${r.status} ${r.contentType}`);
    },
    async ui_spa(ctx) {
      const r = await call(ctx, '/settings', { method: 'GET' });
      if (r.status === 404 && r.data && r.data.message) return warn('UI not built');
      return r.status === 200 && /text\/html/.test(r.contentType) ? pass('/settings falls back to index.html') : fail(`HTTP ${r.status} ${r.contentType}`);
    },
    async perf_state(ctx) {
      const times = [];
      for (let i = 0; i < 5; i++) { const t = Date.now(); await get(ctx, '/api/state'); times.push(Date.now() - t); }
      const med = times.sort((a, b) => a - b)[2];
      const status = med < 200 ? 'pass' : med < 500 ? 'warn' : 'fail';
      return { status, msg: `median ${med} ms over 5 polls (min ${times[0]}, max ${times[4]})` };
    },
    async perf_materials(ctx) {
      const t = Date.now();
      const [p, u] = await Promise.all([get(ctx, '/api/materials/presets'), get(ctx, '/api/materials/user')]);
      const ms = Date.now() - t;
      const n = (Array.isArray(p.data) ? p.data.length : 0) + (Array.isArray(u.data) ? u.data.length : 0);
      return { status: ms < 500 ? 'pass' : ms < 1500 ? 'warn' : 'fail', msg: `${n} materials in ${ms} ms` };
    },

    // ---- native UI (Step B): only present when the host is scurebox-ui; the browser-UI host answers 404 → skip
    async ui_route(ctx) {
      const r = await get(ctx, '/api/ui/route');
      if (r.status === 404) return skip('native UI not running on this host (browser UI / API-only)');
      if (!r.data || !r.data.ok || !r.data.route) return fail('no route in response: ' + short(r.text));
      return pass(`route ${r.data.route} (${r.data.title})`);
    },
    async ui_navigate(ctx, test) {
      const probe = await get(ctx, '/api/ui/route');
      if (probe.status === 404) return skip('native UI not running');
      const target = test.route || 'Settings';
      const n = await post(ctx, `/api/ui/navigate?to=${target}`);
      if (!n.data || !n.data.ok) return fail('navigate refused: ' + short(n.text));
      await sleep(600);
      const r = await get(ctx, '/api/ui/route');
      if (!r.data || r.data.route !== target) return fail(`route is ${r.data && r.data.route} (expected ${target})`);
      return pass(`navigated to ${target}`);
    },
    async ui_tour(ctx) {
      const probe = await get(ctx, '/api/ui/route');
      if (probe.status === 404) return skip('native UI not running');
      const routes = ['Home', 'Settings', 'Alerts', 'Network', 'CureHistory', 'Home'];   // the program editor is a dialog, not a route
      const bad = [];
      for (const target of routes) {
        await post(ctx, `/api/ui/navigate?to=${target}`);
        await sleep(400);
        const r = await get(ctx, '/api/ui/route');
        if (!r.data || r.data.route !== target) bad.push(`${target}→${r.data && r.data.route}`);
      }
      return bad.length ? fail('wrong routes: ' + bad.join(', ')) : pass(`${routes.length - 1} pages reachable`);
    },
    async ui_screenshot(ctx) {
      const probe = await get(ctx, '/api/ui/route');
      if (probe.status === 404) return skip('native UI not running');
      const res = await ctx.fetch(ctx.apiUrl + '/api/ui/screenshot', { signal: AbortSignal.timeout(15000) });
      if (!res.ok) return fail('HTTP ' + res.status);
      const buf = new Uint8Array(await res.arrayBuffer());
      const png = buf.length > 8 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47;
      if (!png) return fail(`not a PNG (${buf.length} bytes)`);
      if (buf.length < 5000) return warn(`PNG suspiciously small (${buf.length} bytes) - blank frame?`);
      return pass(`PNG ${(buf.length / 1024).toFixed(0)} KB`);
    },
    async ui_tap(ctx) {
      const probe = await get(ctx, '/api/ui/route');
      if (probe.status === 404) return skip('native UI not running');
      await post(ctx, '/api/ui/navigate?to=Home');
      await sleep(400);
      const t = await post(ctx, '/api/ui/tap?x=1423&y=50');   // TopBar settings gear (design coordinates)
      if (!t.data || !t.data.ok) return fail('tap refused: ' + short(t.text));
      await sleep(600);
      const r = await get(ctx, '/api/ui/route');
      if (!r.data || r.data.route !== 'Settings') return fail(`tap on the gear led to ${r.data && r.data.route}`);
      await post(ctx, '/api/ui/navigate?to=Home');
      return pass('tap on the TopBar gear opened Settings');
    },
  };

  // ------------------------------------------------------------------ the table
  const CATEGORIES = [
    { id: 'connectivity', name: 'API Connectivity', icon: '🌐', tests: [
      { id: 'api_state', name: 'GET /api/state', desc: 'The 1 Hz state poll responds with the hardware state', endpoint: '/api/state', method: 'GET', expect: 'chamberTemp' },
      { id: 'api_version', name: 'GET /api/system/version', desc: 'Version info responds', endpoint: '/api/system/version', method: 'GET', expect: 'appVersion' },
      { id: 'api_404', name: 'Unknown /api Route → 404 JSON', desc: 'An unknown /api path answers 404 with {ok:false, message} — never the SPA page', check: 'not_found_json' },
    ] },
    { id: 'state', name: 'State Shape', icon: '📋', tests: [
      { id: 'state_keys', name: 'Every Contract Key Present', desc: 'GET /api/state carries every key of docs/01 §1, including counters / cloudSync / nfcEnabled / nfcReader / recipe', endpoint: '/api/state', method: 'GET', check: 'state_keys' },
      { id: 'state_nested', name: 'Nested Shapes', desc: 'fans / fanRpm groups, fanRpmEach per fan, ledTemps zones, faults, sensors, fanHealth, ledHealth (status vocabularies), counters, cloudSync, nfcReader', endpoint: '/api/state', method: 'GET', check: 'state_nested' },
      { id: 'state_sim', name: 'Simulation Fixed Values', desc: 'In simulation: n2LinePressure 6.0 and n2Pressure {0.6 MPa, analog_voltage} (skipped on the real board)', endpoint: '/api/state', method: 'GET', check: 'state_sim' },
    ] },
    { id: 'cure', name: 'Cure Operations', icon: '🔥', tests: [
      { id: 'cure_heat', name: 'Heat To 40°C', desc: 'POST /api/cure/heat?target=40', endpoint: '/api/cure/heat?target=40', method: 'POST', expect: 'ok' },
      { id: 'cure_heat_state', name: 'Heating Reflected In State', desc: 'isHeating + targetTemp follow the heat command', check: 'heating_on' },
      { id: 'cure_dry', name: 'Dry To 45°C', desc: 'POST /api/cure/dry?target=45', endpoint: '/api/cure/dry?target=45', method: 'POST', expect: 'ok' },
      { id: 'cure_405', name: 'Cure UV 405 nm @ 30 %', desc: 'POST /api/cure/cure-405?target=60&intensity=30', endpoint: '/api/cure/cure-405?target=60&intensity=30', method: 'POST', expect: 'ok' },
      { id: 'cure_405_state', name: 'UV 405 Reflected In State', desc: 'uvOn with uvWavelength 405 and uvOutputs', check: 'uv_on_405' },
      { id: 'cure_450', name: 'Bleaching UV 450 nm @ 30 %', desc: 'POST /api/cure/cure-450?target=60&intensity=30', endpoint: '/api/cure/cure-450?target=60&intensity=30', method: 'POST', expect: 'ok' },
      { id: 'cure_uv_only', name: 'UV Only With Vent', desc: 'POST /api/cure/uv-only?intensity=30&wavelength=405&vent=1 — no heating, damper open + intake fan', endpoint: '/api/cure/uv-only?intensity=30&wavelength=405&vent=1', method: 'POST', expect: 'ok' },
      { id: 'cure_cool', name: 'Cool (medium) To 25°C', desc: 'POST /api/cure/cool?target=25&mode=medium', endpoint: '/api/cure/cool?target=25&mode=medium', method: 'POST', expect: 'ok' },
      { id: 'cure_cool_state', name: 'Cooling Reflected In State', desc: 'isCooling + coolingMode + coolingFanPwm follow the cool command', check: 'cooling_on' },
      { id: 'cure_n2_on', name: 'Nitrogen Valve Open', desc: 'POST /api/cure/nitrogen?on=1', endpoint: '/api/cure/nitrogen?on=1', method: 'POST', expect: 'ok' },
      { id: 'cure_n2_off', name: 'Nitrogen Valve Close', desc: 'POST /api/cure/nitrogen?on=0', endpoint: '/api/cure/nitrogen?on=0', method: 'POST', expect: 'ok' },
      { id: 'cure_stop', name: 'Stop All (immediate)', desc: 'POST /api/cure/stop?immediate=1', endpoint: '/api/cure/stop?immediate=1', method: 'POST', check: 'stop_message' },
      { id: 'cure_stop_state', name: 'All Outputs Off', desc: 'heater, cooling, UV and N2 read off after stop', check: 'all_off' },
      { id: 'rej_temp_high', name: 'Reject Heat 99°C (7001)', desc: 'target above 80 is refused with code 7001', endpoint: '/api/cure/heat?target=99', method: 'POST', check: 'reject', code: 7001 },
      { id: 'rej_temp_low', name: 'Reject Heat 10°C (7001)', desc: 'target below 30 is refused with code 7001', endpoint: '/api/cure/heat?target=10', method: 'POST', check: 'reject', code: 7001 },
      { id: 'rej_intensity', name: 'Reject Intensity 5 % (7002)', desc: 'cure-405 with intensity below 10 is refused with 7002', endpoint: '/api/cure/cure-405?target=60&intensity=5', method: 'POST', check: 'reject', code: 7002 },
      { id: 'rej_mode', name: 'Reject Cooling Mode "turbo" (7003)', desc: 'cool with an unknown mode is refused with 7003', endpoint: '/api/cure/cool?target=25&mode=turbo', method: 'POST', check: 'reject', code: 7003 },
      { id: 'rej_cool_temp', name: 'Reject Cool 15°C (7001)', desc: 'cool target below 20 is refused with 7001', endpoint: '/api/cure/cool?target=15', method: 'POST', check: 'reject', code: 7001 },
      { id: 'rej_wavelength', name: 'Reject Wavelength 500', desc: 'uv-only with an unknown wavelength is refused (message, no code)', endpoint: '/api/cure/uv-only?intensity=30&wavelength=500', method: 'POST', check: 'reject_nocode' },
      { id: 'stop_always_ok', name: 'Stop Is Always OK', desc: 'POST /api/cure/stop answers ok:true even when nothing runs', endpoint: '/api/cure/stop', method: 'POST', check: 'stop_message' },
    ] },
    { id: 'chamber', name: 'Chamber Heating', icon: '🌡️', tests: [
      { id: 'chamber_set', name: 'Set Target 40°C', desc: 'POST /api/chamber/temperature?target=40 (manual heating)', endpoint: '/api/chamber/temperature?target=40', method: 'POST', expect: 'ok' },
      { id: 'chamber_reject', name: 'Reject Target 99°C (7001)', desc: 'manual target outside 30–80 is refused with 7001', endpoint: '/api/chamber/temperature?target=99', method: 'POST', check: 'reject', code: 7001 },
      { id: 'chamber_stop', name: 'Stop Heating', desc: 'POST /api/chamber/stop', endpoint: '/api/chamber/stop', method: 'POST', expect: 'ok' },
    ] },
    { id: 'hardware', name: 'Direct Hardware', icon: '🔧', tests: [
      { id: 'fan_set', name: 'Fan Group Speed', desc: 'POST /api/fans/chamber_intake?speed=40 always answers ok', endpoint: '/api/fans/chamber_intake?speed=40', method: 'POST', expect: 'ok' },
      { id: 'fan_reflect', name: 'Fan Duty Reflected', desc: 'fans.chamber_intake reads 40 % (then back to 0)', check: 'fan_duty' },
      { id: 'fan_override_on', name: 'Fan Override On', desc: 'POST /api/fans/override?fan=FAN_DOOR&on=1', endpoint: '/api/fans/override?fan=FAN_DOOR&on=1', method: 'POST', expect: 'ok' },
      { id: 'fan_override_off', name: 'Fan Override Off', desc: 'POST /api/fans/override?fan=FAN_DOOR&on=0', endpoint: '/api/fans/override?fan=FAN_DOOR&on=0', method: 'POST', expect: 'ok' },
      { id: 'fan_override_unknown', name: 'Fan Override Unknown Fan', desc: 'fan=FAN_NOPE answers {ok:false, message:"unknown fan: …"}', endpoint: '/api/fans/override?fan=FAN_NOPE&on=1', method: 'POST', check: 'override_unknown' },
      { id: 'damper_open', name: 'Damper Open', desc: 'POST /api/damper/open', endpoint: '/api/damper/open', method: 'POST', expect: 'ok' },
      { id: 'damper_close', name: 'Damper Close', desc: 'POST /api/damper/close', endpoint: '/api/damper/close', method: 'POST', expect: 'ok' },
      { id: 'uv_on', name: 'UV On (diagnostic)', desc: 'POST /api/uv?on=1&intensity=30&wavelength=405', endpoint: '/api/uv?on=1&intensity=30&wavelength=405', method: 'POST', expect: 'ok' },
      { id: 'uv_off', name: 'UV Off', desc: 'POST /api/uv?on=0', endpoint: '/api/uv?on=0', method: 'POST', expect: 'ok' },
      { id: 'bofa_on', name: 'BOFA On', desc: 'POST /api/bofa?on=1', endpoint: '/api/bofa?on=1', method: 'POST', expect: 'ok' },
      { id: 'bofa_off', name: 'BOFA Off', desc: 'POST /api/bofa?on=0', endpoint: '/api/bofa?on=0', method: 'POST', expect: 'ok' },
      { id: 'rgb_alerts', name: 'RGB Alert Counts', desc: 'POST /api/rgb/alerts?critical=0&warning=0 echoes the counts', endpoint: '/api/rgb/alerts?critical=0&warning=0', method: 'POST', expect: 'critical' },
      { id: 'rgb_on', name: 'RGB Manual Override On', desc: 'POST /api/rgb?on=1&color=blue answers the {ok, message} envelope', endpoint: '/api/rgb?on=1&color=blue', method: 'POST', check: 'envelope_ok' },
      { id: 'rgb_off', name: 'RGB Manual Override Off', desc: 'POST /api/rgb?on=0 returns the strip to the status ladder', endpoint: '/api/rgb?on=0', method: 'POST', check: 'envelope_ok' },
      { id: 'door_cycle', name: 'Door Open', desc: 'POST /api/door/open is always ok; doorClosed reads false; in simulation it re-closes after 5 s', check: 'door_cycle' },
      { id: 'door_ack', name: 'Door Abort Acknowledge', desc: 'POST /api/door-abort/ack', endpoint: '/api/door-abort/ack', method: 'POST', expect: 'ok' },
    ] },
    { id: 'diagnostics', name: 'Diagnostics', icon: '🩺', tests: [
      { id: 'fan_test', name: 'Fan Test (all)', desc: 'POST /api/diagnostics/fan-test?fan=all → {rpm, status, fans{FAN_*:{rpm,status}}, message}', endpoint: '/api/diagnostics/fan-test?fan=all', method: 'POST', check: 'fan_test_shape', timeout: 30000 },
      { id: 'fan_test_unknown', name: 'Fan Test Unknown Fan', desc: 'fan=nope → {ok:true, rpm:0, status:"FAIL", message:"unknown fan: nope"}', endpoint: '/api/diagnostics/fan-test?fan=nope', method: 'POST', check: 'fan_test_unknown' },
      { id: 'led_test', name: 'LED Test (2 s)', desc: 'POST /api/diagnostics/led-test?seconds=2&min_rise=0.1 → status/stage/results[] shape (may pre-cool 20 s when the chamber is warm)', endpoint: '/api/diagnostics/led-test?seconds=2&min_rise=0.1&wavelength=405', method: 'POST', check: 'led_test_shape', timeout: 90000 },
    ] },
    { id: 'data', name: 'Data Round Trips', icon: '💾', tests: [
      { id: 'presets', name: 'GET /api/materials/presets', desc: 'Bundled preset programs (HTTP 200 array)', endpoint: '/api/materials/presets', method: 'GET', expectArray: true },
      { id: 'materials_get', name: 'GET /api/materials/user', desc: 'User programs array', endpoint: '/api/materials/user', method: 'GET', expectArray: true },
      { id: 'materials_roundtrip', name: 'User Materials Replace', desc: 'Append a program, read it back, restore the list', check: 'materials_roundtrip' },
      { id: 'print_get', name: 'GET /api/print-history', desc: 'Print history array', endpoint: '/api/print-history', method: 'GET', expectArray: true },
      { id: 'print_roundtrip', name: 'Print History Replace', desc: 'Prepend a record, read it back, restore the list', check: 'print_roundtrip' },
      { id: 'cure_history_get', name: 'GET /api/cure-history', desc: 'Cure runs array (newest first)', endpoint: '/api/cure-history', method: 'GET', expectArray: true },
      { id: 'cure_run_roundtrip', name: 'Cure Run qa-test-run', desc: 'start → telemetry → finish → report POST/GET with id qa-test-run', check: 'cure_run_roundtrip' },
      { id: 'report_404', name: 'Report 404 For Unknown Run', desc: 'GET /api/cure-runs/{unknown}/report → 404 {ok:false, message:"No report"}', check: 'report_404' },
      { id: 'phase_timing_400', name: 'Phase Timing Validation', desc: 'POST /api/cure-runs/{id}/phase without process/seconds → 400; a valid record is appended', check: 'phase_timing_400' },
      { id: 'phase_timings_get', name: 'GET /api/phase-timings', desc: 'Collected phase timings array', endpoint: '/api/phase-timings', method: 'GET', expectArray: true },
    ] },
    { id: 'system', name: 'System', icon: '⚙️', tests: [
      { id: 'sys_version', name: 'Version Info Keys', desc: 'appVersion x.y.z + gitCommit/gitDate/lastBoot/os/kernel/python/runtime/emmcSerial', endpoint: '/api/system/version', method: 'GET', check: 'version_keys' },
      { id: 'sys_datetime_bad', name: 'Date/Time Validation', desc: 'POST /api/system/datetime with a bad format → {ok:false, message:"Invalid date/time format"}', endpoint: '/api/system/datetime', method: 'POST', body: { date: '14/09/2026', time: '10:00' }, check: 'datetime_invalid' },
      { id: 'sys_datetime_ok', name: 'Date/Time Set (off-device)', desc: 'Valid date/time accepted — only exercised on a Windows dev host (on the machine it would set the clock)', check: 'datetime_valid' },
      { id: 'sys_export_csv', name: 'Export CSV To USB', desc: 'POST /api/system/export-csv → ok, or 9081 without a USB drive (pass)', endpoint: '/api/system/export-csv', method: 'POST', body: { filename: 'qa-program', content: 'Step,Process\n1,Heating\n' }, check: 'export_or_9081' },
      { id: 'sys_export_report', name: 'Export Report To USB', desc: 'POST /api/system/export-report → ok, or 9081 without a USB drive (pass)', endpoint: '/api/system/export-report', method: 'POST', body: { filename: 'qa-report', content: '<html></html>' }, check: 'export_or_9081' },
      { id: 'sys_export_logs', name: 'Export Logs', desc: 'POST /api/system/export-logs → ok or 9083', endpoint: '/api/system/export-logs', method: 'POST', check: 'ok_or_9083' },
      { id: 'sys_update_manifest', name: 'Update Manifest', desc: 'GET /api/system/update/manifest → 404 with 9081/9086/9087 without a package, or {version, sha256}', check: 'manifest_404_or_ok' },
      { id: 'sys_reboot', name: 'Reboot (not executed)', desc: 'POST /api/system/reboot is never sent by QA', check: 'never_run', reason: 'would reboot the machine' },
      { id: 'sys_shutdown', name: 'Shutdown (not executed)', desc: 'POST /api/system/shutdown is never sent by QA', check: 'never_run', reason: 'would power the machine off' },
      { id: 'cloud_config_400', name: 'Cloud Config Requires url+key', desc: 'POST /api/cloud/config without key → 400', check: 'cloud_config_400' },
    ] },
    { id: 'network', name: 'Network', icon: '📡', tests: [
      { id: 'net_status', name: 'Network Status Shape', desc: 'GET /api/network/status → connected/ip/mac/gateway/interfaces[]/internet', endpoint: '/api/network/status', method: 'GET', check: 'net_status_shape' },
      { id: 'net_diag_unknown', name: 'Diagnostics Unknown Tool (9080)', desc: 'tool=nmap → {ok:false, code:9080, result:"Unknown tool"}', endpoint: '/api/network/diagnostics', method: 'POST', body: { tool: 'nmap', address: '127.0.0.1' }, check: 'net_unknown_tool' },
      { id: 'net_diag_injection', name: 'Diagnostics Rejects Shell Injection (9085)', desc: 'address "127.0.0.1; rm -rf /" is refused by the hostname/IP validator, never passed to a shell', endpoint: '/api/network/diagnostics', method: 'POST', body: { tool: 'ping', address: '127.0.0.1; rm -rf /' }, check: 'net_injection' },
      { id: 'net_diag_ping', name: 'Diagnostics Ping', desc: 'tool=ping address=127.0.0.1 → {ok, result}', endpoint: '/api/network/diagnostics', method: 'POST', body: { tool: 'ping', address: '127.0.0.1' }, check: 'net_ping', timeout: 60000 },
      { id: 'net_static', name: 'Static IP (not executed)', desc: 'POST /api/network/static is never sent by QA', check: 'never_run', reason: 'would reconfigure eth0' },
    ] },
    { id: 'nfc', name: 'NFC', icon: '🏷️', tests: [
      { id: 'nfc_get', name: 'GET /api/nfc', desc: '{ok, enabled, reader{detected,port,model,serial,usbId}}', endpoint: '/api/nfc', method: 'GET', check: 'nfc_shape' },
      { id: 'nfc_on', name: 'NFC On', desc: 'POST /api/nfc?on=1 → ok with a reader, else 9052 refusal', endpoint: '/api/nfc?on=1', method: 'POST', check: 'nfc_on' },
      { id: 'nfc_off', name: 'NFC Off', desc: 'POST /api/nfc?on=0', endpoint: '/api/nfc?on=0', method: 'POST', expect: 'ok' },
    ] },
    { id: 'dev', name: 'Developer Mode', icon: '🧪', tests: [
      { id: 'dev_log', name: 'Dev Event Log', desc: 'POST /api/dev/log {event, detail}', endpoint: '/api/dev/log', method: 'POST', body: { event: 'QA run', detail: { tool: 'qa-tool' } }, expect: 'ok' },
      { id: 'led_cal_get', name: 'LED Calibration Get', desc: 'GET /api/dev/led-calibration → {ok, factors{back,door,left,right}}', endpoint: '/api/dev/led-calibration', method: 'GET', expect: 'factors' },
      { id: 'led_cal_save', name: 'LED Calibration Save', desc: 'POST factors 0.9/1.1/1.0/0.8, read back, restore', check: 'led_cal_save' },
      { id: 'led_cal_invalid', name: 'LED Calibration Validation (400)', desc: 'factor 2.0 or a missing zone → 400 "Invalid factors: …"', check: 'led_cal_invalid' },
      { id: 'led_cal_reset', name: 'LED Calibration Reset', desc: 'POST /api/dev/led-calibration/reset → all 1.0', endpoint: '/api/dev/led-calibration/reset', method: 'POST', check: 'led_cal_reset' },
      { id: 'led_power_bad', name: 'LED Power Validation (400)', desc: 'power 101 → 400', check: 'led_power_bad' },
      { id: 'led_power_zero', name: 'LED Power 0 (safe off)', desc: 'POST /api/dev/led-power {power:0} → {ok, outputs}', endpoint: '/api/dev/led-power', method: 'POST', body: { power: 0 }, check: 'led_power_ok' },
      { id: 'picolog', name: 'PicoLog Status', desc: 'GET /api/dev/picolog/status → {connected, ch1Available, temperature, deviceInfo, error}', endpoint: '/api/dev/picolog/status', method: 'GET', check: 'picolog_shape' },
      { id: 'hdt_status', name: 'HDT Status Shape', desc: 'GET /api/dev/hdt/status → the full state-machine payload (9 power levels)', endpoint: '/api/dev/hdt/status', method: 'GET', check: 'hdt_shape' },
      { id: 'hdt_reset', name: 'HDT Reset', desc: 'POST /api/dev/hdt/reset → {ok:true, message:null} when idle', endpoint: '/api/dev/hdt/reset', method: 'POST', check: 'hdt_reset' },
    ] },
    { id: 'dvt', name: 'DVT Bench (StarBright)', icon: '🔬', tests: [
      { id: 'dvt_meter', name: 'StarBright on the machine', desc: 'GET /api/dvt/meter → {present, head, wavelength_nm, reading_mw_cm2} (WARN when no meter is plugged in)', endpoint: '/api/dvt/meter', method: 'GET', check: 'dvt_meter' },
      { id: 'dvt_sweep_status', name: 'UV Sweep Status Shape', desc: 'GET /api/dvt/uv-sweep?samples=0 → the sweep document (same JSON as the Python machine software)', endpoint: '/api/dvt/uv-sweep?samples=0', method: 'GET', check: 'dvt_sweep_shape' },
      { id: 'dvt_sweep_bad_wl', name: 'UV Sweep Validation', desc: 'POST /api/dvt/uv-sweep?wavelength=365 → refused before any LED lights', endpoint: '/api/dvt/uv-sweep?wavelength=365', method: 'POST', check: 'dvt_refused' },
      { id: 'dvt_uv_off_status', name: 'UV-off Timing Status Shape', desc: 'GET /api/dvt/uv-off?samples=0 → the SAF-012 step 2 document (plateau, uv_off_time_s, program_end, alerts)', endpoint: '/api/dvt/uv-off?samples=0', method: 'GET', check: 'dvt_uv_off_shape' },
      { id: 'dvt_uv_off_bad', name: 'UV-off Timing Validation', desc: 'POST /api/dvt/uv-off?intensity=5 → refused before any LED lights', endpoint: '/api/dvt/uv-off?intensity=5', method: 'POST', check: 'dvt_refused_intensity' },
      { id: 'dvt_meter_bad_wl', name: 'Meter Wavelength Validation', desc: 'POST /api/dvt/meter/wavelength?nm=365 → refused', endpoint: '/api/dvt/meter/wavelength?nm=365', method: 'POST', check: 'dvt_refused' },
    ] },
    { id: 'recipe', name: 'Recipe Runner', icon: '▶️', tests: [
      { id: 'recipe_status', name: 'Recipe Status Shape', desc: 'GET /api/recipe/status → state/runId/materialId/…/errorCode', endpoint: '/api/recipe/status', method: 'GET', check: 'recipe_idle_shape' },
      { id: 'recipe_start', name: 'Start Preset ST45', desc: 'POST /api/recipe/start {materialId:"preset-ST45"} → state running, /api/state.recipe populated', check: 'recipe_start' },
      { id: 'recipe_double_start', name: 'Second Start Refused (6015)', desc: 'starting while a program runs → 6015', check: 'recipe_double_start' },
      { id: 'recipe_pause_resume', name: 'Pause / Resume', desc: 'POST pause → paused, POST resume → running', check: 'recipe_pause_resume' },
      { id: 'recipe_abort', name: 'Abort', desc: 'POST /api/recipe/abort → aborted, run recorded in cure-history, outputs stopped', check: 'recipe_abort' },
      { id: 'recipe_bad_material', name: 'Invalid Program Refused', desc: 'unknown materialId → {ok:false}; inline program with 99°C → 7001', check: 'recipe_bad_material' },
    ] },
    { id: 'static', name: 'Static UI & Config', icon: '🖥️', tests: [
      { id: 'cfg_errors', name: 'errors.json', desc: '/config/errors.json — the central registry with every record complete and the backend codes present', url: '/config/errors.json', check: 'errors_json' },
      { id: 'cfg_system', name: 'system.json', desc: '/config/system.json is served', url: '/config/system.json', check: 'json_object' },
      { id: 'cfg_versions', name: 'versions.json', desc: '/config/versions.json is served', url: '/config/versions.json', check: 'json_object' },
      { id: 'ui_index', name: 'UI Served At /', desc: 'GET / returns the built React page (warn when the UI is not built)', check: 'ui_index' },
      { id: 'ui_spa', name: 'SPA Fallback', desc: 'GET /settings (client route) still returns index.html', check: 'ui_spa' },
    ] },
    { id: 'performance', name: 'Performance', icon: '⚡', tests: [
      { id: 'perf_state', name: 'State Poll Latency', desc: 'median of 5 × GET /api/state: < 200 ms pass, < 500 ms warn', check: 'perf_state' },
      { id: 'perf_materials', name: 'Materials List Latency', desc: 'presets + user lists in parallel: < 500 ms pass, < 1500 ms warn', check: 'perf_materials' },
    ] },
    { id: 'native_ui', name: 'Native UI (Step B)', icon: '🖥️', tests: [
      { id: 'ui_route', name: 'Current Route', desc: 'GET /api/ui/route reports the page the native Avalonia UI shows (skipped on the browser-UI host)', check: 'ui_route' },
      { id: 'ui_navigate', name: 'Navigate To Settings', desc: 'POST /api/ui/navigate?to=Settings changes the current route', check: 'ui_navigate', route: 'Settings' },
      { id: 'ui_tour', name: 'Every Page Reachable', desc: 'Home, Settings, Alerts, Network and Cure History all open by route (the program editor is a dialog)', check: 'ui_tour' },
      { id: 'ui_screenshot', name: 'Screenshot Renders', desc: 'GET /api/ui/screenshot returns a real PNG frame of the main window', check: 'ui_screenshot' },
      { id: 'ui_tap', name: 'Touch Injection', desc: 'POST /api/ui/tap on the TopBar gear opens Settings (synthesised touch at design coordinates)', check: 'ui_tap' },
    ] },
  ];

  // ------------------------------------------------------------------ runner
  async function runTest(test, ctx) {
    const t0 = Date.now();
    try {
      let result;
      if (!test.endpoint && !test.url) {
        result = await CHECKS[test.check](ctx, test);
      } else {
        const res = test.url
          ? await call(ctx, test.url, { method: 'GET', timeout: test.timeout })
          : await call(ctx, test.endpoint, { method: test.method || 'GET', body: test.body, timeout: test.timeout });
        const d = res.data;
        if (test.check) result = await CHECKS[test.check](ctx, test, res);
        else if (test.expect === 'ok') result = d && d.ok === true ? pass(d.message || 'OK') : fail(d && d.message ? `${d.code !== undefined ? d.code + ' ' : ''}${d.message}` : `HTTP ${res.status}: ${short(res.text)}`);
        else if (test.expect) result = d && d[test.expect] !== undefined ? pass(`${test.expect} = ${short(d[test.expect], 40)}`) : fail(`no '${test.expect}' in ${short(res.text)}`);
        else if (test.expectArray) result = Array.isArray(d) ? pass(`${d.length} items`) : fail(`not an array (HTTP ${res.status}): ${short(res.text)}`);
        else result = warn('no expectation defined');
      }
      return Object.assign({ status: 'warn', msg: '' }, result, { ms: Date.now() - t0 });
    } catch (e) {
      return { status: 'fail', msg: e && e.name === 'TimeoutError' ? 'timeout' : String(e && e.message || e), ms: Date.now() - t0 };
    }
  }

  root.SCURE_QA = { CATEGORIES, CHECKS, runTest, STATE_KEYS };
  root.SCURE_QA_TESTS = CATEGORIES;
})(typeof globalThis !== 'undefined' ? globalThis : this);

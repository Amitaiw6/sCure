---
name: project-versioning
description: "sCure versioning system — VERSION file, versions.json registry, /api/system/version, Settings modal"
metadata: 
  node_type: memory
  type: project
  originSessionId: c59c6f7c-0f4f-4307-b08f-9539995dc02e
  modified: 2026-08-06T04:11:49.192Z
---

sCure versioning (established 2026-08-06, reset to 0.1.0):

- Single source of truth: `VERSION` file at repo root (semver, e.g. `0.1.0`).
- Release registry: `public/config/versions.json` — `history[]` newest first, each `{version, date, notes[]}`. Shown in the Settings > Versions modal (tap the "Software Version" row; tap must stopPropagation — the surrounding card counts 10 taps for factory reset).
- Live info: `GET /api/system/version` returns appVersion (VERSION file) + gitCommit/gitDate/lastBoot/os/kernel/python read from the machine. `SystemConfigContext` overrides the static system.json firmware/lastBoot with these. gitCommit is null on the test Pi (files scp'd, not a git checkout).
- QA: `sys_version` test in qa-tool checks semver + live fields.
- Rule: every code change bumps the version — see [[version-bump-every-change]].

# Step B - native embedded UI (Avalonia)

Single-process .NET application, no browser: `src/SCureBox.Ui` (executable `scurebox-ui`) hosts the
firmware container built by `SCureBox.Api.ScureApiHost.Build(...)` (hardware + process + platform layers
and the `/api` contract on :3001 for QA / cloud / the browser tool) and renders the operator UI with Avalonia 11.

## Hosting model
* `Program.Main`: `ScureApiHost.Build(args, b => b.Services.AddSCureBoxUi())` → `app.StartAsync()` on a background
  thread, then Avalonia on the main thread. Shutdown of either side stops the other.
* View models resolve services from the same container: `ICureController`, `IRecipeRunner`, `IMaterialStore`,
  `ICureRunStore`, `IPrintHistoryStore`, `IPhaseTimingStore`, `INetworkService`, `ISystemService`, `IUpdateService`,
  `INfcReaderDetector`, `ILedCalibrationStore`, `IComponentCounters`, `IHdtCalibration`, `ErrorRegistry`, `TimeProvider`.
  **Never** call the HTTP API from the UI.
* Linux (CM5): `AppBuilder.StartLinuxDrm(args, card: "/dev/dri/card1" or first card, scaling: 1.0)` - direct KMS/DRM
  output, libinput touch, no compositor. `SCURE_UI_DRM_CARD` overrides the card; `SCURE_UI_WINDOW=1` forces a desktop
  window (X11/Wayland) for bench use.
* Windows / dev: classic desktop lifetime, a 1920x1200 window (or `SCURE_UI_SIZE=800x480`), simulation hardware.
* `MachineStateStore`: a 1 Hz poll of `ICureController.GetState()` (decorated the same way as `/api/state`) into an
  observable snapshot every page binds to (replaces the React 1 s polling). The read runs on a thread-pool thread and
  only the snapshot is applied on the UI thread at `DispatcherPriority.Background`: on the machine one `GetState` is
  dozens of I2C transactions, and reading on the UI thread stalled touch scrolling once a second.
* `GET /api/ui/screenshot` (added by the UI project) renders the main window to PNG - used to verify the device
  visually over SSH; `GET /api/ui/route` returns the current page; `POST /api/ui/navigate?to=` for QA.

## Touch behaviour
* `TouchScrollGestureRecognizer` (in the `ScrollViewer` control theme) replaces Avalonia's, which tracks the pointer in
  root coordinates and so reads a vertical swipe as horizontal on the rotated portrait panel. It also damps the reported
  touch point adaptively (panel noise below ~4 px is followed at 0.4, a real drag 1:1), fits the fling velocity by least
  squares over the sample window and caps it at 6000 px/s, and ticks inertia at `DispatcherPriority.Render` so the
  offset for a frame is set before that frame is drawn.
* Anything that blocks the UI thread shows up as stutter under a finger. Hardware reads belong on a worker thread
  (see `MachineStateStore`), and long work in a view model belongs in `Task.Run`.

## Screen design
* The React UI is a fixed 800x480 canvas scaled to the panel. The native UI uses a 1920x1200 logical layout
  (the 10.1" Touch Display 2 in landscape) built with the same proportions: a `LayoutTransformControl` scales a
  1600x1000 design surface to the window so it also fits 1920x1080 (bench HDMI) and 1280x800.
* Visual tokens (from `docs/04-ui-spec.md`): dark background `#0B0F14`-ish, surfaces, primary blue, white titles
  (never blue titles - project rule), success green, warning yellow, critical red; Inter font; radii 12-16 px;
  touch targets ≥ 56 px.
* Every page in `docs/04-ui-spec.md` becomes a `Views/<Page>View.axaml` + `ViewModels/<Page>ViewModel.cs`
  (CommunityToolkit.Mvvm, `[ObservableProperty]`, `[RelayCommand]`). Shared controls under `Controls/`.
* Navigation: `INavigationService` with a route enum mirroring the React routes; `ShellView` hosts TopBar + content;
  modals via `DialogHost` control in the shell (no OS windows).
* Text: all user-visible strings in `Resources/Strings.cs` (from the strings table in the spec), US English.
* Boot: `BootView` (S logo, diagnostics lines) → Setup (if `setupComplete` false in `system.json` / settings store)
  → Home. Idle → WakeScreen. Shutdown → blank + `ISystemService.Shutdown()`.

## Process sequencing
The recipe engine is server-side (`IRecipeRunner`), so `CureProcessView` binds to `RecipeStatus` + `MachineState`
and only issues Start/Pause/Resume/Abort/Skip. The UI keeps: pre-flight fan test dialog (`RunFanTest("all")` +
override), door-abort acknowledgement, temperature-stall warning 7004 (5 checks × 5 min < 1 °C), alert banners,
completion + report generation (HTML report saved through `ICureRunStore.SaveReport`, USB export via
`ISystemService.ExportReport`).

## Deliberate differences from the React spec
`docs/04-ui-spec.md` describes the React UI and stays the fidelity reference. These were changed on purpose for the
machine's own panel:
* **No wall clock in the header.** The React header shows `HH:mm` next to the system name; the panel does not.
* **A new program opens with no steps.** React seeds a `Heating 40 °C / 10 min` step; here the operator adds the first
  step themselves, and the program may be emptied completely (saving an empty one is still refused).
* **No "select a program" prompt** above Start Cure. The hint pill only ever says what is blocking a start
  (door open, critical alert).
* **Alerts: `Dismiss` sits in the detail header**, not at the end of the body, so it needs no scrolling.
* **Cure history draws no chart.** The panel shows the run summary and `Export report`; the temperature / UV / fan
  graphs are in the exported report (inline SVG, `CureReportBuilder`).
* **Pre-flight wording** is `Running System Pre-Check` (React: "Checking all fans before starting…") and the fan glyph
  turns while the test runs.
* **The program editor is a modal over Home**, not a page: `Build Cure Program` with the name keyboard, an inline
  process picker and step fields that open the keypad. It is a dialog, not a route, so `Route` carries 12 values and
  the editor lives in `UiPages.Dialogs`.
* **Adding a step brings the new card to the middle** of the editor strip (`MaterialEditorDialogView.CenterStep`,
  driven by `MaterialEditorDialogViewModel.StepAdded`): once the strip outgrows the dialog the fresh card would
  otherwise appear off the right edge. The slide uses the tween below and is clamped to the end of the strip, so the
  last card comes as close to the middle as the strip allows. The first step never slides - the strip is centred by
  its own alignment until it is wider than the dialog.
* **Deleting a program asks first.** The trash icon in edit mode sits next to Duplicate and Edit and the list has no
  undo, so `HomeViewModel.ConfirmDeleteAsync` shows a destructive `MessageDialog` ("Delete "<name>"?") and only
  removes the program on OK. Presets are never deletable and are not even asked about.
* **Dialogs blur the page behind them** - all of them, not only the editor. The blur is a small still of the page
  (RenderTargetBitmap at `ShellView.BlurScale`) stretched back over it, NOT an Avalonia `Effect`: the shell runs
  inside a 90 degree rotation on the portrait-native panel and an effect's offscreen pass ignores that rotation, so
  the blurred page came out upside down on the machine while a screenshot of the same frame looked right.
* **Motion is driven by `Services/Tween.cs`**, not by `Transitions`: a `DoubleTransition` lands on its end value in
  one frame on this render stack. The boot bar and its check glyphs use the tween; the dialog fade uses a timer in
  `DialogHost`.

## Tests
* `tests/SCureBox.Ui.Tests`: view-model tests with fakes/simulation (`SCURE_SIMULATE`) + Avalonia headless
  (`Avalonia.Headless.XUnit`) smoke tests: shell renders, navigation between every page, setup flow, start a preset
  and see the process page update, alerts list from the registry.
* QA: `qa/qa-tests.js` gains a "Native UI" category using `/api/ui/*` (route after navigate, screenshot returns PNG).

## Deploy
* `deploy/scurebox-ui.service` replaces `scurebox.service` + `scurebox-kiosk.service` (`install.sh --ui native`,
  the default; `--ui browser` keeps Step A). Runs as root (DRM master + libinput) with `WatchdogSec=60`,
  `ExecStartPre=+-/usr/bin/chvt 1`, Plymouth handoff (`plymouth quit --retain-splash` right before the first frame).
* The image builder is unchanged: the payload carries both executables; `install.sh` decides.

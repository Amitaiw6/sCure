# React UI reuse + QA conventions

## UI (Step A: reuse the existing React UI unchanged)
* Built with `npm run build` in `sCure-A` → `dist/` (index.html + assets/ + config/ + materials/ + videos/ + compliance/). Absolute asset paths → must be served from the domain root.
* The UI calls the API with an **absolute** base URL `http://localhost:3001/api` (`VITE_HW_API_URL` at build time). Three contexts are hardcoded to `http://localhost:3001` (materials, print-history, cure-history). Therefore: the C# server must listen on **3001**, serve `dist/` at `/`, and keep CORS open.
* No EventSource/WebSocket. Polling only (`/api/state` 1 s, telemetry 5 s, alert summary 30 s, `/api/network/status` 3 s on the network page, HDT status 1 s).
* All commands: POST with query-string parameters and no body, except the JSON-body endpoints listed in `01-api-contract.md`.
* Response envelope: `{ok: boolean, message: string, code?: number}`.
* The UI is a fixed 800×480 canvas scaled to the window (`root.style.scale`). 1280×800 (10.1" Touch Display 2) works: it stretches 1.6× / 1.667×.
* Static assets fetched from the same origin: `/config/system.json`, `/config/errors.json`, `/config/versions.json`.
* Behaviour when the API is down: alert 9089, demo data fallback for lists. Not our concern server-side.
* The program sequencing state machine lives in the UI (`CureProcessPage.tsx`): it calls one endpoint per phase, waits on `/api/state` (ramp ends at chamberTemp ≥ target − 0.5; cooling done at chamberTemp ≤ target + band), then posts phase timing, then `/api/cure/stop` + `finish`. Pause = `stop?immediate=1` + `door/open`; resume re-sends the phase command. Pre-flight = `diagnostics/fan-test?fan=all` (+ `fans/override` on "continue anyway").
* The C# backend ADDITIONALLY offers a server-side recipe runner (`/api/recipe/*`) that executes a whole Material without the UI driving each phase — required by the scope ("Recipe execution engine / State machine / Process sequencing / Abort handling").

## Program validation rules (Domain)
* Temperature: Heating/Drying/Cure/Bleacher 30–80 °C; Cooling 30–75 °C.
* Hold time: Bleacher 1–720 min; others 1–120 min; Cooling/Nitrogen 0.
* UV intensity 10–100 %.
* Cooling target ≥ 5 °C below the previous step's temperature.
* Max 2 Nitrogen steps; after Nitrogen only Cure/Bleacher; after that Cure/Bleacher only Cooling; each N2 purge must be vented by a later Cooling step and followed by ≥1 Cure/Bleacher.
* Temperature monotonically non-decreasing unless a Cooling step resets the chain.
* CSV format (10 columns): `Step,Process,Temperature,Time,TimerMode,UVIntensity,UVStart,UVRampPercent,CoolingMode,Ventilation`; `Temperature=off` on Cure/Bleacher = UV-only; blank for Nitrogen; Time blank for Cooling/Nitrogen; Ventilation on/off only on no-heat rows. Parser needs ≥4 columns per row and a header containing "process" or "step".

## Program estimate (Domain)
AMBIENT 25 °C; heat bands sec/°C: ≤45 → 13, ≤75 → 50, else 80; cool °C/min: fast 2.5, medium 1.5, slow 0.8; nitrogen default 120 s.
`estimateProgram(steps)`: hold + ramp + cool + nitrogen; for timerMode on-ramp only max(0, ramp − hold) is added. Minutes = ceil(total/60).

## Simulation thermal model (Application, when no hardware)
SIM_AMBIENT 24.0 °C; heat 0.5 °C/s toward target; cooling fast 5 / medium 2.5 / slow 1.0 °C per minute; idle drift 0.05 °C/s back to ambient; dt clamped to 10 s; fan RPM 2850 when duty>0; door reads open 5 s after open_door then re-closes.

## QA
1. **Unit tests** (xunit): Domain (validation, estimate, NTC math, pressure conversion, heater PI/delta-sigma, calibration filter, fan health, sensor supervision, LED supervision, strip mode ladder, recipe state machine) with a fake `TimeProvider`.
2. **Integration tests** (xunit + `WebApplicationFactory`): every route in simulation mode, JSON field presence for `/api/state` (all keys), error codes 7001/7002/7003/6015/9052, data round trips with run id `qa-test-run`, static UI serving, SPA fallback.
3. **Browser QA tool** `qa/qa-tool.html`: same record shape as the existing tool `{id,name,desc,endpoint,method,body,expect|expectArray|check}`, `apiUrl` input (default `http://localhost:3001`), sequential runner, pass/fail/warn/skip tiles, text report export.
4. **Headless QA runner** `qa/run-qa.mjs` (node ≥ 18, no deps): runs the same test table against a live server and exits non-zero on failure — used by `qa/run-all.ps1` which builds, runs unit + integration tests, starts the API in simulation, runs the headless QA, and prints a summary.

# sCureBox API contract (ported from the Python/Flask backend)

This is the HTTP contract the existing React UI depends on. The C# backend must reproduce it
byte-for-byte in JSON field names (camelCase) and semantics. Source of truth for the original
behaviour: `sCure-A/server/app.py`, `server/io_bridge.py`.

Server: bind `0.0.0.0`, port `PORT` env (default **3001**). CORS wide open. No SSE/WebSocket; the UI polls.
UI polls `/api/state` every 1000 ms, posts telemetry every 5 s, alert summary every 30 s.

## Conventions
* Almost every endpoint returns **HTTP 200** even on logical failure: `{"ok": false, "code": <int>, "message": "<str>"}`.
  Exceptions (non-200): `GET /api/materials/presets` → 503 without DB; `POST /api/cure-runs/{id}/phase` → 400;
  `GET /api/cure-runs/{id}/report` → 404; `POST /api/cloud/config` → 400; `POST /api/dev/led-calibration` → 400;
  `POST /api/dev/led-power` → 400; `GET /api/system/update/manifest|package` → 404; UI catch-all → 404.
* Command endpoints take **query-string** parameters. Boolean parsing: `on` is true unless value ∈ {"0","false","off"}
  (for `/api/cure/uv-only` and `/api/cure/stop` the set is {"0","false",""}; "off" counts as true there — keep for fidelity).
* Hardware refusal helper `_hw_result`: success → `{ok:true, message}`; refusal → `{ok:false, code, message}` where the
  default code is **6015**, but if the reason starts with `"[NNNN] "` that code is used and the prefix stripped (9001/9002/9003 arrive this way).

## 1. State
`GET /api/state` → HardwareState (superset; nulls allowed):
```
chamberTemp: number|null, targetTemp: number|null, internetOk: bool|null, doorClosed: bool|null (null = unreadable),
doorAborted: bool, isHeating: bool, isCooling: bool, coolingMode: "fast"|"medium"|"slow"|null, uvOn: bool,
uvIntensity: int (logical system power %), uvWavelength: 405|450|null, uvOutputs: {back,door,left,right}|null,
ventOn: bool, damperOpen: bool|null, damperDriver: "pio"|"lgpio"|null,
fans: {led_cooling:int, chamber_intake:int, chamber_heating:int} (commanded duty %),
fanRpm: {led_cooling, chamber_intake, chamber_heating} (worst/min RPM of group),
fanRpmEach: {FAN_HEATER,FAN_DOOR,FAN_RIGHT,FAN_LEFT,FAN_BACK,FAN_COOLING}: int,
fanOverride: string[], stripMode: string|null, uiAlerts: {critical,warning,at}|{},
ledTemps: {left,right,back,door,left2,right2}: number|null,
nitrogenActive: bool, n2Pressure: {volts,mpa,bar,on,saturated,mode,setPointMPa}|null, n2LinePressure: number|null,
bofaOn: bool, atTemp: bool, heaterPwm: number (0 when idle), heaterOut: bool (false when idle), coolingRate: number|null, coolingFanPwm: int|null,
faults: {heater: string|null, cooling: string|null, led: string|null},
sensors: {chamber,left,right,back,door: {sensor: string, ok: bool, openSec: int|null, critical: bool}},
fanHealth: {FAN_*: {duty,rpm,expected,deficitPct,status,since}}  status ∈ idle|ok|warn|critical|warn-pending|critical-pending|overridden,
ledChecksEnabled: bool (components.json led_heating.enabled, default false; false = no 9004 / 9005 and no UI LED heat check),
ledHealth: {LED_LEFT,LED_RIGHT: {lit,intensity,baseline,rise,litSec,status,peak?,drop?}} status ∈ off|low|warming|ok|fail|drop|no-sensor,
alerts: int[] (sorted active error codes), alertDetails: {"<code>": "<detail>"},
hwSource: "io_controller"|"simulation",
counters: {led405,led450,coolingFan,heater,heaterFan} (hours, 1 decimal),
cloudSync: {enabled: bool, lastSyncOk: number|null, error: string|null},
nfcEnabled: bool, nfcReader: {detected,port,model,serial,usbId,seenSinceBoot}
```
When NFC is enabled but the reader is unplugged, add 9052 to `alerts` and `alertDetails["9052"]`.
Simulation mode fixed values: `n2LinePressure: 6.0`, `n2Pressure: {volts:1.75,mpa:0.6,bar:6.0,on:true,saturated:false,mode:"analog_voltage",setPointMPa:0.6}`,
fanRpm 2850 when duty>0 else 0, ledTemps = chamber + {left:+1.5,right:+2.0,door:+0.5,back:+1.0,left2:+1.4,right2:+2.1}.

`GET /api/nfc` → `{ok:true, enabled, reader:{detected,port,model,serial,usbId}}`
`POST /api/nfc?on=1|0` → `{ok, message, enabled, reader}`; enabling with no reader → `{ok:false, code:9052, message:"No NFC reader detected - connect the reader (data USB cable) and try again", enabled, reader}`.
Reader detection = USB identity only (VID:PID 0483:5740 / `/dev/serial/by-id` name containing eccel|pepper), never opens the port. Env `SCURE_SIM_NFC=1` simulates a reader.

## 2. Network
`GET /api/network/status` → `{connected, ip, mac, gateway, interfaces:[{name,status:"UP"|"DOWN",ip}], internet, wireguardIp}`; on error add `code: 9084`, `connected:false`. `wireguardIp` (since 1.0.19) = the IPv4 of the up NetBird / WireGuard tunnel (`wt0`, `wg0` ...), `""` when the unit is not enrolled.
`ip` from eth0 only. `connected = hasIp && carrier`. `internet` from the background TCP-443 watch.
`POST /api/network/diagnostics` body `{tool:"ping"|"traceroute"|"nslookup", address}` → `{ok:true, result}`; unknown tool → `{ok:false, code:9080, result:"Unknown tool"}`; exception → `{ok:false, code:9085, result}`.
**Never pass `address` through a shell** — validate (hostname/IP regex) and exec with argument list. ping `-c 4 -W 3`, traceroute `-m 15 -w 3`, 45 s timeout.
`POST /api/network/static` body `{dhcp:bool, ip, gateway, subnet(default 255.255.255.0), dns}` → `{ok:true, message}`; off-Linux → `{ok:true, message:"Network config simulated (off-device)"}`; error → `{ok:false, code:9084, message}` (nmcli).

## 3. Materials
`GET /api/materials/presets` → Material[] (503 `{ok:false,message:"Database not configured (set DATABASE_URL)"}` without Postgres — the file store returns the built-in presets instead; **decision for the port: return the bundled presets from a JSON file, HTTP 200**).
`GET /api/materials/user` → Material[]. `POST /api/materials/user` body Material[] (full replace) → `{ok:true}`.
Material: `{id:string, name:string, isPreset:bool, createdAt:string, steps:CureStep[], totalDuration:int(min)}`.
CureStep: `{step:int, process:"Heating"|"Drying"|"Cure"|"Cooling"|"Bleacher"|"Nitrogen", temperature:number|null, intensity:number|null, time:number(min), uvIntensity?:number|null, timerMode?:"on-ramp"|"on-target", uvStartMode?:"at-start"|"at-target", uvRampPercent?:number, coolingMode?:"fast"|"medium"|"slow", ventilation?:bool}`.
`temperature:null` on Cure/Bleacher = UV-only (no heating).

## 4. Print history
`GET /api/print-history` → PrintLog[]; `POST /api/print-history` body PrintLog[] (full replace) → `{ok:true}`.
PrintLog: `{id, printName, materialName, printerName, date, duration:int(sec), status, steps:int, csvFile}`.

## 5. Cure runs
`GET /api/cure-history` → CureLog[]: `{id, materialName, steps, stepsCompleted, startedAt, endedAt, duration, status, phases[], targetTemp, sensorIssues[], fanIssues[], serialNumber, telemetry[]}` (newest first).
`POST /api/cure-runs/{extId}/start` body `{materialName, steps, phases[], targetTemp, serialNumber}` → `{ok:true}` (idempotent; inserts at index 0 with status "running", stepsCompleted 0, startedAt local `yyyy-MM-ddTHH:mm:ss`, telemetry []).
`POST /api/cure-runs/{extId}/telemetry` body `{t:int, chamberTemp, uvOn, uvType:"405nm"|"450nm"|null, fanRpm:{FAN_*}, ledTemps:{right,left,door,back}}` → `{ok:bool}` (false when unknown id). Side effect: note open sensors and worst fan deficits per run.
`POST /api/cure-runs/{extId}/finish` body `{status:"completed"|"aborted"|"error", stepsCompleted}` → `{ok, sensorIssues:[{sensor,critical}], fanIssues:[{fan,deficitPct,critical}]}`; computes duration.
`POST /api/cure-runs/{extId}/report` body `{content, summary, format:"html"}` → `{ok:true, reportId}`.
`GET /api/cure-runs/{extId}/report` → `{ok:true, content, summary, format}` or 404 `{ok:false, message:"No report"}`.
`POST /api/cure-runs/{extId}/phase` body `{program, step, process, targetTemp, plannedMin, startedAt, endedAt, seconds, rampSeconds, tempStart, tempEnd, coolingMode, intensity, timerMode}`; `process` and `seconds` required else 400 `{ok:false, message:"process and seconds required"}`; → `{ok:true, count}`. Appends to phase_timings.json.
`GET /api/phase-timings` → the array.
On load, runs left "running" by a power cut are rewritten to "error".

## 6. System
`POST /api/system/reboot` → `{ok:true, message:"Rebooting..."}` / off-device `"Reboot simulated"`.
`POST /api/system/shutdown` → `{ok:true, message:"Shutting down..."}` / `"Shutdown simulated"`.
`POST /api/system/datetime` body `{date:"YYYY-MM-DD", time:"HH:MM"|"HH:MM:SS"}` → `{ok:true,message}`; bad → `{ok:false, message:"Invalid date/time format"}` (200); timedatectl set-ntp false + set-time.
`GET /api/system/version` → `{appVersion, gitCommit, gitDate, lastBoot, os, kernel, python, emmcSerial}` (emmcSerial = `/sys/block/mmcblk*/device/serial` of the eMMC, e.g. `0x9d63faba`, null off-device; Settings shows it as Device) (nulls when unavailable; `python` may be replaced by the runtime version string, keep the key; add `runtime`).
`POST /api/system/export-logs` → `{ok:true, message:"Logs exported to USB"}` or `{ok:false, code:9083, message}`.
`POST /api/system/export-csv` body `{filename, content}` → `{ok:true, message, path}`; no USB → `{ok:false, code:9081, message:"No Disk-on-Key found. Please connect a Disk-on-Key (USB drive)."}`; write error → `{ok:false, code:9082, message}`. Basename-sanitised, `.csv` appended.
`POST /api/system/export-report` same with `.html`.
`GET /api/system/update/manifest` → `{ok:true, version, sha256}` or 404 `{ok:false, code:9081|9086|9087, message}`.
`GET /api/system/update/package` → raw .scu bytes (attachment) or 404 JSON.
`POST /api/system/update` → `{ok, steps:[{step,status:"running"|"ok"|"error"}], version, message, code?}`; without USB/package: code 9087 (no .scu) / 9081 (no USB) / 9086 (other). Package: tar containing `<name>.tar.gz` + `<name>.tar.gz.sig` (RSA-SHA256 over the inner tar.gz, public key `keys/scure-update.pub`), inner has `manifest.json` + `install.sh` (`--pre`, `--post`, `--rollback`).
`POST /api/cloud/config` body `{url,key,name?,interval?}` → 400 `{ok:false,message:"url and key required"}` or `{ok:true, message}`.

## 7. Direct hardware / diagnostics
`POST /api/door/open` → always `{ok:true, message:"Door opened"}`. UV off + heater stop, magnet on, release after 2.0 s. Simulation: door reads open 5 s then auto-recloses.
`POST /api/door-abort/ack` → `{ok:true, message:"Door abort acknowledged"}`.
`POST /api/fans/ack` → `{ok:true, message:"Fan alarm acknowledged: 9002 FAN_LEFT, 9003"}` - operator acknowledge of the fan alarms (the screen calls it when a 9002 / 9003 / 9051 alarm is deleted): releases the 9002 latch of every fan not failing right now and the 9003 pre-flight verdict; a fan driven and still failing stays latched (1.0.60).
`POST /api/chamber/temperature?target=` valid 30–80 else `{ok:false, code:7001, message:"Invalid target {t} (30-80°C)"}`; success `{ok:true, message:"Target set to {t}°C"}` or `{ok:false, message}` (manual heat → strip solid orange).
`POST /api/chamber/stop` → `{ok:true, message:"Heating stopped"}`.
`POST /api/rgb/alerts?critical=N&warning=M` → `{ok:true, critical, warning}`; reports older than 90 s are ignored by the strip.
`POST /api/rgb?on=0|1&color=` → `{ok, message}` (manual strip override; add this route — QA tool uses it).
`POST /api/fans/override?fan=<FAN_X|led_cooling|chamber_intake|chamber_heating|all>&on=1|0` → `{ok, message}`; unknown → `{ok:false, message:"unknown fan: X"}`.
`POST /api/fans/{fan}?speed=` → always `{ok:true, message:"{fan} set to {speed}%"}` (bridge may refuse silently: heater fan while heating, intake while cooling, LED fans during fast-cool boost).
`POST /api/damper/open|close` → `{ok:true, message:"Damper opened|closed"}`.
`POST /api/uv?on=&intensity=&wavelength=` → hw result; bad intensity → code 7002; bad wavelength → `{ok:false, message:"Invalid wavelength X (405|450)"}`.
`POST /api/bofa?on=` → hw result, message "BOFA on|off".
`POST /api/diagnostics/fan-test?fan=<group|all>` → `{ok:true, rpm:int(worst), status:"OK"|"FAIL", fans:{FAN_X:{rpm,status}}, message:string|null}`; unknown → `{ok:true, rpm:0, status:"FAIL", message:"unknown fan: X"}`. Real: 2 s spin-up at 100 % (skip fans a loop owns), measure all in parallel over 1 s, threshold 100 RPM. Simulation → `{ok:true, rpm:2850, status:"OK", fans:{...}}`.
`POST /api/diagnostics/led-test?seconds=15&min_rise=0.8&wavelength=405` → `{ok:true, status:"OK"|"FAIL", stage:"busy"|"sensors"|"uv"|"heating", seconds, wavelength, precooled, intensity, min_rise_c, results:[{name,start,temp,rise,status:"OK"|"FAIL"|"INFO"}], message}`. Refused while a process runs (stage "busy").

## 8. Cure operation endpoints (POST, query params)
Limits: HEAT_TARGET_MIN=30, TEMP_MAX=80, COOL_TARGET_MIN=20, UV_INTENSITY_MIN=10.
| Route | Query | Error | Success message |
|---|---|---|---|
| `/api/cure/heat` | target (60) | 30–80 else 7001 | `Heating to {t}°C` |
| `/api/cure/dry` | target (60) | 7001 | `Drying to {t}°C` |
| `/api/cure/cure-405` | target (60), intensity (30) | 7001 / 7002 (10–100) | `Cure UV 405nm @ {i}%, {t}°C` |
| `/api/cure/cure-450` | target, intensity | 7001 / 7002 | `Bleaching UV 450nm @ {i}%, {t}°C` |
| `/api/cure/uv-only` | intensity (30), wavelength (405), vent (0) | 7002; bad wavelength → message without code | `UV {wl}nm @ {i}% — no heating[, fresh-air vent]` |
| `/api/cure/cool` | target (25), mode (medium) | 20–80 else 7001; mode ∉ {fast,medium,slow} → 7003 | `Cooling ({mode}) to {t}°C` |
| `/api/cure/nitrogen` | on (1) | — | `Nitrogen valve opened|closed` |
| `/api/cure/stop` | immediate (0) | — | `All cure outputs stopped[ immediately]` always ok |
All except stop go through the hw-result helper (refusals 6015/9001/9002/9003).

Hardware actions per process (bridge semantics):
* heat/dry: sensor preflight; clear drying flag & dry fan; clear door abort; UV off; stop cooling; release vent; damper closed; heater start(target). Dry additionally: when at-temp first reached → damper open + intake fan 30 % (one-shot per step).
* cure-405/450: preflight; stop cooling; release vent; damper closed; heater start(target) AND uv on(intensity, wavelength); errors joined with "; ".
* uv-only: preflight; stop cooling; heater stop; uv on; then ventilation(vent) = damper open + intake fan 60 % (failure logged, never blocks).
* cool: preflight; clear drying; release vent; duty from mode (fast 100 / medium 60 / slow 30); on fresh entry only: UV off + heater shutdown (no run-on); start cooling(pwm, target); damper open; fast mode → 4 LED fans 100 %.
* nitrogen: GPIO13 solenoid; opening clears a stale door-abort latch.
* stop: UV off, N2 closed, cooling stopped, LED boost released, vent released, heater stop (element off, fan run-on continues), damper closed.

## 9. Developer mode
`POST /api/dev/log` body `{event (≤200 chars), detail}` → `{ok:true}` (append JSON line `{ts,event,detail}` to dev_events.jsonl).
`GET /api/dev/led-calibration` → `{ok:true, factors:{back,door,left,right}}`.
`POST /api/dev/led-calibration` body `{factors}` each 0.0–1.5 → `{ok:true, factors}` or 400 `{ok:false, message:"Invalid factors: …"}`.
`POST /api/dev/led-calibration/reset` → `{ok:true, factors:{1.0…}}`.
`POST /api/dev/led-power` body `{power:0-100, factors?}` → `{ok, message, outputs:{back,door,left,right}}`; 400 on invalid; 200 `{ok:false, message:"HDT calibration is running - abort it first"}` while HDT owns the LEDs; power ≤ 0 → UV off else 405 nm at that power.
`GET /api/dev/picolog/status` → `{connected, ch1Available, temperature, deviceInfo, error}`.
`POST /api/dev/hdt/start` body `{hdtC, safetyMarginC?, samplingIntervalSec?, movingAverageWindowSec?, stabilityBandC?, stabilityTimeMin?, stabilityMaxRateCPerMin?, maxStabilizationTimeMin?, nextStepMaxTempDeltaC?, cooldownMaxWaitMin?, boostPower?, boostStartTempC?}` → `{ok, message}`. Refusals: "HDT calibration already running", "Invalid material HDT {x} (30-200degC)", "PicoLog TC-08 CH1 has no valid temperature - …", "A cure process is active - stop it before HDT calibration".
`POST /api/dev/hdt/abort` → `{ok:true, message:"Abort requested - LEDs off"}`. `POST /api/dev/hdt/reset` → `{ok, message:null|"Calibration is running"}`.
`GET /api/dev/hdt/status?samplesFrom=N` → `{state, running, finalStatus, message, hdtC, safetyMarginC, currentPower, stepIndex, totalSteps(9), rawTemp, rateCPerMin, avgTemp, stepElapsedSec, totalElapsedSec, startedAt, endedAt, picolog{}, factors{}, outputs{}, results[{power,status,startTemp,stableTemp,minTemp,maxTemp,timeToStabilitySec,durationSec,rateCPerMin,startedAt,endedAt,outputs}], recommendedPower, boost{power,startTempC,targetTempC,timeSec,method,note}, maxMeasuredTemp, heaterFanPwm, config{…,powerLevels[]}, sampleCount, samples?[{t,raw,avg,power,step}]}`.
`GET /api/dev/hdt/report.csv` → text/csv attachment `hdt-calibration.csv`.
HDT state machine: IDLE → STARTING_CALIBRATION → [PREPARING_POWER_LEVEL → TESTING_POWER_LEVEL → WAITING_FOR_STABILITY → STABLE|NOT_CONVERGED]×9 (10..90 % @405 nm) → CALIBRATION_COMPLETE | HDT_LIMIT_REACHED | ABORTED | SENSOR_ERROR. 1 Hz; 10 s moving average; stable = window max−min ≤ 2.0 °C for 5 min AND |slope| ≤ 0.5 °C/min; timeout 30 min → NOT_CONVERGED; avg ≥ hdtC → HDT_LIMIT_REACHED; heater fan held 100 % (re-asserted every 5 s); recommendedPower = highest PASS with stableTemp ≤ hdtC − margin (2.0).

### 9a. DVT bench - StarBright on the machine's USB (same JSON as sCure-A server/uv_sweep.py)
`GET /api/dvt/meter` -> `{ok, present, transport, path, firmware, instrument, head, head_type, units, unit_name, ranges, range_in_use, wavelengths, measurement_mode, wavelength_nm, errors, reading_mw_cm2, message}`; no meter -> `{ok:false, present:false, message}` ("no Ophir StarBright on USB - …", "libusb-1.0 is not installed on the machine …"). While a sweep or the UV-off timing holds the meter the last identity comes back with `message: "the meter is in use by <owner>"` (the USB device is never opened twice); the identity is read once and kept - a status read is wavelength + reading, `?identify=1` re-reads it. All meter access is serialized (10 s wait). Never a USB reset (on this meter it is one-way: a reset stuck StarBright failed to enumerate at all): an I/O / pipe error reports the meter as stuck at once and fails the rest of that conversation fast; a meter gone after that is reported as dropped off the bus.
`POST /api/dvt/meter/wavelength?nm=405|450` -> `{ok, wavelength_nm (read back), message}`; refused while a sweep runs.
`POST /api/dvt/uv-sweep?wavelength=405|450&steps=30,40,…,100&dwell=10&baseline=5&settle=5&tail=3&hz=5&force=0` -> `{ok, message, code, meter_wavelength_nm, meter_wavelength_verified}`. Refusals: already running, wavelength not 405/450, steps outside 10-100, a process active (heating / cooling / UV), HDT calibration running, door open, meter unreachable, meter set to another wavelength (`code:"METER_WAVELENGTH"`, unless `force=1` - then recorded unverified).
`GET /api/dvt/uv-sweep?samples=0|1` -> `{ok, running, status (IDLE|RUNNING|OK|INCOMPLETE|ABORTED|ERROR), phase (idle|starting|baseline|step|tail|done), config{wavelength,steps,dwell,baseline,settle,tail,hz}, samples[[t_s, mW/cm2|null, intensity, phase, led_max_c|null, uv_on]] (or n_samples), steps[{intensity, mean_mw_cm2, sd_mw_cm2, n, dwell_s, led_max_c}], error, aborted, started, finished, elapsed, step_index, intensity, reading, meter{}, meter_wavelength_nm, meter_wavelength_verified, dark_mw_cm2}`.
`POST /api/dvt/uv-sweep/abort` -> `{ok:true, message}`: a running sweep stops with the LEDs off; without one nothing is touched ("no sweep running" - the UV may belong to a cure).
`POST /api/dvt/uv-off?wavelength=405&intensity=100&stable=2&open_timeout=30&tail=3&alarm_watch=15&hz=20&force=0` (DVT-SAF-012 step 2) -> `{ok, message, code, meter_wavelength_nm, meter_wavelength_verified}`; refused like the sweep, plus the door must be closed and no program running; shares the DVT bench with the sweep (one at a time). Sequence on the machine's clock: 1 s dark -> a real UV-only cure program (Cure 405 / Bleacher 450, 10 min, `intensity`) until the StarBright is stable within 2 % for `stable` s -> the machine's own open-door command (switches the UV off, releases the lock for 2 s) -> the door sensor and the StarBright sampled at `hz` until the door opens (`open_timeout`) and the reading is below 10 % of the plateau -> `tail` s -> `alarm_watch` s more -> the program's state and the alerts are captured, the program aborted, LEDs off.
`GET /api/dvt/uv-off?samples=0|1` -> `{ok, running, status, phase (dark|plateau|open_door|decay|tail|alarm_watch|done), mode (program|direct), dark_mw_cm2, plateau_mw_cm2, release_at_s, release_ok, door_open_at_s, below_10pct_at_s, uv_off_time_s (door open -> below 10 %, 0 when the UV was already off), uv_off_before_door_open, release_to_off_s, zero_threshold_mw_cm2 (dark + max(0.5 % of the lit level, 3 sd dark noise, 0.01)), zero_at_s, uv_zero_time_s (door open -> back at zero for 0.5 s), release_to_zero_s, residual_mw_cm2, program_end{state,message,error_code}, alerts_before[], alerts_after[], alert_details{}, door_aborted, ui_alerts[], samples[[t_s, mW/cm2, door_open, phase]] | n_samples, error, meter{}}`. `POST /api/dvt/uv-off/abort`.
Simulation finding (no screen running): after the open-door command the program stays `running` with no alert - the door-abort (6016) lives in the screen's countdown, so on the unit `alarm_watch` must cover it.

Sweep: LEDs off `baseline` s (dark), each step lit `dwell` s with the meter read at `hz`, step value = mean of its last `settle` s, LEDs off `tail` s and on abort / error. The door opening or the LEDs going off during a lit step stops the sweep with an error - that step is discarded, never recorded dark. Real meter: libusb-1.0 (`libusb-1.0.so.0`), vendor 0x0BD3, Ophir ASCII commands in control transfers (OUT 0x40 req 2 / IN 0xC0 req 4); the service runs as root, so no udev rule. `SCURE_SIM_METER=1` = simulated meter (0.9 / 0.5 mW/cm2 per % at 405 / 450 nm).

Bench lock from outside: `GET /api/dvt/bench` -> `{ok, owner}`; `POST /api/dvt/bench/claim?who=&lease_s=30` (1..300 s; the same `who` renews) -> `{ok, owner, lease_s, message}` or `{ok:false, message:"the DVT bench is busy (…)"}`; `POST /api/dvt/bench/release?who=`. A leased hold expires by itself when not renewed; the firmware's own tools (uv-sweep, uv-off) hold it without a lease.

### 9b. DVT bench process (`scurebox --dvt-bench`, scurebox-dvt-bench.service, port 3002)
A separate process from the firmware that runs a whole DVT catalog test on the machine's clock, with the TC-08 in its own hands (the firmware releases it: `POST /api/dev/picolog/release` / `.../resume`; `GET /api/dev/picolog/status` then says `released to the DVT bench`). Talks to the firmware over its API on 127.0.0.1:3001.
`GET /bench/status` -> `{ok, version, simulated, tests[], firmware_alive, firmware_version, run{…}}`.
`POST /bench/run?test=DVT-SAF-004&heat_target=80&hz=5&operator_timeout=180&cut_timeout=90&cooldown_max=1200&cooldown_below=60` -> `{ok, message}`; refused while a run is in progress, for an unknown test, when the firmware does not answer or a program is running.
`GET /bench/run?samples=0|1` -> `{test_id, running, status (IDLE|RUNNING|OK|ERROR|ABORTED), phase, prompt (what the operator must do now, or null), started, finished, elapsed, error, aborted, values{catalog field: value}, marks{name: t_s}, notes[], phases[{name, from_s, to_s}], columns[], samples[[t_s, ch1_c, cold_junction_c, meter_mw_cm2, fw_alive, heating, uv_on, chamber_c, chamber_sensor_ok, phase, ch2_c]] | n_samples, last, config, tc08, meter}` (ch2_c = the reference thermocouple in the chamber on TC-08 CH2, null when none is plugged in).
`POST /bench/run/abort?by=` -> outputs off, the run ends ABORTED.
DVT-SAF-004 phases: prepare (CH1 far above the cold junction with nothing running is watched 3 s: steady = a body still hot from an earlier test, a jump > 5 C = open probe, refused) -> cooldown (chamber or heater body above 60 C) -> heating_wait_rise (body slope >= 0.05 C/s over 10 s) -> prompt_disconnect (until the firmware's chamber sensor reads open) -> watch_cut (rise-to-fall turn, 0.5 C hysteresis; alarm 9001 tracked) -> inhibit (+10 s watch) -> prompt_reconnect -> watch_resume (20 s). Values: disconnect_timestamp, heater_temp_at_disconnect, heater_body_drop_observed, heater_off_time, heater_temp_peak, alarm_raised, time_to_alarm_s, error_code, alarm_text, alarm_text_instructs_reconnect, heat_start_inhibited, heat_command_reply, recovery_requires_ack, alarm_cleared_after_reconnect, test_method. Every exit path: outputs off via the firmware (or `scurebox --watchdog --cut-now` when it does not answer), TC-08 closed and resumed.
Recorder (any test script): `POST /bench/record/start?label=&tc08=1&meter=0&hz=5&max_s=10800` -> `{ok, message}` (TC-08 taken from the firmware with the same handshake; refused while a bench run or another recording holds the bench); `POST /bench/record/mark?name=` stamps an instant (rows carry the last mark as `phase`); `POST /bench/record/stop`; `GET /bench/record?samples=0|1&from=N` -> `{running, status (IDLE|RUNNING|OK|ERROR), label, phase, config, started, finished, elapsed, error, tc08, meter, clock, t0_unix, marks{name: t_s}, events[[t_s, name]], notes[], columns[], n_samples, from, samples[...], last}` - same columns as a bench run. Clock: `t_s` is seconds on the bench's clock since `started` (= `t0_unix`), for rows, marks and events alike. `events` are the recorder's own marks - firmware state changes it saw between two samples: `heating_on|off`, `uv_on|off`, `chamber_sensor_open|ok`, `door_open|closed`, `door_abort`, `alert_<code>`, `alert_<code>_cleared`, `fw_dead|alive`. A firmware restart shows as rows with `fw_alive` false and the recording continues. CH1 more than 60 C above the cold junction while nothing heats and no UV is on is an open thermocouple: recorded as null with a note (a bench run refuses to start on one). `meter=1` claims the firmware's DVT bench lock first (`POST /api/dvt/bench/claim?who=DVT bench recording&lease_s=30`, renewed every 10 s, released at the end) so the firmware's `/api/dvt/meter`, uv-sweep and uv-off never open a second handle on the StarBright; while a firmware DVT tool holds the lock the recording ends ERROR "the StarBright is in use by the firmware".
`SCURE_SIMULATE=1`: simulated machine and instruments; `POST /bench/sim/sensor?open=1|0`, `POST /bench/sim/heat?on=1|0`, `GET /bench/sim`.

## 10. Static UI
`GET /` and `GET /{**path}` → serve `dist/<path>` if it exists else `dist/index.html` (SPA fallback); if no build: 404 `{ok:false, message:"UI not built"}`. `/api/*` always wins. The UI's own base URL is `http://localhost:3001/api` (absolute), so CORS must stay open.

## 11. Static config assets served from dist/config
`errors.json` (central registry, 46 records: `{code,key,severity,category,layer,message,description,troubleshooting[],supportUrl}`), `system.json`, `versions.json`.

## 12. Error codes the backend must emit
6015 generic hardware/pre-cure refusal, 6016 door abort, 7001 invalid temperature, 7002 invalid intensity, 7003 invalid cooling mode,
9001 required temperature sensor open (critical), 9002 fan critical (≥20 % below nominal), 9003 LED fan - or, since 1.0.62, the chamber cooling fan FAN_COOLING - not spinning at pre-flight (the LED fans before UV, the chamber fan before a drying or cooling step),
9006 heater reading frozen - moved < 0.1 C in 90 s with the heater at ≥ 50 % output (critical; heater off at once, HEAT refused until the reading moves ≥ 1 C or goes open - the latch is kept in data/frozen_reading.json across the restart the machine gives itself 60 s after the alert; components.json frozen_reading),
9004 LED panel not heating, 9005 LED panel temperature drop, 9050 optional sensor open (warning), 9051 fan wear warning (≥10 %),
9052 NFC reader not detected, 9080 unknown diag tool, 9081 no USB, 9082 USB write failed, 9083 log export failed, 9084 network error,
9085 diag exception, 9086 update failed, 9087 no update package, 9089 (UI only: API unreachable).

## 13. Persistence (data dir `SCURE_DATA_DIR`, default `<app>/data`)
Atomic writes (tmp + fsync + rename): `user_materials.json`, `print_history.json`, `cure_history.json` (telemetry flushed every 15 samples),
`cure_reports.json` `{extId:{content,summary,format}}`, `phase_timings.json`, `component_counters.json` (seconds), `led_calibration.json`,
`nfc.json` `{enabled}`, `dev_events.jsonl`, `cloud.json`. Optional Postgres when `DATABASE_URL` is set (schema in `deploy/db/schema.sql`).
Component ON-hour counters sample every 2 s, flush every 60 s and at exit: led405/led450 = UV on at wavelength; heater = heaterOut → heaterPwm>0 → isHeating; heaterFan/coolingFan = tach RPM>0 → commanded duty.
Cloud sync (outbound only, every `interval` s, floor 3): POST `{name, state{chamberTemp,doorClosed,isHeating,isCooling,uvOn,internetOk,counters}, programs, prints[:20], cures[:10 w/o telemetry], ackIds}` to `<url>/api/agent/sync` with `X-Machine-Key`; apply data-only commands `upsert_program|delete_program|send_print`, ack ids next sync.

## 14. Version
`appVersion` from the `VERSION` file next to the app (fallback assembly version); `gitCommit`/`gitDate` optional; `lastBoot` from `uptime -s`; `os` from /etc/os-release PRETTY_NAME; `kernel` from `uname -r`.

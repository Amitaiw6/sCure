# Package manifest

Generated 2026-10-11 by `qa_package.py`.

## 01-working-rules/

Claude Code project-memory notes that acted as standing instructions (process-relevant ones only; files with machine addresses / credentials left out).

| File | Bytes |
|---|---|
| `01-working-rules/feedback_bash_backslashes.md` | 1,278 |
| `01-working-rules/feedback_no_rpm_damper_check.md` | 1,010 |
| `01-working-rules/feedback_pi_bench_scripts.md` | 2,238 |
| `01-working-rules/feedback_qa_tests.md` | 798 |
| `01-working-rules/feedback_reply_in_hebrew.md` | 827 |
| `01-working-rules/feedback_shutdown_proof.md` | 1,409 |
| `01-working-rules/feedback_srs_authoring.md` | 2,030 |
| `01-working-rules/feedback_ui_consistency.md` | 1,087 |
| `01-working-rules/feedback_version_bump.md` | 1,201 |
| `01-working-rules/feedback_worktree_junction.md` | 1,170 |
| `01-working-rules/project_error_registry.md` | 2,471 |
| `01-working-rules/project_parallel_sessions.md` | 2,332 |
| `01-working-rules/project_srs_diagrams.md` | 1,245 |
| `01-working-rules/project_ui_english_conventions.md` | 1,573 |
| `01-working-rules/project_versioning.md` | 1,142 |

## 02-port-specs/

sCureBox-CS specs that drove the port (01-05), the descriptive SRS (06) and the repo README.

| File | Bytes |
|---|---|
| `02-port-specs/01-api-contract.md` | 29,628 |
| `02-port-specs/02-hardware-map.md` | 15,375 |
| `02-port-specs/03-ui-and-qa.md` | 4,602 |
| `02-port-specs/04-ui-spec.md` | 118,542 |
| `02-port-specs/05-native-ui.md` | 8,301 |
| `02-port-specs/06-srs.md` | 56,567 |
| `02-port-specs/sCureBox-CS-README.md` | 2,270 |

## 03-qa/

QA harnesses: sCureBox-CS live-API suite (README, run-all.ps1, run-qa.mjs, qa-tests.js) and the sCure-A browser QA tool.

| File | Bytes |
|---|---|
| `03-qa/README.md` | 4,155 |
| `03-qa/qa-tests.js` | 60,864 |
| `03-qa/run-all.ps1` | 8,307 |
| `03-qa/run-qa.mjs` | 4,182 |
| `03-qa/sCure-A-qa-tool.html` | 395,938 |

## 04-versioning/

sCureBox-CS changelog (versions.json, newest first) and the central error registry (errors.json).

| File | Bytes |
|---|---|
| `04-versioning/sCureBox-CS-errors.json` | 37,264 |
| `04-versioning/sCureBox-CS-versions.json` | 174,868 |

## 05-original-repo-bmad/

Everything BMAD-related from origin_hw-main.zip (SW_BR_EMB 0.4.9): CLAUDE.md, AGENTS.md, settings, BMAD manifest + team customizations, the 5 planning artifacts, the list of 49 installed skills.

| File | Bytes |
|---|---|
| `05-original-repo-bmad/AGENTS.md` | 5,825 |
| `05-original-repo-bmad/CLAUDE.md` | 1,719 |
| `05-original-repo-bmad/_bmad-custom/bmad-agent-architect.toml` | 768 |
| `05-original-repo-bmad/_bmad-custom/bmad-agent-dev.toml` | 767 |
| `05-original-repo-bmad/_bmad-custom/bmad-build.toml` | 4,389 |
| `05-original-repo-bmad/_bmad-custom/bmad-code-review.toml` | 2,566 |
| `05-original-repo-bmad/_bmad-custom/bmad-review.toml` | 916 |
| `05-original-repo-bmad/_bmad-custom/config.toml` | 348 |
| `05-original-repo-bmad/_bmad-manifest.yaml` | 500 |
| `05-original-repo-bmad/_bmad-output-planning-artifacts/deferred-findings.md` | 3,311 |
| `05-original-repo-bmad/_bmad-output-planning-artifacts/final-review.md` | 20,100 |
| `05-original-repo-bmad/_bmad-output-planning-artifacts/performance-review.md` | 23,389 |
| `05-original-repo-bmad/_bmad-output-planning-artifacts/qa-report.md` | 4,045 |
| `05-original-repo-bmad/_bmad-output-planning-artifacts/refactor-architecture-plan.md` | 37,145 |
| `05-original-repo-bmad/bmad-skills-installed.txt` | 947 |
| `05-original-repo-bmad/claude-settings.json` | 312 |
| `05-original-repo-bmad/project-context.md` | 16,977 |

## 06-examples/

Before/after screenshots of four recent changes (README section 7).

| File | Bytes |
|---|---|
| `06-examples/screenshots/1a-dropdown-before-clipped.png` | 264,534 |
| `06-examples/screenshots/1b-dropdown-after-floating.png` | 240,271 |
| `06-examples/screenshots/2a-precheck-before-overlapping-fades.png` | 328,833 |
| `06-examples/screenshots/2b-precheck-after-holds-spinner.png` | 221,695 |
| `06-examples/screenshots/2c-precheck-after-cure-page-already-running.png` | 114,173 |
| `06-examples/screenshots/3-cure-history-delete.png` | 112,657 |
| `06-examples/screenshots/4-drying-wind-icon.png` | 114,996 |

## Root

| File | Purpose |
|---|---|
| `README.md` | The write-up |
| `MANIFEST.md` | This list |
| `QA-REPORT.md` | Result of the package checks |
| `qa_package.py` | The checks themselves |
| `redact.py` | Redaction applied to the copied files |
| `qa_count_tests.mjs` | Counts QA tests by loading the real test tables |

---
name: project-srs-diagrams
description: Diagram conventions and render pipeline for the sCure Box SRS (docs/sCure_SRS.html)
metadata:
  type: project
---

In docs/sCure_SRS.html, each screen section has its diagrams built this way:

- **Activity / flow diagrams** → **draw.io** swimlanes (lanes ordered **Storage | UI sCure | Cloud**, UI in the middle so no connector crosses a third lane). Success ends in a filled final node (●), errors in a red ✗ node. Source: `docs/diagrams/<name>.drawio` (manually drag-editable, the user's preference). Render: `node tools/drawio-to-svg.mjs <in.drawio> <out.svg>` then `node tools/svg-to-grid-png.mjs <out.svg> <out.png>` (PNG has a draw.io-style grid background; this PNG is what the doc embeds).
- **Sequence diagrams** → **PlantUML** (`docs/diagrams/<name>.puml`). Render via `node tools/puml-url.mjs <file.puml>` → curl the PNG URL to `docs/screenshots/<name>.png`. The doc embeds the PNG and links the PlantUML editor URL.

Rendering requires Chrome at `C:\Program Files\Google\Chrome\Application\chrome.exe` and internet (draw.io viewer CDN + plantuml.com). The user edits the `.drawio` directly in VS Code via the *Draw.io Integration* extension. Related: [[feedback-srs-authoring]].

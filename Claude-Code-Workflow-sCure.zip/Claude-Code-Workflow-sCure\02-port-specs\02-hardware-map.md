# sCureBox hardware map (CM5 on IO board BRD-74205 rev07)

Ported from `sCure-A/io_controller/io_controller.py` (+ `components.json`, `io_bridge.py`, `pio_servo.c`).
The C# hardware layer must reproduce the register sequences and polarities below.

## Buses / chips
| Chip | Ref | Linux bus | Addr | Role |
|---|---|---|---|---|
| PCA9685 | U15 | `/dev/i2c-0` | 0x55 | 16-ch 12-bit PWM: fans, heater, LEDs, motors, BOFA |
| TCA6424A | U1 | `/dev/i2c-0` | 0x23 | 24-bit I/O expander: LED_SWITCH relay, valves/door magnet, motor dir, NFC reset |
| ADS1115 | U6 | `/dev/i2c-0` | 0x49 | NTCs right/left |
| ADS1115 | U7 | `/dev/i2c-1` | 0x49 | NTCs back/door/chamber + N2 pressure on AIN3 |
| ADS1115 | U8 | `/dev/i2c-0` | 0x48 | analog sensors (unused by app) |
| ADS1115 | U10 | `/dev/i2c-1` | 0x48 | light sensors (unused by app) |
i2c-0 = GPIO0/1 (needs `dtparam=i2c_vc=on`), i2c-1 = GPIO2/3 (`dtparam=i2c_arm=on`). One global I²C lock across all chips.

## PCA9685 (0x55)
Registers: MODE1=0x00, MODE2=0x01, PRESCALE=0xFE, LED0_ON_L=0x06; SLEEP=0x10, AI=0x20, RESTART=0x80.
Init: write MODE1=0x20 (AI on, awake); write MODE2=0x04 (totem pole, INVRT off); sleep 1 ms. Frequency: default prescale (~200 Hz); `SetFrequency(hz)` = read MODE1; write (old&0x7F)|SLEEP; PRESCALE=clamp(round(25e6/(4096*hz))-1,3,255); write old; sleep 5 ms; write old|RESTART|AI.
Channel write: block at 0x06+4*ch of [on&0xFF, on>>8, off&0xFF, off>>8]. Full-on = (0x1000,0); full-off = (0,0x1000); partial = (0, eff/100*4095).
`SetDuty(ch, pct)`: clamp 0..100; `LastDuty[ch]=pct` (load-bearing: fan supervisor reads it); if ch ∈ DIGITAL {6}: pct = pct>0?100:0; eff = ch ∈ INVERTED {0,1,2,3,4,5,7,8,9} ? 100-pct : pct.
Read-back decode honours inversion; `SetDutyVerified` retries 3×.
| Ch | Name | Type | Inverted |
|---|---|---|---|
| 0 | FAN_HEATER | PWM fan (tach GPIO22) | yes |
| 1 | FAN_DOOR | PWM fan (tach 23) | yes |
| 2 | FAN_RIGHT | PWM fan (tach 24) | yes |
| 3 | FAN_LEFT | PWM fan (tach 19) | yes |
| 4 | FAN_BACK | PWM fan (tach 25) | yes |
| 5 | FAN_COOLING | PWM fan (tach 26) | yes |
| 6 | PWM_HEATER | SSR K3, digital only | no |
| 7 | LIGHT1 | chamber light | yes |
| 8 | MOT1_EN | L298N enable | yes |
| 9 | MOT2_EN | L298N enable | yes |
| 10 | BOFA | fume extractor 0/100 | no |
| 11 | LED_BACK | UV LED DIM | no |
| 12 | LED_DOOR | UV LED DIM (only LED allowed at 450 nm) | no |
| 13 | LED_RIGHT | UV LED DIM | no |
| 14 | LED_LEFT | UV LED DIM | no |
| 15 | LED_ANALOG5 | unused | no |

## TCA6424A (0x23)
Registers with auto-increment bit: INPUT=0x80, OUTPUT=0x84, CONFIG=0x8C (1=input). 3 bytes each (ports 0..2).
Safe init: build output shadow with every SAFE_HIGH|INVERTED pin high → block-write OUTPUT while pins are still inputs → config [0xFF,0xFF,0xFF] with mapped pins cleared → write CONFIG. (Power-on hazard: LED_SWITCH floats high = relay K4 engaged until driven.)
Pins: NFC_RESET P0.1 (active-low, safe HIGH); LED_SWITCH P0.5 (→ relay K4, LED_OUT1/2); FAN1..6_ONOFF P1.1..P1.6 (inverted, unused); MOT1_IN1 P2.5, MOT1_IN2 P2.4, MOT2_IN1 P2.2, MOT2_IN2 P2.1; DOOR_MAGNET = VALVE_2_ON P2.6; VALVE_1_ON P2.7.
`SetPin(name, logical)`: level = inverted ? !logical : logical; update shadow; block-write 3 output bytes; verify by reading INPUT. `NfcReset()`: low, 10 ms, high. `AllSafe()`: motors stop (0,0), valves closed, LED_SWITCH 0. Door magnet: energise, release after 2.0 s.

## ADS1115 ×4
Single-shot read: mux = 0b100+ch; config = (1<<15)|(mux<<12)|(pga<<9)|(1<<8)|(0b100<<5)|0b00011 (128 SPS, comparator off); write [hi,lo] to reg 0x01; poll ≤50× (2 ms) until reg1 byte0 & 0x80; read reg 0x00 → int16; volts = raw*FS[pga]/32768. FS = {0:6.144,1:4.096,2:2.048,3:1.024,4:0.512,5:0.256}. TEMP_PGA = 1 (U6/U7). ANALOG_PGA = 0 (U8/U10).
Temperature channels: TEMP_RIGHT_ORIGIN U6/0, TEMP_RIGHT U6/1, TEMP_BACK_ORIGIN U6/2, TEMP_LEFT U6/3, TEMP_LEFT_ORIGIN U7/0, TEMP_DOOR_ORIGIN U7/1, TEMP_CHAMBER U7/2, N2 pressure U7/3 (LEFT_ORIGIN and BACK_ORIGIN were crossed in the HSI until 2026-10-01: the Left origin probe is on U7/0, the Back origin on U6/2 - HSI, io_controller and this map corrected together).
NTC (Murata NCP21XV103J03RA, pull-up topology): R0=10000, BETA=3934, T0=298.15, R_SERIES=10000, VREF=3.3. v≤0 or v≥VREF → open (null). R = R_SERIES*v/(VREF−v); 1/T = 1/T0 + ln(R/R0)/BETA; °C = T−273.15. Valid range −20..120 °C.
TEMP_CHAMBER calibration (apply exactly): GAIN 1.0979, OFFSET −3.9813, LEAD 2.1873 °C per °C/min above deadband 0.3, COOL_COEF 0.0956 per °C above 25 with gate −1.0 °C/min → full −2.5 °C/min, RATE_WINDOW 45 s. est = GAIN*raw+OFFSET; keep (t,raw) window 45 s; if <3 samples or span <10 s → est; slope (least squares) ×60 = rate; rate>0.3 → est += LEAD*(rate−0.3); rate<−1.0 → f=min(1,(−1.0−rate)/1.5); est += f*COOL_COEF*(raw−25).

## GPIO (use /dev/gpiochip via System.Device.Gpio, not pinctrl)
| GPIO | Dir | Function | Polarity |
|---|---|---|---|
| 8 | out (PIO servo) | damper servo MG90S via inverting driver Q16 | electrically inverted |
| 12 | out (PIO serial) | RGB status strip TM1903/WS2811, 21 LEDs, order RGB | — |
| 13 | out | nitrogen solenoid valve | active high |
| 16 | out | 450 nm SSR enable (K1) | active high |
| 17 | out | wavelength routing line — keep LOW in both modes (HIGH kills door DIM 12 V rail) | — |
| 19,22,23,24,25,26 | in, pull-up | fan tachometers, 2 pulses/rev, open collector | rising edge count |
| 20 | out | 405 nm SSR enable (K2) | active high |
| 27 | in, NO pull (external R46) | door sensor; HIGH = closed, LOW = open (open_level 0) | read → true/false/null |
Boot safe: `gpio=16,17,20=op,dl` in config.txt.

## Servo (GPIO8) — PIO helper process `pio_servo` (C, built on the Pi against piolib)
Pulse: SERVO_INVERTED (logical flip): a = 180 − angle; pulse_us = 500 + a/180*1900 → logical 0° = 2400 µs, 90° = 1450 µs. Damper: open = 90° (1450 µs), closed = 0° (2400 µs) - reversed before 1.0.61. settle_sec 1.5 then release (stop pulses). Same-angle re-request while holding is skipped. Never drive GPIO8 via gpio while PIO owns it.
Helper protocol: spawn `pio_servo <gpio> [--inverted]`; wait ≤3 s for stdout line starting `READY`; commands `P <pulse_us>`, `R`, `Q`, each answered `OK`/`ERR …`. Fallback: software PWM 50 Hz duty = pulse/20000*100 (inverted → 100−duty). Report driver as "pio"/"lgpio".

## RGB strip (GPIO12) — PIO helper process `pio_rgb` (new, C, WS2811 800 kHz program, 24-bit GRB/RGB per LED)
Protocol: spawn `pio_rgb <gpio> <count> [--order RGB|GRB]`; `READY`; command `F <hex bytes 3*count>` → OK; `Q`. Colors: named (red FF0000, green 00FF00, blue 0000FF, white, yellow FFB400, orange FF5A00, purple AA00FF, cyan 00C8FF, pink FF2878, off) or RRGGBB/#RRGGBB.
Status ladder (evaluated every status_sec 1 s): driver fault → fault(red); UI critical>0 → fault; door-abort latched → fault; door open → door(ff7800); UI warning>0 → warn(yellow); manual heat → manual_heat(ff8c00 solid); any process → busy(purple comet, chase_sec 0.12, tail 5, direction rtl) or busy_no_net (solid blue); idle offline → no_net(blue); else normal(green). Blink half period 0.5 s. Internet check TCP 443 to www.google.com then 1.1.1.1, 2 s timeout, every 5 s. UI alert reports older than 90 s ignored. Colours/params hot-reloaded from components.json.

## Fan tachometers
Count rising edges; `MeasureRpm(fan, window)` = (Δcount/2)*(60/window) blocking; `ReadRpm(fan)` = delta since last call (null on first call). Group measurement in parallel. Nominal RPM table (duty→rpm): FAN_HEATER {100:3530, 80:2925, 50:1870, 30:915}; FAN_COOLING {100:4790, 60:2690, 30:1235}; FAN_LEFT/RIGHT/BACK/DOOR {100:3560}. Expected = linear interpolation; proportional below lowest / above highest.
Fan health: warn_below_pct 10, critical_below_pct 20, persist_sec 60, settle_sec 5, min_eval_duty 30, stopped_persist_sec 5 (rpm ≤5 % of expected), led_fan_min_rpm 100. Critical → 9002 + stop all + block starts; latch releases after 60 s OK. Override per fan (status "overridden").
LED-fan pre-flight: all LED fans 100 %, wait 1.5 s, measure 0.5 s, any <100 RPM → 9003 refuse; skipped while LEDs on and 30 s after a pass.

## Heating (PI + delta-sigma) — components.json heating
target_min 30, sample_sec 0.05, kp 0.22, ki 0.00015, kd 0, integ [0,0.85], at_temp_band 1.5, cooldown_sec 900, cooldown_fan_pwm 30. Heater: fan_pwm 100, min_fan_rpm 100, health_check_sec 10, thermistor TEMP_CHAMBER, temp_valid [−20,120].
Enable sequence: cooling not active; door confirmed closed; FAN_HEATER 100 %; thermistor valid; wait 2.0 s; measure RPM ≥ 100; then PWM_HEATER on.
Loop each 50 ms: integ=clamp(integ+ki*err); control=kp*err+integ+kd*(err−prev); power=clamp(control,0,1); delta-sigma: delta = last?power−1:power; sig=accum+delta; out=sig>0.5; last=out; accum=sig; write duty 100/0 only on change. Health every 10 s (fan rpm — confirm with a blocking 1 s measure before shutdown; thermistor immediate). Stop: element off now; fan run-on 30 % for 900 s then all fans off + damper closed. Shutdown: no run-on.

## Cooling — components.json cooling
damper open 90°, closed 0° (since 1.0.61); heater fan 100 % whole mode; FAN_COOLING fixed duty by mode fast 100/medium 60/slow 30; fast_led_fan_pwm 100; target 25; sample 1 s; window 30 s slope (telemetry only); auto-terminate at temp ≤ target → fans off, damper closed.
Other: DRY_INTAKE_FAN_PWM 30, VENT_FAN_PWM 60 (ventilation.fan_pwm), FAST_COOL_LED_FAN_PWM 100. UI fan groups: led_cooling=[FAN_LEFT,FAN_RIGHT,FAN_BACK,FAN_DOOR], chamber_intake=[FAN_COOLING], chamber_heating=[FAN_HEATER].

## LED power path
led_power: ssr_450nm GPIO16, ssr_405nm GPIO20, routing GPIO17, default_mode 405nm, switch_settle_sec 0.1, min_intensity 10, led_max_duty 60.
modes: 450nm {ssr_450:1, ssr_405:0, routing:0, led_switch:0}; 405nm {ssr_450:1, ssr_405:1, routing:0, led_switch:1}.
Turn-on order: LED_SWITCH relay (verified) → settle only if it moved → SSRs + GPIO17 → read GPIO17 back (mismatch = fail) → then DIM PWM. Mode change: all LEDs off first. LED_SWITCH rests at 0 when idle.
Brightness: on = pct ≥ min_intensity; duty = pct*60/100. Gate order: min-intensity → door confirmed closed → wavelength allowed → power applied → PWM + fan (LED fans at 100 % while lit). Per-zone factors 0..1.5 (led_calibration.json), physical = clamp(requested*factor).
LEDs: LED_LEFT ch14/FAN_LEFT, LED_RIGHT ch13/FAN_RIGHT, LED_BACK ch11/FAN_BACK (405 only); LED_DOOR ch12/FAN_DOOR (405+450).

## N2 pressure (SMC ISE20, U7 AIN3)
mode analog_voltage; ISE20A-T-01 datasheet 'Analogue Output' points A/B/C: 0.6 V = −0.100 MPa, 1.0 V = 0 MPa, 5.0 V = 1.000 MPa (4 V per MPa; 6 bar = 3.4 V) - components.json p_at_v_min_mpa 0.0 / p_at_v_max_mpa 1.0 (the old p_min_mpa −0.1 is not read; before 1.0.35 it made 1 V read −1 bar); divider 1.0; adc_saturation 3.2 V (saturated → mpa null); set_point 0.6 MPa; bar = mpa*10; on = mpa ≥ set_point (or saturated). Switch mode: on = v ≥ 2.0.

## Door interlock
door_sensor gpio 27, open_level 0, abort_after_sec 10. Door open while LEDs/heater on → force off. Watchdog (1 s): door open AND any output live for 10 s → door_abort: heater shutdown (no run-on), stop all, fans 0, BOFA off, latch doorAborted (6016) until ack or next process start. Unreadable (null) is never treated as open.

## Sensor supervision
Required (critical 9001): TEMP_CHAMBER→chamber, TEMP_LEFT_ORIGIN→left, TEMP_RIGHT_ORIGIN→right. Warning (9050): TEMP_BACK_ORIGIN→back, TEMP_DOOR_ORIGIN→door. Open continuously 60 s → alert; TEMP_CHAMBER open while heating → 9001 immediately (detail "Heater temperature sensor (chamber NTC TEMP_CHAMBER) is not reading - the heater is off"). Preflight: 3 reads 0.5 s apart; refuse "[9001] Temperature sensor disconnected: Chamber (TEMP_CHAMBER), Left LED panel (TEMP_LEFT_ORIGIN) - reconnect the sensor before starting a process". The 9001 / 9050 detail names every open sensor of its class by place (Chamber, Left / Right / Back / Door LED panel) and is rebuilt every pass, so a recovered sensor drops out; with the chamber open it keeps the heater wording and adds "; also not reading: …". Fan alerts name the fans the same way: 9002 and 9051 list every fan they hold ("Left LED fan (FAN_LEFT): 0 RPM measured, …", joined by "; "), 9003 lists every LED fan that did not spin. The fan ID stays in the text because the Cure screen finds failed fans by it.
LED heating supervision: panels LED_LEFT→TEMP_LEFT, LED_RIGHT→TEMP_RIGHT; min_eval_intensity 30, check_after_sec 90, min_rise_c 1.0, rest_sec 120, drop_c 1.0, drop_persist_sec 30, drop_settle_sec 120 → 9004 / 9005.

## Startup safe state
All 16 PCA channels 0; TCA all_safe; GPIO13 off; GPIO16/17/20 low; LED_SWITCH 0 verified.

## Deployment (existing)
systemd `scure.service` (root, python) + `scure-io-safe.service` (early: pinctrl 16/17/20 low, i2cset 0x23 0x04 0x02 / 0x0C 0xDD). Kiosk: chromium `--kiosk` at http://localhost:3001 (desktop autostart or cage). Display: 7" DSI profile exists (`dtoverlay=vc4-kms-dsi-ili9881-7-0`, video=DSI-1:720x1280@60,rotate=90). **Target for this port: Raspberry Pi Touch Display (10.1", DSI, 1280x800)** — `dtoverlay=vc4-kms-dsi-waveshare-panel,10_1_inch` is NOT it; the official Raspberry Pi Touch Display 2 10.1" uses `dtoverlay=vc4-kms-dsi-ili9881-7-0` family? No: the official 10.1" Touch Display 2 is auto-detected by `display_auto_detect=1` on Pi 5/CM5 (panel `vc4-kms-dsi-ili9881-7` for 7", `10inch` variant selects `vc4-kms-dsi-ili9881-7-0,10inch`?). See deploy/image/README for the verified overlay line.

## Output watchdog (sCureBox 1.0.22)
A second process guards the heat and light sources when the firmware itself is gone (user decision 2026-09-16).

* **Heartbeat** — the firmware (`HeartbeatService`, Linux only) writes `/run/scurebox-heartbeat` every 1 s from its own
  thread: `<Environment.TickCount64 ms> <pid>` (monotonic since boot, immune to clock changes; /run is tmpfs). A clean stop
  deletes the file. `SCURE_HEARTBEAT_FILE` moves it, `off` disables it.
* **Watchdog** — `scurebox --watchdog --timeout 20` as `scurebox-watchdog.service` (root, Restart=always, not bound to the
  firmware unit), polls every 500 ms (`WatchdogMonitor`):
  * heartbeat younger than 20 s → armed; file removed without a trip → disarmed (clean stop, the firmware switched off itself)
  * heartbeat **20 s or older** (crash, kill, hang), or already stale when the watchdog starts → **TRIPPED**: cut now,
    cut again every 5 s while silent; a fresh heartbeat → recovered (the restarted firmware runs its own StartupSafe).
* **Cut** (`SafetyCut`) — PCA9685 (i2c-0 0x55) ch 6 heater SSR and ch 11-14 UV LED DIM written full-off and read back;
  the LED supply SSRs (components.json `led_power.ssr_450_gpio` / `ssr_405_gpio`, default GPIO16 / GPIO20) set output LOW
  with `pinctrl` and read back (pinctrl overrides a pin a hung firmware still holds). Fans, damper, valves, BOFA untouched
  so the chamber keeps cooling. Every step is attempted even if an earlier one fails; the journal lists what is off / failed.
* Manual cut for bench checks: `sudo /opt/scurebox/scurebox --watchdog --cut-now`.
* Logs: `journalctl -u scurebox-watchdog` (`[WATCHDOG] TRIPPED - firmware silent for 20.0 s: heaters + UV LEDs OFF (verified)`).


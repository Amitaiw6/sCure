---
name: feedback-reply-in-hebrew
description: "Reply language: Hebrew by default - user asked \"בעברית\" 2026-10-01 and again 2026-10-08 after a one-off \"switch to english\" on 2026-10-07"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 9c39147e-10c2-4f32-85a8-dbb9744f95b3
  modified: 2026-10-08T06:02:01.445Z
---

Write replies to the user in Hebrew (technical names, codes, file paths, commands and API terms stay in English).

**Why:** the user writes in Hebrew and asked "בעברית" on 2026-10-01 (twice) and again on 2026-10-08. A "switch to english" on 2026-10-07 was a one-off and was reversed the next day.

**How to apply:** default every user-facing reply to Hebrew; switch only for the turn(s) where the user explicitly asks for English. Code, comments and peer messages stay English.

# sCure UI specification (for a 1:1 native Avalonia / .NET re-implementation)

Source of truth: the React app in `sCure-A/src` (commit state as read).
Companion docs: `01-api-contract.md` (every endpoint + JSON), `02-hardware-map.md`, `03-ui-and-qa.md`
(program validation, estimate model, phase sequencing, simulation model — **not repeated here**).

All file references are `sCure-A/…:line`.

---

## 1. App shell

### 1.1 Design canvas & scaling
* Fixed design canvas **800 × 480 px** (`src/main.tsx:23-24` `DESIGN_W/DESIGN_H`; `src/index.css:20-27` `#root { width:800px; height:480px; overflow:hidden; transform-origin:center center }`).
* `fitToScreen()` (`main.tsx:25-31`) sets `root.style.scale = "${innerWidth/800} ${innerHeight/480}"` — a **non-uniform stretch** (X and Y scale independently, aspect ratio is NOT preserved), recomputed on every `resize`.
  * Device panel: 1280×720 or 1280×800 → 1.6× / 1.5× (or 1.667×).
  * Avalonia equivalent: a `LayoutTransformControl`/`ScaleTransform` with independent `ScaleX = ActualWidth/800`, `ScaleY = ActualHeight/480` wrapping an 800×480 root panel, `ClipToBounds=true`.
* `html, body`: margin/padding 0, 100%×100%, `overflow:hidden`, **background `#000`**, flex-centered (`index.css:8-18`). The canvas is centred on black.
* Body: `font-size:14px`, `line-height:1.4`, antialiased, `user-select:none`, `touch-action:manipulation`, `-webkit-tap-highlight-color:transparent`, `overscroll-behavior:none`, GPU `translateZ(0)` (`index.css:29-49`).
* `@media (pointer: coarse) { * { cursor: none } }` — **no mouse cursor on the device** (`index.css:154-157`).
* `.scroll-hidden` = scrollable with hidden scrollbars (`index.css:51-64`) — used on every scroll region. In Avalonia: `ScrollViewer` with `HorizontalScrollBarVisibility/VerticalScrollBarVisibility = Hidden` but scrolling enabled (touch pan).
* `@media (prefers-reduced-motion)` kills all animation (`index.css:147-152`).

### 1.2 Global providers (nesting order matters)
`src/main.tsx:33-53`, outermost → innermost:

1. `Router` — `BrowserRouter`, or `HashRouter` when `location.protocol === 'file:'` (`main.tsx:17`).
2. `SystemConfigProvider` (`context/SystemConfigContext.tsx`)
3. `DevModeProvider` (`context/DevModeContext.tsx`)
4. `HardwareProvider` (`context/HardwareContext.tsx`)
5. `AlertsProvider` (`context/AlertsContext.tsx`)
6. `CureHistoryProvider` (`context/CureHistoryContext.tsx`)
7. `MaterialProvider` (`context/MaterialContext.tsx`)
8. `PrintHistoryProvider` (`context/PrintHistoryContext.tsx`)
9. `App`

| Provider | Responsibility | Poll / persistence |
|---|---|---|
| SystemConfig | `/config/system.json` + `GET /api/system/version` override; `organizationId`, `setupComplete` | localStorage `scure-org` |
| DevMode | 10-press gate, PIN `<dev-pin>`, session-only `devMode` | none (session) |
| Hardware | `GET /api/state` **every 1000 ms**, mirrors all readings; raises alerts | localStorage `scure-system-name` |
| Alerts | error registry `/config/errors.json` (bundled fallback), active alerts, `POST /api/rgb/alerts` on change + every 30 s | localStorage `scure-active-alerts` |
| CureHistory | `GET /api/cure-history`; start/telemetry/finish POSTs | server only |
| Material | `GET /api/materials/presets` + `/user`, saves user list on change (full replace POST) | localStorage `scure-favorite-materials` |
| PrintHistory | `GET /api/print-history`, `POST` full replace | server only |

`useXxx()` throws if used outside its provider — in Avalonia these become singleton services injected into view models.

### 1.3 Gating order in `App` (`src/App.tsx:70-111`)
Evaluated top-down; the first match wins and nothing else is rendered:

1. `isLoading` (system config not yet loaded) → render **nothing** (blank black).
2. `asleep` → `WakeScreen blank` (full-black sleep screen).
3. `booting` → `BootScreen`.
4. `!config.setupComplete` → `SetupPage` (no TopBar, no routing).
5. `screenSaver` → `WakeScreen blank`.
6. Normal: `div.w-full.h-full.bg-background.flex.flex-col.overflow-hidden` → `TopBar` + `div.flex-1.overflow-y-auto.scroll-hidden` containing `<Routes>` + global `DevAuthModal`.

`asleep` / `booting` initial values are computed **once at mount** from `sessionStorage['scure-shutdown']` (`App.tsx:28-34`):
* `asleep = (flag === 'true')`
* `booting = (flag !== 'true')` → resuming from Sleep **skips the boot screen**.

### 1.4 Routing table (`App.tsx:94-107`)

| Route | Page component | Reachable from |
|---|---|---|
| `/` | `HomePage` | TopBar back, all aborts/completions |
| `/cure-process` | `CureProcessPage` | Home "Start Cure", PrintHistoryModal "Cure Together" |
| `/settings` | `SettingsPage` | TopBar gear |
| `/material-editor` | `MaterialEditorPage` | **orphan** — nothing navigates here (legacy screen; keep or drop) |
| `/network` | `NetworkPage` | TopBar globe |
| `/alerts` | `AlertsPage` | TopBar bell, "Go to alerts" in critical-block dialog |
| `/cure-history` | `CureHistoryPage` | TopBar history |
| `/dev` | `DevLayout` → index `DevMenuPage` | after PIN auth, TopBar `DEV` badge, "Dev Menu" link |
| `/dev/led-calibration` | `LedCalibrationPage` | Dev menu |
| `/dev/hdt-calibration` | `HdtCalibrationPage` | Dev menu |

Navigation style: TopBar uses `navigate(path, { replace: location.pathname !== '/' })` so lateral moves between top-level screens don't stack history; Back (`navigate(-1)`) therefore always lands on Home.

### 1.5 Idle / sleep behaviour
* `SCREENSAVER_TIMEOUT = 2 * 60 * 1000` (2 min) (`App.tsx:22`).
* Activity events that reset the timer: `pointerdown`, `pointermove`, `touchstart` (passive) (`App.tsx:50-54`).
* Screensaver is **disabled** while: `asleep`, `booting`, `!setupComplete`, or `isCuring` where `isCuring = pathname === '/cure-process' || devMode` (`App.tsx:45-48`) — an HDT calibration can run for hours and must stay visible.
* Entering cure clears any pending timer (`App.tsx:63-68`).
* **WakeScreen** (`components/WakeScreen.tsx`): fixed full-screen `bg-black`, z 99999, click anywhere counts a tap.
  * `blank=true` (both sleep and screensaver use it): stays **pure black** until the first tap (burn-in protection); the first tap reveals `SCureLogo size=64` at `opacity-40` + hint text.
  * Hint text: `Tap to wake` (0 taps) → `Tap again to start` (1 tap). On the **2nd** tap `onWake()` fires.
  * Screensaver wake: `setScreenSaver(false)` + restart idle timer. Sleep wake: remove `sessionStorage['scure-shutdown']` + `setAsleep(false)`.

### 1.6 Boot screen sequence (`components/BootScreen.tsx`)
Full-screen `bg-background`, z 9999, centred column.

Phase 1 — **logo**, 1500 ms: `SCureLogo size=80 color #ffffff`; below it `sCure` in `text-cyan-500 text-lg font-bold tracking-widest animate-pulse`.

Phase 2 — **checking**: logo transitions (700 ms) to `size=48`, `scale-75 opacity-90 -translate-y-8`. A 500 px-wide block fades in (`animate-fadeIn`, 0.5 s, `index.css:67-71`) containing:
* Header row: `System Diagnostics` (muted, uppercase, tracking-wider, 12 px) … `{passed}/6` (white, mono, 12 px).
* Progress bar: 100 % × 1 px track `#1a1a1a`, fill **white**, rounded-full; it leads each running check and lands when it ends.
* One column of the checks, each a status glyph + label + a right-aligned detail (live step while checking, the reason in red on a failure):
  * pending → small dot `#333`, label `#444`
  * checking → cyan-400 dot, label `cyan-400 font-medium`
  * ok → green-400 `✓` (U+2713), label `#888`
  * fail → red-500 `✗`, label red-500, detail red
* **Native UI (sCureBox 1.0.16, user decision 2026-09-16): the checks are real**, run in this order:
  1. `Door Closed` — waits up to **60 s** for the door (detail `Close the door to continue`); still open → fail `The door is open - close it and retry`, unreadable → `The door sensor is not reading`.
  2. `Temperature Sensors` — every NTC reads: the five supervised sensors (chamber, left / right / back / door ORIGIN, `/api/state.sensors[*].ok`) and the two panel sensors `ledTemps.left2` / `right2`. Waits up to 5 s for the first supervision pass; fail names each sensor (`Not reading: …`).
  3. `UV LEDs 405nm` — the Settings LED test (`RunLedTest`, 15 s, 100 %, min rise 0.8 °C; precools the panels first when warm). Only with the door closed, otherwise `Skipped - the door is not closed`.
  4. `UV LEDs 450nm` — the same at 450 nm, 30 s (the door panel is reported, not judged). Door rule as above.
  5. `Chamber Fans` — the diagnostics fan test (`RunFanTest("all")`: every fan 100 % for 2 s, measured over 1 s, ≥ 100 RPM); fail `Not spinning: FAN_X (n RPM), …`.
  6. `API Server` — the state read succeeds.
* The checks sit behind `IBootSelfTest` (`HardwareBootSelfTest` on the firmware; the UI tests register an instant fake).

Phase 3 — **done**:
* all passed → centred `All systems operational` (green-400, 14 px, semibold) + `Starting sCure...` (muted, 12 px), then Setup / Home after **1200 ms**.
* any failure → the check list stays up, `{n} of 6 checks failed` (red) with **Continue anyway** (secondary) and **Retry** (primary). Retry runs every check again; Continue anyway goes to Setup / Home.

Boot time with every check passing ≈ 1.5 s logo + door + sensors (< 1 s) + LED 405 (15 s, + 20 s precool when the panels are warm) + LED 450 (30 s, + precool) + fans (~3 s) ≈ **50 s – 90 s**. (The original web UI ran 14 cosmetic checks in ~10 s.)

### 1.7 Shutdown / reboot flow
* **SLEEP** (Settings → Power Options, `pages/SettingsPage.tsx:164-167`): `sessionStorage['scure-shutdown'] = 'true'` then `window.location.reload()`. After reload the app mounts `asleep=true`, `booting=false` → black WakeScreen. Two taps return to the app with no boot screen.
  * Avalonia equivalent: a "sleep" app state flag that survives an in-process UI reset (blank the screen, keep the backend running); no OS shutdown is issued.
* **REBOOT**: `confirm('Reboot device?')` (native browser confirm) then `POST /api/system/reboot` (`hardware-api.ts:58-60`). Blocked in dev builds (`DEV_BLOCKED`, `hardware-api.ts:17`).
* `POST /api/system/shutdown` exists in the service (`systemShutdown`) but **no screen calls it**.
* There is no OS power-off button in the UI.

### 1.8 Setup gating (`setupComplete`)
* `config.setupComplete` comes from `localStorage['scure-org']` overriding `/config/system.json` (`SystemConfigContext.tsx:50-58`); shipped `system.json` has `"setupComplete": false`.
* While false, **SetupPage replaces the whole app** (no TopBar, no routes, no screensaver).
* `completeSetup()` persists `{organizationId, setupComplete:true}` to `scure-org`.
* `resetSetup()` removes the key and clears org → the app returns to Setup on next gate evaluation. Triggered from Settings by the Unlink button and by **10 taps** on the version card.

### 1.9 Developer-mode gating (`context/DevModeContext.tsx`)
* `PRESSES_TO_UNLOCK = 10`, `DEV_PASSWORD = '<redacted>'`.
* Every TopBar gear press calls `registerSettingsPress()`; counter is a ref, ignored once already in dev mode; the 10th press resets the counter, calls `devLog('Developer Mode requested')` and opens `DevAuthModal`.
* `tryPassword('<dev-pin>')` → `devLog('Developer Mode authentication successful')`, `devLog('Developer Mode entered')`, `devMode=true`, close, `navigate('/dev')`. Wrong → `devLog('Developer Mode authentication failed')`, returns false (modal shows error, clears entry).
* `exitDevMode()` → `devLog('Developer Mode exited')`, `devMode=false`, `navigate('/')`.
* Dev mode is **session-only** — a restart is always back in normal mode; only the LED calibration factors persist (on the backend).
* `/dev/*` routes are guarded by `DevLayout`: `if (!devMode) return <Navigate to="/" replace/>`.
* While `devMode` is true the screensaver is disabled globally and a `DEV` badge appears in the TopBar.

### 1.10 Curing gating (safety)
While `pathname === '/cure-process'`:
* TopBar: back arrow hidden, **door button hidden entirely** (`TopBar.tsx:66`), every right-hand icon inert with `opacity-30` (history, bell, settings, network); gear does not count presses.
* Screensaver disabled.
* On Home, **Start Cure** is disabled/grey when `hw.doorClosed === false` (a real "open" reading; `null`/undefined does not block) or no program is selected; grey + explanatory dialog when any **critical** alert is active.

---

## 2. Visual language

### 2.1 Colour tokens (`src/index.css:203-237`, dark-only theme)

| Token | Hex | Usage |
|---|---|---|
| `--background` | `#0a0a0a` | app background, page background |
| `--foreground` | `#ffffff` | primary text |
| `--card` | `#111111` | all cards / list rows / panels |
| `--card-foreground` | `#ffffff` | |
| `--popover` | `#141414` | dialog surface |
| `--popover-foreground` | `#ffffff` | |
| `--primary` | `#0ea5e9` | **primary blue** (buttons, active icon, links, accents) |
| `--primary-foreground` | `#ffffff` | |
| `--secondary` | `#1a1a1a` | TopBar background, chips, keypad keys, inset fields |
| `--secondary-foreground` | `#ffffff` | |
| `--muted` | `#1a1a1a` | progress track, ghost hover |
| `--muted-foreground` | `#9ca3af` | secondary/label text |
| `--accent` | `#1a1a1a` | hover/active row |
| `--accent-foreground` | `#ffffff` | |
| `--destructive` | `#dc2626` | **critical** text/borders, abort |
| `--destructive-foreground` | `#ffffff` | |
| `--border` / `--input` | `#222222` | 1 px borders, dividers, gauge track |
| `--ring` | `#0ea5e9` | focus ring |
| `--chart-1..5` | `#0ea5e9`, `#f97316`, `#a855f7`, `#14b8a6`, `#3b82f6` | |
| `--sidebar*` | `#111111` / `#ffffff` / `#0ea5e9` / `#1a1a1a` / `#222222` | unused on device |

Semantic status colours (Tailwind palette, used directly):

| Meaning | Class | Hex |
|---|---|---|
| success / done / PASS | `green-400` / `green-500` | `#4ade80` / `#22c55e` |
| info / duration / "next" | `cyan-300/400/500` | `#67e8f9` / `#22d3ee` / `#06b6d4` |
| warning / aborted | `orange-400` / `orange-500` | `#fb923c` / `#f97316` |
| caution (temp warning, hot surface) | `yellow-400` / `#F5C400` | `#facc15` |
| critical | `red-500` / `red-600` / destructive | `#ef4444` / `#dc2626` |
| heating phase | `orange-400/500` | `#fb923c` / `#f97316` |
| drying phase | `blue-400/500` | `#60a5fa` / `#3b82f6` |
| cure phase (405 nm) | `purple-400/500/600` | `#c084fc` / `#a855f7` / `#9333ea` |
| bleaching (450 nm) | `cyan-400` + `blue-600` btn | `#22d3ee` / `#2563eb` |
| cooling phase | `teal-400/500` | `#2dd4bf` / `#14b8a6` |
| nitrogen | `white` | `#ffffff` |
| developer mode | `amber-300/400/500` | `#fcd34d` / `#fbbf24` / `#f59e0b` |
| favourite star | `yellow-400` filled | `#facc15` |
| disabled Start Cure | `neutral-600` bg / `neutral-300` fg | `#525252` / `#d4d4d4` |
| door-countdown dialog | `zinc-900` bg / `red-500` border / `zinc-300` text / `zinc-500` caption | `#18181b` / `#ef4444` / `#d4d4d8` / `#71717a` |
| raw greys in boot/keyboard | `#1a1a1a`, `#222`, `#333`, `#444`, `#555`, `#888` | |
| HDT chart | grid `#333`, axis `#555`, ticks `#888`, raw `#60a5fa`, average `#facc15`, HDT line `#ef4444`, margin line `#f97316`, transition `#666`/label `#aaa`, tooltip bg `#1b1b1b` border `#444` | |

### 2.2 Typography
* Family: **`Geist Variable`**, fallback `sans-serif` (`--font-sans`, `index.css:161`); headings use the same family (`--font-heading: var(--font-sans)`). Bundled via `@fontsource-variable/geist`.
* Monospace is used for IDs/IPs/versions/clock values (`font-mono` → system mono). The setup device illustration uses `monospace`; the report header uses `Inter/Helvetica`.
* Root 14 px / 1.4. Effective sizes seen (px): 8, 9, 10, 11, **12 (`text-xs`)**, **14 (`text-sm`)**, **16 (`text-base`)**, 17.5 (material row label), **18 (`text-lg`)**, **20 (`text-xl`)**, 21 (Start Cure), **24 (`text-2xl`)**, 26, 48 (`text-5xl` door countdown).
* Weights: 400 normal, 500 medium, 600 semibold, 700 bold. Tracking: `tracking-wide`, `tracking-wider`, `tracking-widest`, `tracking-[0.2em]` (DEVELOPER MODE).

### 2.3 Spacing & radii
* Page padding: `p-3` (12 px) on Settings/Network/Alerts/CureHistory/dev; `px-3` on CureProcess; `px-4 pb-20` on Home.
* Card padding: `p-2` … `p-4`; gaps `gap-1 … gap-6` (4–24 px); vertical stacks `space-y-1 … space-y-4`.
* Radii from `--radius: 0.75rem = 12px` (`index.css:193-199`):
  * `rounded-sm` 7.2 px, `rounded-md` 9.6 px, **`rounded-lg` 12 px**, **`rounded-xl` 16.8 px**, **`rounded-2xl` 21.6 px**, `rounded-3xl` 26.4 px, `rounded-4xl` 31.2 px (badges), `rounded-full` pill/circle.
* Touch targets: TopBar icons **48×48** (`w-12 h-12`), back button **44×44**, `TouchNumber` steppers **36×36**, PIN keys **48 high**, keyboard keys fill a 4-row grid.

### 2.4 Button variants (`components/ui/button.tsx`)
Base: inline-flex, centred, `rounded-lg`, 1 px transparent border, `text-sm font-medium`, no wrap, `select-none`, `active:translate-y-px`, `disabled:opacity-50 disabled:pointer-events-none`, child SVG 16 px.

| variant | appearance |
|---|---|
| `default` | `bg-primary` (#0ea5e9), white text |
| `outline` | `border-border`, `bg-input/30`, hover `bg-input/50` |
| `secondary` | `bg-secondary` (#1a1a1a), white text |
| `ghost` | transparent, hover `bg-muted/50` |
| `destructive` | `bg-destructive/20`, **text-destructive** (not a solid red button by default — several call sites override with solid `bg-destructive`) |
| `link` | primary text, underline on hover |

| size | height / padding |
|---|---|
| `xs` | 24 px, px 8, 12 px text, 12 px icons |
| `sm` | 28 px, px 10, 12.8 px text, 14 px icons |
| `default` | 32 px, px 10 |
| `lg` | 36 px, px 10 |
| `icon` | 32×32 · `icon-xs` 24×24 · `icon-sm` 28×28 · `icon-lg` 36×36 |

Notable one-offs: **Start Cure** `h-[54px] px-[30px] text-[21px] rounded-2xl gap-3 shadow-lg shadow-black/50`; Pause = white button with 2 px phase-coloured border; "Pause & Open Door" = `bg-cyan-500 text-black`.

### 2.5 Icons (lucide-react ≥1.7), per screen
* **TopBar**: `ArrowLeft`, `DoorClosed`/`DoorOpen`, `Thermometer`, `Nfc`, `History`, `Bell`, `Settings`, `Globe` (+ text badge `DEV`, text `N₂`).
* **BootScreen / WakeScreen / Setup**: `SCureLogo` (custom SVG), `Usb`, `Upload`, `Building2`, `ArrowRight`, `CheckCircle2`, `Pencil`.
* **Home**: `Play`, `Upload`, `Trash2`, `Pencil`, `Copy`, `ChevronRight`, `CheckCircle`, `XCircle`, `AlertTriangle`, `Building2`; `MaterialItem` adds `Star`, `Lock`, `PlusCircle`.
* **CureProcess**: `ArrowRight`, `DoorOpen`, `CheckCircle`, `AlertTriangle`; `PhaseCard` `PauseCircle`; `FanFailModal` `AlertTriangle`,`Fan`; `HeaterFaultModal` `AlertTriangle`,`Thermometer`; `AbortModal` `AlertTriangle`,`Eye`,`Box` + custom `HotSurfaceSign`; `PauseModal` `PauseCircle`,`DoorOpen`,`AlertTriangle`; `PauseOverlay` `DoorOpen`,`Play`,`Square`,`Lock`.
* **CureHistory**: `CheckCircle`, `XCircle`, `AlertTriangle`, `Clock`, `Play`, `Download`.
* **Alerts**: `AlertOctagon`, `AlertTriangle`, `ChevronRight`, `ArrowLeft`, `Mail`, `Phone`, `MessageCircle`, `Wrench`, `FileText` + QR code SVG.
* **Settings**: `Download`, `Upload`, `Fan`, `Zap`, `Building2`, `Unlink`, `ShieldCheck`, `Pencil`.
* **Network**: none (text tabs, coloured status dot).
* **Dev**: `SlidersHorizontal`, `ThermometerSun`, `ChevronRight` (menu); `TerminalSquare`, `LogOut` (layout); `Save`, `RotateCcw`, `LogOut`, `Zap`, `ZapOff` (LED); `Play`, `OctagonX`, `Download`, `CheckCircle2`, `XCircle`, `CircleAlert`, `Thermometer`, `Activity`, `Eye`, `EyeOff`, `RotateCcw` (HDT); `Delete`, `TerminalSquare` (PIN pad).
* **Modals**: `Plus`, `Trash2`, `Download` (CSV builder); `Folder`, `CheckCircle`, `XCircle` (import); `CheckCircle`, `XCircle`, `Loader2`, `Upload`, `RefreshCw` (update); `Tag` (versions); `ShieldCheck`, `CheckCircle2`, `Clock` (compliance); `Filter`, `X`, `Check`, `Play`, `ChevronRight` (print history); `Minus`/`Plus` (TouchNumber); `ChevronUp/Down` (TouchSpinner); `XIcon` (dialog close).
* Emoji/glyph icons on phase badges & step cards: `🔥` Heating, `⏱`/`◇` Drying, `✦` Cure, `❄` Cooling, `☀` Bleaching, `N₂` Nitrogen.

### 2.6 SCure logo geometry (`components/SCureLogo.tsx`)
SVG, `viewBox="-3 -7 106 141"`, `width=height=size`, `fill=none`, `stroke-width 5.5`, `strokeLinecap="square"`, `strokeLinejoin="miter"`, `strokeMiterlimit=100`, single `color` prop (default `currentColor`; `#ffffff` everywhere in the app).

Strokes (all in the 0–100 × 0–126 coordinate space):
1. Top V: `M0 45 L50 0 L100 45`
2. Bottom V: `M0 90 L50 126 L100 90`
3. Vertical: `(50,0) → (50,126)`
4. Top horizontal: `(0,45) → (100,45)`
5. Bottom horizontal: `(0,90) → (100,90)`
6. Left S-weave diagonal: `(0,45) → (50,90)`
7. Right S-weave diagonal: `(50,45) → (100,90)`
8. Top-right perpendicular: `(100,45) → (77.6,69.9)`
9. Bottom-left perpendicular: `(0,90) → (22.4,65.1)`

(The perpendicular endpoints are the computed feet of the perpendiculars to the diagonals — slope 0.9, perpendicular −1.111; see the comment block at `SCureLogo.tsx:11-19`.)

Sizes used: 28 (TopBar), 48/80 (boot), 64 (wake), 100 (setup welcome).

### 2.7 Animations (`src/index.css`)
| Name | Definition | Where |
|---|---|---|
| `fadeIn` | 0.5 s ease-out, opacity 0→1 + translateY 8→0 | boot check block, boot done text |
| `welcome-logo-enter` | 1 s cubic-bezier(.16,1,.3,1): scale .3/rot −10° → 1.08/+2° → .97/−1° → 1/0° | setup welcome logo |
| `welcome-glow` | 3 s infinite, delay 1.2 s: drop-shadow 8 px white .2 → 24 px white .4 + 48 px #0ea5e9 .15 | setup logo |
| `welcome-text-enter` | 0.7 s, opacity + translateY 20→0; title delay 0.5 s, subtitle 0.75 s | setup title/subtitle |
| `welcome-btn-enter` | 0.6 s delay 1 s, opacity + translateY 16 + scale .95→1 | Get Started |
| `welcome-ring` | 2 s infinite, opacity .6→0, scale .8→1.6; second ring delayed 0.6 s | 180 px and 260 px rings behind the logo |
| `welcome-shimmer` | 4 s linear infinite, delay 1.5 s; gradient `#ffffff → #0ea5e9 → #ffffff → #0ea5e9`, `background-size 200%`, text-clipped | "sCure" wordmark |
| `draw-line` | stroke-dashoffset 1→0 | defined, unused |
| `animate-pulse` (Tailwind) | 2 s opacity pulse | boot "sCure", checking dot, N₂ active ring, running-status icon, HDT Activity icon, keyboard caret |
| `animate-spin` | Fan test icon, `Loader2` in UpdateModal |
| `animate-bounce` | Export-logs Download icon while exporting |
| `active:scale-95` | large touch buttons (overlays, OK, Continue) |
| Dialog | `fade-in-0 zoom-in-95` / `fade-out-0 zoom-out-95`, 100 ms | all dialogs |
| PhaseCard gauge | SVG stroke-dashoffset (no CSS transition; value-driven) | |

---

## 3. Screens

Common conventions: every page is the scrollable body under the TopBar (`div.flex-1.overflow-y-auto.scroll-hidden`). All dialogs are Radix dialogs **portalled into `#root`** so they scale with the canvas (`ui/dialog.tsx:20-34`); overlay `bg-black/10` + backdrop-blur-xs, content centred, `bg-popover`, `rounded-xl`, `p-4`, `ring-1 ring-foreground/10`, default `max-w-sm`.

---

### 3.1 SetupPage (`pages/SetupPage.tsx`)
Full-screen (`w-full h-full bg-background`, centred), **three steps**: `welcome` → `name` → `org`. Rendered instead of the whole app while `setupComplete === false`.

Step indicator (shown for `name`/`org`, absolute top-4 centre): dot (8 px) — 24 px line `bg-border` — dot. Active dot `bg-primary`, inactive `bg-primary/30` (step 1) / `bg-border` (step 2).

**Welcome**
* Two concentric animated rings behind the logo: 180 px `border-primary/10` (`animate-welcome-ring`), 260 px `border-primary/5` (`animate-welcome-ring-delayed`), both offset `-mt-6`, `pointer-events-none`.
* `SCureLogo size=100 color #ffffff` with `animate-welcome-logo`.
* `h1` 24 px bold `tracking-widest`: **`sCure`** with the shimmer gradient.
* Subtitle (12 px muted, 2 lines): `Congratulations on your new ` + `sCure` (primary, semibold) + ` curing system.` / `Let's set it up in just a few steps.`
* Button `Get Started` + `ArrowRight` 14 (h-9, px-8, 14 px semibold, `animate-welcome-btn`) → step `name`.

**Native port addition (v1.0.13, mandatory + conditional since v1.0.14): Serial Number step** between Welcome and
Name, shown **only when the unit has no serial number** (none scanned on the machine and `config/system.json`
`serialNumber` empty - the shipped file has none): Get Started → `serial`, the indicator has three dots; otherwise
Get Started → `name` with two dots. The step **cannot be skipped**: `Next` is enabled only once a valid number was
scanned or typed in this Setup. Left card: a barcode label inside aiming-frame corners with a red laser line sweeping
up and down (2.4 s) and a breathing **`Scan the barcode`** prompt, `Waiting for the scanner...`; after a valid scan a
green check, `Serial number scanned`, the number (mono) and `Scan again to replace it`. Right: title `Serial Number`,
hint `Scan the serial number barcode with the USB scanner`, an `S/N` read-out (scanner only; since v1.0.15 typing is
hidden: **10 taps on the white barcode label** open the device password pad (`DevAuthDialog`, the developer PIN) and
the right password turns the read-out into the `Enter manually` button with the on-screen keyboard - developer mode is
left again at once), the rejection text `"<code>" is not a valid serial number` and `Next` (stores it). Valid: `^[A-Za-z0-9][A-Za-z0-9._/-]{2,39}$`. Scans are read from the USB input devices
(`BarcodeScanner`, /dev/input, US layout, Enter-terminated) and only taken while this step is on screen. The number is
persisted as `serialNumber` in `<data>/ui-settings.json` and overrides `config/system.json`. QA: `POST /api/ui/scan?code=`.

**Step 1 — Device name** (row: illustration | 340 px form)
* Left: inline SVG 160×145, `viewBox 0 0 200 180`: device body `rect 35,20 130×110 r10 fill #111111 stroke #333333 1.5`; five vents `rect 42,(40|50|60|70|80) 28×5 r2 fill #222222`; screen `rect 85,32 68×85 r5 fill #0a0a0a stroke #222222`; live device name centred at (119,72) `#ffffff` 8 px monospace bold (or `???`); `NAME ME` at (119,86) `#9ca3af` 5 px mono; caption at (100,155) `#555555` 6 px: `Give your cure box a name`.
* Right: `h1` 16 px bold `Name Your Cure Box`; hint 10 px `Choose a name to identify this device`.
* Tappable field (card, 1 px border, `rounded-lg`, p-2.5): label 9 px `Device Name`; value 14 px semibold — the entered name or placeholder `Tap to enter name...` (muted/40); `Pencil` 13 at the right. Tap → `OnScreenKeyboard`.
* Button `Next` + `ArrowRight` 12 (`w-full h-8`, 12 px semibold), **disabled while the name is blank**. On press: `setSystemName(trimmed)` (HardwareContext → localStorage `scure-system-name`) then step `org`.

**Step 2 — Organization** (row: 420×420 video | 320 px form)
* Left: `<video autoPlay muted playsInline object-cover>` cycling `/videos/usb-insert.mp4` → `/videos/usb-org.mp4` on `ended` (modulo loop; `SetupPage.tsx:24-25, 183-191`). Avalonia: looping video/animation playlist of the same two clips.
* `h1` 18 px bold `Link Organization`; subtitle 12 px `Link ` + **deviceName** (primary) + ` to your organization`.
* If no org parsed: dashed-border card button, 36 px circle `bg-primary/10` with `Upload` 16 primary, title 14 px `Upload Organization CSV`, subtitle 12 px `Select the CSV file from the USB drive`. Opens a hidden `<input type=file accept=".csv">` (native file picker).
* File handling: read as text, match `/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i`.
  * Match → store org id + file name.
  * No match → error text (10 px destructive, centred): **`No valid organization ID found in CSV file`**; org/file cleared.
* If parsed: card `border-primary/30`: 36 px circle `bg-green-500/10` + `CheckCircle2` 16 green-500; `Building2` 11 primary + 12 px semibold `Organization Found`; the UUID 9 px mono truncated; `from {fileName}` 8 px; small `Change` button (10 px, `bg-secondary`) clears everything.
* Primary button `Usb`14 + `Link Organization` + `ArrowRight`14 (`w-full h-11 rounded-xl`), disabled until an org id exists → `setOrganization(orgId)`, `completeSetup()`, `navigate('/')`.
* Text button `Continue without organization` (12 px muted) → `completeSetup()`, `navigate('/')` (no org id).
* `OnScreenKeyboard` is mounted for the whole page (bound to `deviceName`).

**Notes for the port**: no API calls at all in Setup; the name goes to localStorage + HardwareContext, the org id to localStorage `scure-org`. No validation of the UUID beyond the regex.

---

### 3.2 TopBar (`components/TopBar.tsx`)
`header`: `flex items-center justify-between px-3 py-2 bg-secondary shrink-0` (≈ 48 px tall at design scale).

**Left group** (gap-2)
* Back button 44×44 with `ArrowLeft` 22 — shown only when **not** on `/` and **not** curing; `navigate(-1)`.
* `SCureLogo size=28 #ffffff`.
* `h1` 20 px bold `tracking-wide` = `hw.systemName` (default `sCure`, from localStorage `scure-system-name`).

**Centre group**
* Door button (hidden while curing): `DoorClosed`24 + label **`Open Door`** when closed; `DoorOpen`24 + **`Door Open`** when open. Open state styling `bg-orange-500/15 text-orange-400` and the button is **disabled**. Press (only when closed) → `POST /api/door/open` (`doorOpen()`) + optimistic `setDoorClosed(false)`; the 1 s `/api/state` poll re-syncs. Right border `border-r border-border`.
* Temperature block: `Thermometer` 22 + value. `hw.chamberTemp.toFixed(1)°C` 16 px bold. Both turn **red-500** once `isHeating` has been true for **> 10 s** (`heatingLong`, timer from `hw.heatingStartTime`, `TopBar.tsx:31-43`). When `hw.targetTemp !== null` a second line shows `Target: {targetTemp}°C` in orange-400 10 px.

**Right group** (gap-1.5, each 48×48 `TouchIcon`; active = `bg-primary/15 text-primary`, idle = muted, hover white)
1. `DEV` text badge (only when `devMode` and not already under `/dev`): amber pill, 10 px bold `tracking-widest` → `/dev` (inert while curing).
2. N₂ indicator (only when `hw.nitrogenMode`): 36 px circle, 2 px white border, `N₂` 12 px bold; when `nitrogenActive` → `bg-white/20 animate-pulse` and the corner dot (8 px) is `green-400 animate-pulse`, otherwise white. Non-interactive.
3. NFC: shown when `hw.nfcEnabled && (hw.nfcReader?.detected ?? true)` — `Nfc` 22 inside a 40 px circle with a 2 px `#444` border. Non-interactive.
4. History → `/cure-history` (`History` 24).
5. Bell → `/alerts`: `Bell` 24, coloured **red-500** when any critical alert, **orange-400** when only warnings; badge = 16 px red-500 circle at `-top-1.5 -right-1.5`, 9 px bold white, showing `alertCount` (only alerts whose code resolves in the registry).
6. Settings → `/settings` (`Settings` 24) **and** `registerSettingsPress()` (dev-mode gate).
7. Network → `/network` (`Globe` 24): **destructive** when `!hw.networkConnected`, primary when the page is active, otherwise white.

State consumed: `systemName`, `chamberTemp`, `targetTemp`, `isHeating`/`heatingStartTime`, `doorClosed`, `nitrogenMode`, `nitrogenActive`, `nfcEnabled`, `nfcReader.detected`, `networkConnected`; `alertCount`, `criticalAlerts`; `devMode`.

---

### 3.3 HomePage (`pages/HomePage.tsx`)
`main.px-4.pb-20.relative` (bottom padding clears the floating Start Cure button).

**Region A — Recent Prints** (`mt-4 mb-3`)
* `h2` 16 px semibold white `Recent Prints`; right: ghost button `View All` + `ChevronRight`14 (12 px muted) → PrintHistoryModal — **only when an organization is linked**.
* No org → card (`bg-card rounded-xl px-4 py-4`): `Building2`18 muted + `No organization` (14 px muted) + `Link an organization in Settings to view print history` (10 px).
* Org but no logs → `No prints yet.`
* Otherwise up to **3** rows (`recentLogs = logs.slice(0,3)`), each `rounded-xl px-4 py-2.5`, selected = `bg-primary/10 border-primary/40`:
  status icon 14 (`CheckCircle` green-500 / `AlertTriangle` orange-500 / `XCircle` destructive) · `printName` 14 px medium + `materialName` 12 px muted · `{duration} min` cyan-400 12 px · `timeAgo(date)` (`{m}m ago` < 60 min, `{h}h ago` < 24 h, else `{d}d ago`) · `printerName` 14 px muted/50 · `ChevronRight`14.
  Tap toggles selection; selecting a print clears `selectedMaterialId`; the material for the run is resolved by **name match** (`materials.find(m => m.name === print.materialName)`).

**Region B — Program list** (sticky header, `z-20`, `bg-background`, `pt-5 pb-2`)
* `h2` `Program List` + `({materials.length})` (12 px muted).
* Buttons: `Edit` / `Done` toggle (ghost → destructive when active, only if there are materials); outline `Upload`14 + `CSV` → ImportCsvModal; primary `+ New` → CsvBuilderModal (create).
* List: `isLoading` → `Loading materials...`; empty → `No materials yet. Upload a CSV or create a new material.`; otherwise all materials **sorted favourites-first** (stable otherwise), each rendered as `MaterialItem` with `duration = "~{estimateProgramMinutes(mat.steps)} min"`.
* Edit mode appends per-row icon buttons (28×28 ghost, `mb-2`): `Copy`16 (title `Duplicate`, always) — duplicates to `"<name> Copy"`/`Copy 2`… and immediately opens the builder on the copy; then for non-presets `Pencil`16 primary (title `Edit`) and `Trash2`16 destructive (title `Delete`, deletes immediately, no confirmation).

**Region C — Start Cure** (`fixed bottom-4 right-4`)
* Button: `Start Cure` + `Play` 24 filled; 54 px high, 30 px horizontal padding, 21 px semibold, `rounded-2xl`, `shadow-lg shadow-black/50`.
* `canStart = !!activeMaterialId && !doorOpen`; when `!canStart` → `bg-neutral-600 text-neutral-300`, no shadow, inert. `title`: `Close the door to start the cure` (door open) / `A critical alert is active`.
* With a critical alert the button is grey but **clickable** → opens the critical-block dialog.
* `handleStartCure`: resolve material; if all non-Nitrogen steps are empty and `!hw.nitrogenMode` → N₂ error overlay; else ensure `setSelectedMaterialId` then `navigate('/cure-process')`.

**Dialogs opened from Home**
1. **Critical alert active** (`Dialog`, `max-w-md`): title `AlertTriangle`20 + `Critical alert active` (destructive). Body: `A cure cannot start while a critical alert is active. Handle it/them on the Alerts screen first:` followed by a bulleted list (max 4) of `"{code} — {message}"` + ` ({detail})`. Footer: outline `Close`, primary `Go to alerts` → `/alerts`.
2. **Cannot Start Cure** (custom full-screen overlay `fixed inset-0 z-50 bg-background/95`): 80 px `bg-destructive/20` circle + `AlertTriangle`48 destructive; `h2` 20 px bold `Cannot Start Cure`; `This material contains only nitrogen purge steps, but nitrogen is not enabled on the system.`; `Enable nitrogen in Settings or choose a different material.`; primary `OK` button (px-6 py-3 rounded-2xl).
3. `CsvBuilderModal`, `ImportCsvModal`, `PrintHistoryModal` (§3.10–3.12).

---

### 3.4 CureProcessPage (`pages/CureProcessPage.tsx`, 1260 lines — the most complex screen)
`main.px-3.h-full.flex.flex-col.overflow-hidden`. **The page auto-starts the run on mount** (no start button).

#### 3.4.1 Phase model
`phases` (`:143-172`) = material steps, **Nitrogen steps filtered out unless `hw.nitrogenMode`**, mapped to
`{ name, type: name.toLowerCase(), temp: step.temperature (null ⇒ UV-only), intensity: step.uvIntensity ?? step.intensity, time (min), coolingMode ?? 'medium', uvStartMode ?? 'at-target', timerMode ?? 'on-target', vent: !!step.ventilation }`.
With no material a 4-phase demo (Heating 80 / Drying 80 @30 % / Cure null @50 % / Cooling 25, all 1 min) is used.

#### 3.4.2 Layout regions (top → bottom)
**A. Sequence header** (`bg-card rounded-xl p-2 mt-1`)
* `h2` 14 px bold `Cure` + ` — {material name}` (12 px muted).
* Pill (`bg-secondary rounded-full px-3 py-1`): `{min(activePhase+1,total)}/{total}` + one 16×8 `rounded-sm` chip per phase — coloured by phase name once reached (`Heating` orange-500, `Drying` blue-500, `Cure` purple-500, `Cooling` teal-500, `Nitrogen` white, fallback primary), `bg-border` while pending.
* Right: `{overallProgress}%` in **green-400** 14 px bold. (The native UI no longer shows a chamber temperature / target next to it - removed in sCureBox 1.0.23, user decision 2026-09-16; the top bar hides its temperature on this page since 1.0.9.)
* `Progress` bar `h-1` with `overallProgress`.
* Phase-name row: one text button per phase, `{name}` + `{time}m` (9 px). Colour: active → phase colour (`Heating` orange-400, `Drying` blue-400, `Cure` purple-400, `Cooling` teal-400, `Nitrogen` white), completed → green-400, pending → muted. Clicking only does something when **not** running (`!isRunning && setActivePhase(i)`).

**B. Status bar** (`bg-card rounded-lg px-3 py-1.5 mt-1 border-l-4 border-cyan-500`) — five mutually exclusive states:

| condition | badge | text |
|---|---|---|
| `isComplete` | green-500 `Done` | `Cure complete!` + `ArrowRight`20 green-400 |
| `n2Purging` | white/black `N₂` | `Nitrogen Purge` · `{nitrogenDuration - n2Elapsed}s remaining` |
| `isRamping` | orange-500 `{phase name}` | `{chamberTemp}°C → {targetTemp}°C` · `Timer running — started with the ramp` (on-ramp) or `Timer starts at target` |
| `isRunning` | outline cyan `Next` | `{nextPhase.name ?? 'Final phase'}` · `({getNextPhaseDesc()})` + `ArrowRight`20 muted |
| otherwise | outline cyan `Starting` | `Initializing...` |

`getNextPhaseDesc()` = joined parts: `Hold at {temp}°C`, `Intensity {intensity}%`, `for {time} min`; `Process complete` when there is no next phase.

**C. Hardware-refusal banner** (when `phaseError`): `bg-destructive/15 border-destructive rounded-lg px-3 py-1.5`, `AlertTriangle`14 + `Hardware: {message}` (12 px destructive).

**D. Phase cards** — horizontal scroll strip, `flex-1 min-h-0`, `overflow-x-auto`, `scroll-snap-type: x mandatory`, `touch-action: pan-x`. One `PhaseCard` per phase (240 px wide — see §4).

**E. Overlays** (all `fixed`, z 40–50) — see §3.4.6.

#### 3.4.3 Gauge content per phase (`getGaugeInfo`, `:929-987`)
| phase | value / label | progress | range start → end | status text |
|---|---|---|---|---|
| Heating / Drying, ramping | `{chamberTemp}` / `RAMP °C` | `rampProgress` | `{rampStartTemp}°C` → `{temp}°C` | `Ramping...` |
| Heating / Drying, holding | `mm:ss` remaining / `REMAINING` | elapsed/hold | `25°C` → `{temp}°C` | `Heating...` / `Drying...` |
| completed | `{temp}` / `HOLD °C` | 100 % | | `Done` |
| pending | `0` / `HOLD °C` | 0 | | `Waiting...` |
| Cure (and Cooling) | no numeric value — a 40×2 px dash + centre caption `UV + HEAT` / `COOL`, overridden to `UV ONLY` or `UV + VENT` on a no-heat step | elapsed/hold (cure) | `0%` → `{intensity}%` | `UV curing at {intensity}%{ (no heat) / (no heat, vented) }...` |
| Nitrogen | `{nitrogenDuration - n2Elapsed}` / `SEC` | n2Elapsed/duration | `0s` → `{duration}s` | `N₂ purging...` |
| Cooling | `{chamberTemp}` / `COOL °C` | `(coolStartTemp − chamberTemp) / (coolStartTemp − target)` | `{coolStartTemp}°C` → `{target}°C` | `Cooling to {target}°C...` |

#### 3.4.4 Ramp / hold / cooling logic (mirror exactly)
* `AMBIENT_TEMP = 25`; ramp seconds from `estimateHeatSeconds(from,to)` (13/50/80 s per °C bands — `lib/program-estimate.ts`).
* `rampProgress`: with the API connected it follows the **measured** temperature `(chamberTemp − rampStartTemp)/(target − rampStartTemp)`; off-API it is time-based and also fakes `chamberTemp`.
* Ramp ends when `chamberTemp >= target − 0.5` (API) or the estimated duration elapses (simulated). Then `setHeating(false)` and, for Cure/Bleacher steps with `uvStartMode !== 'at-start'`, `startPhaseUv()` issues `cure-405`/`cure-450` (UV comes on **only at target**).
* Hold timer: anchored on `performance.now()` (never by counting ticks), lazily re-anchored per phase, clamped to `time*60`. A `timerMode === 'on-ramp'` step counts through the ramp; `on-target` (default) parks the timer until the ramp ends.
* Phase completion (`:617-654`): **Cooling** completes on the measured temperature (`chamberTemp <= target + COOL_DONE_BAND (0.5)`), everything else on the hold timer. On completion: `reportPhaseTiming` (POST `/api/cure-runs/{id}/phase`), then next phase or finish.
* Finish: `POST /api/cure/stop` (non-immediate → heater fan cooldown run-on), `isComplete=true`, `wallTotal = now − processStart`, `completeCure(id)` (POST `finish`), and any `scure-pending-cure-logs` print rows are deleted.
* Nitrogen phase: `setNitrogenValve(true)` (`POST /api/cure/nitrogen?on=1`), counts `hw.nitrogenDuration` seconds, then valve off and advance.
* Overall progress: `totalElapsed / estimateProgram(filtered steps, {nitrogenSeconds}).totalSeconds`, capped at 100 %.
* 1 s tick interval runs only while `isRunning && !isComplete && !isPaused`.

#### 3.4.5 Commands issued per phase (`commandPhase`, `:184-217`)
| phase type | endpoint |
|---|---|
| heating | `POST /api/cure/heat?target=` |
| drying | `POST /api/cure/dry?target=` |
| cure, `temp == null` | `POST /api/cure/uv-only?wavelength=405&intensity=&vent=` |
| cure, ramping & `uvStartMode=at-target` | `POST /api/cure/heat?target=` (UV deferred) |
| cure, otherwise | `POST /api/cure/cure-405?target=&intensity=` |
| bleacher | same with `wavelength=450` / `cure-450` |
| cooling | `POST /api/cure/cool?target=&mode=` |

A refusal (`ok:false`) sets `phaseError`, raises `scure-alert` with `res.code ?? 6015`, and if it looks like a heater-sensor refusal (`code 9001` mentioning `TEMP_CHAMBER|chamber|heater`, or the message contains `thermistor`) freezes the clocks, pauses and opens `HeaterFaultModal(when:'start')`.

#### 3.4.6 Supervision, pause, abort, alerts during a cure

**Pre-flight fan test** (`:742-756`)
* Before the run: `POST /api/diagnostics/fan-test?fan=all` (20 s timeout). While running, a centred hint at `top-14`: **`Checking all fans before starting…`** (12 px muted).
* Any fan whose `status !== 'OK'` → `FanFailModal(when:'preflight')`. Off-API the check is skipped (`fanPreflight='ok'`).
* Only once `fanPreflight === 'ok'` does the auto-start effect (`:759-805`) run: `startCure(...)` (POST `/api/cure-runs/{id}/start` with material name, step count, phase names, first target temp, serial number), stale `doorAborted` is acknowledged (`POST /api/door-abort/ack`) and ignored for this run, wall clocks anchored, first phase commanded.

**Door opened mid-process** (`:405-441`)
* While running, not paused, API connected and `doorClosed === false`: a **10 s countdown** overlay (`bg-black/75`): `zinc-900` panel, 2 px `red-500` border, `rounded-2xl`, `AlertTriangle`44 red-500, `h2` 20 px bold **`Door Open — Process Paused`**, body `The chamber door was opened during an active process. The process cannot continue while the door is open.`, then bold `Close the door now, or the process will be aborted in`, the number in **48 px bold red-500**, and `seconds` (14 px zinc-500). Closing the door dismisses it.
* When the server flags `doorAborted` (door stayed open past the grace): `POST /api/cure/stop?immediate=1`, all local outputs cleared, `abortCure(id, activePhase)`, raise alert **6016**, `navigate('/')`.

**Fan failure during the cure** (`:446-468`)
Sources: `fanHealth[x].status === 'critical'` (not overridden) **or** active hw alerts **9002** / **9003** whose detail names a fan. → pause, `stop?immediate=1`, all outputs off, `FanFailModal(when:'running')`.
* `Continue anyway` → `POST /api/fans/override?fan=X&on=1` for each, then resume. Overrides are cleared (`on=0`) on completion and on unmount.
* `Stop process` → abort (or `navigate('/')` when it was the pre-flight).

**LED panel not heating (alert 9004)** (`:489-525`)
* When the UV turns on, snapshot every panel thermistor (`left/right/back/door`) that is `< 30 °C`; skip the `door` panel while bleaching (450 nm).
* Window: **15 s** normally, **30 s** when `uvIntensity < 60 %` or bleaching.
* Required rise: `need = max(0.35, 0.8 × intensity/100 × window/15 s)` °C.
* Panels below the threshold (not overridden) → pause, outputs off, `FanFailModal(kind:'led')`, and raise alert **9004** with detail `"{Panel}: +X.X °C in {N} s, …"`.
* `Continue anyway` marks those panels overridden and resumes; `Stop` aborts.

**Heater temperature sensor lost (9001)** (`:472-485`)
Active alert 9001 whose detail matches `TEMP_CHAMBER|heater` → pause, `stop?immediate=1`, outputs off, `HeaterFaultModal(when:'running')`. `Retry` = resume (re-sends the phase command, the machine re-checks the sensor); `Stop process` = abort.

**Temperature stall → alert 7004** (`:352-399`)
* Armed while ramping or in a cooling phase and not paused. Every **`STALL_CHECK_INTERVAL = 300000 ms` (5 min)** compare against the last sample: heating must rise ≥ 1 °C, cooling must drop ≥ 1 °C.
* No progress increments a retry counter; **`MAX_TEMP_RETRIES = 5`** (≈ 25 min) → the **Temperature Warning** overlay. Any progress resets the counter.
* Overlay (`bg-background/95`): 80 px `bg-yellow-500/20` circle + `AlertTriangle`48 yellow-500; `h2` 20 px bold **`Temperature Warning`**; `The system is unable to reach the target temperature of {target}°C. Current temperature: {chamberTemp}°C.`; yellow-400 medium `Continuing may cause distortion of the printed models.`; `Do you want to continue?`; buttons **`Abort`** (destructive) and **`Continue`** (primary), both `px-6 py-3 rounded-2xl`.
* `Continue` resets the counter and carries on; `Abort` → `stop?immediate=1`, `abortCure`, `navigate('/')`.
* Note: alert **7004** itself is raised from `HardwareContext` whenever a *new* heater/cooling fault appears in `/api/state` (`HardwareContext.tsx:167-172`).

**Pause / resume** (`:810-846`)
* `Pause` on the active PhaseCard → `PauseModal` confirmation → `handlePause`: freeze clocks, `POST /api/cure/stop?immediate=1` (no heater-fan run-on, so the server's door watchdog sees no live output), all local outputs off, `POST /api/door/open`.
* While paused, `PauseOverlay` is shown (unless a fan/LED/heater modal is up).
* `Continue` → shift **every** clock anchor (ramp, N₂, hold, phase wall, process wall) by the pause duration, re-send the phase command (UV still deferred if mid-ramp with `at-target`), re-open the N₂ valve on a purge step.

**Abort** (`:894-909`): clear fan overrides, `POST /api/cure/stop?immediate=1`, all outputs off, `abortCure(id, activePhase)` (POST `finish` with `status:'aborted'`), `setTargetTemp(null)`, `navigate('/')`.

**Telemetry** (`:691-738`): one sample at t=0, then every **5 s** → `POST /api/cure-runs/{id}/telemetry` `{t, chamberTemp, uvOn, uvType ('405nm'|'450nm'|null), fanRpm{FAN_*}, ledTemps{right,left,door,back}}`. `uvOn` is computed as "in a cure/bleacher phase, not paused, and (not ramping or `uvStartMode==='at-start'`)".

#### 3.4.7 Completion screen (`:1156-1180`)
`fixed inset-0 z-50 bg-background/95`, centred: 96 px `bg-green-500/20` circle + `CheckCircle`56 green-500; `h2` 24 px bold **`Cure Complete!`**; `The curing process for {material} has been completed successfully.`; stats row `Total time: {mm:ss}` · `{n} steps` (wall-clock total, not the sum of hold timers); primary button `DoorOpen`24 + **`Open Door`** (px-8 py-4, `rounded-2xl`, 18 px semibold) → `POST /api/door/open`, then after 500 ms `navigate('/')`.
The report itself is **not** generated here — it is exported later from Cure History.

---

### 3.5 CureHistoryPage (`pages/CureHistoryPage.tsx`)
`main.p-3` scrollable.
* Header: `Clock`16 muted + `h2` 14 px bold `Cure History` + `({logs.length})` (12 px muted).
* Empty: `No cure sessions yet.`
* Rows (`bg-card rounded-xl px-4 py-3 flex gap-3`):
  * Status icon 16: completed `CheckCircle` green-500 · aborted `AlertTriangle` orange-500 · error `XCircle` destructive · running `Play` primary `animate-pulse`.
  * `materialName` 14 px medium + status pill 9 px: `Completed` (green-500/15 · green-400), `Stopped` (orange), `Error` (destructive), `Running` (primary).
  * Second line: `formatDate(startedAt)` = `dd MMM yyyy HH:mm:ss` (`en-GB`) and, when ended, `to HH:mm`.
  * **Sensor issues** line (when `sensorIssues.length`): `AlertTriangle`10 + `Sensor disconnected during run: {labels}` — labels: `chamber→Chamber`, `left→Left LED`, `right→Right LED`, `back→Back LED`, `door→Door LED`. Colour destructive if any `critical`, else orange-400.
  * **Fan issues** line: `Fan below nominal during run: {Fan label} (-N %)` — labels: `FAN_HEATER→Heater fan`, `FAN_COOLING→Chamber cooling fan`, `FAN_LEFT/RIGHT/BACK/DOOR→Left/Right/Back/Door LED fan`.
  * Right: duration cyan-400 12 px (`{s}s` / `{m}m {s}s` / `{h}h {m}m`, `--:--` when null) and `{stepsCompleted}/{steps} steps` (9 px; orange-400 when incomplete).
  * **Report export button** (only when `telemetry.length > 0`): `Download`14 primary → `generateCureReport(log)` (`lib/cure-report.ts`) which builds a self-contained HTML report, `POST /api/cure-runs/{id}/report` (persist, best-effort) and `POST /api/system/export-report` (write to USB), falling back to a browser download off-device. Per-row feedback for 2.5 s: `saving` → pulsing muted `Download`; `ok` → `CheckCircle` (green-500 for a completed run, **orange-400** for a stopped one); `fail` → `XCircle` destructive.
* Report filename: `cure-report-{materialName}-{yyyy-MM-dd}.html`. Report content: Stratasys/sCure header, S/N, report id (first 8 chars), 8 metric cards (`Status`, `Duration`, `Steps`, `Max Temp`, `Cure · 405 nm`, `Bleaching · 450 nm`, `Temperature Sensors`, `Fans`), phase ribbon, and three charts: `Chamber temperature & UV light activity`, `LED module temperatures`, `Fan speeds`. USB failures surface codes **9081** (no USB) / **9082** (write failed).
* There is **no detail view / telemetry chart inside the app** — the chart lives in the exported HTML report. (If the Avalonia app should show a chart in-app, that is new scope; the React app only exports.)

---

### 3.6 AlertsPage (`pages/AlertsPage.tsx`)
Two views in one route.

**List view** (`main.p-3`)
* `Critical Errors` section (when non-empty): `AlertOctagon`16 red-500 + label red-400 14 px bold, then a `bg-card rounded-xl` group of rows.
* `Warnings` section: `AlertTriangle`16 orange-400 + label orange-400.
* Row (`px-4 py-3`, bottom border, hover `bg-accent`): code chip (10 px mono bold, `bg-red-500/20 text-red-400` or `bg-orange-500/20 text-orange-400`), `def.message` 12 px medium, a **28 px QR code** of `def.supportUrl` on a white 4 px pad, `ChevronRight`14. Tap → detail.
* Empty state: centred `All Clear` (green-400 18 px bold) + `No active alerts.` (12 px muted).

**Detail view** (card `rounded-xl p-4 max-w-2xl mx-auto space-y-4`)
1. Header: `ArrowLeft`20 back button, `AlertOctagon`24 red-500 (critical) or `AlertTriangle`24 orange-400, `{code}:` (red-400 mono) + `{message}` (14 px bold).
2. `Status:` + pill `Critical` / `Warning`.
3. `Problem Description` (`FileText`16 + 14 px bold): the raising layer's `alert.detail` (12 px foreground medium) when present, then `def.description` (12 px muted).
4. `Troubleshooting Steps` (`Wrench`16 + 14 px bold): ordered list of `def.troubleshooting`.
5. QR block: 80 px QR of `def.supportUrl` on white, caption `Scan for detailed documentation` (10 px) + the URL (10 px primary mono).
6. `Need Help?`: `Mail`14 primary + `support.email` (`support@scure.com`), `Phone`14 green-400 + `support.phone` (`+1-800-123-4567`), `MessageCircle`14 yellow-400 + `Live Chat`.
7. Actions: outline `Back`, primary **`Dismiss Alert`** → `dismissAlert(id)` then back to list.

**Alert registry** — `public/config/errors.json` (46 entries; bundled as a fallback for offline builds). Each entry: `code`, `key`, `message`, `severity ('critical'|'warning')`, `category`, `description`, `troubleshooting[]`, `supportUrl`, optional `legacyCode`. Support block: `email`, `phone`, `chat`, `docsBase` (`https://docs.scure.com/errors`; QR falls back to `{docsBase}/{code}`).

Codes the UI itself raises or reacts to:

| Code | Key | Severity | Message | Raised by |
|---|---|---|---|---|
| 6015 | PRECURE_CHECK_FAILED | critical | Pre-Cure Check Failed | default for any refused phase command |
| 6016 | DOOR_OPENED_MID_PROCESS | critical | Door Opened — Process Aborted | door watchdog abort; dismissing it calls `POST /api/door-abort/ack` |
| 7004 | CURE_TEMP_STALL | warning | Cure Temperature Stall | new heater/cooling fault in `/api/state` |
| 9001 | TEMP_SENSOR_DISCONNECTED | critical | Temperature Sensor Disconnected | machine; drives HeaterFaultModal |
| 9002 | FAN_FAILURE | critical | Fan Below Minimum Speed - System Stopped | machine |
| 9003 | LED_FAN_NOT_SPINNING | critical | LED Cooling Fan Not Spinning - Job Not Started | machine |
| 9004 | LED_NOT_HEATING | critical | LED Panel Not Heating - Check LED Connection | **UI** LED-rise check |
| 9050 | LED_TEMP_SENSOR_DISCONNECTED | warning | LED Temperature Sensor Disconnected | machine |
| 9052 | NFC_READER_NOT_DETECTED | warning | NFC Reader Not Detected | server refusal when enabling NFC |
| 9080 | UNKNOWN_DIAGNOSTIC_TOOL | warning | Unknown Network Tool | server |
| 9081 | USB_NOT_FOUND | warning | No Disk-on-Key Connected | CSV/report export |
| 9082 | USB_WRITE_FAILED | warning | Disk-on-Key Write Failed | CSV/report export |
| 9084 | NETWORK_STATUS_UNAVAILABLE | warning | Network Status Unavailable | server |
| 9085 | NETWORK_DIAGNOSTIC_FAILED | warning | Network Diagnostic Failed | server |
| 9089 | HW_API_UNREACHABLE | critical | Hardware Service Unreachable | **UI** when `/api/state` stops answering after having worked |

---

### 3.7 SettingsPage (`pages/SettingsPage.tsx`)
`main.p-3.overflow-y-auto`, `grid-cols-[1fr_220px] gap-3 h-full`. Local card helper = `bg-card rounded-lg p-2.5`; `Label` = 11 px muted; `InfoItem` = label left / 11 px semibold value right.

#### Left column
1. **System Name** — value `hw.systemName` (14 px bold) + 28 px `bg-secondary` square button with `Pencil`12 → `OnScreenKeyboard`. On keyboard close: `setSystemName(editingName)` → localStorage `scure-system-name` (no API).
2. **Power Options** + **Damper** (side by side)
   * Power: `REBOOT` (muted Btn) → `confirm('Reboot device?')` → `POST /api/system/reboot`; `SLEEP` (red Btn) → sessionStorage flag + reload (§1.7).
   * Damper: `OPEN` / `CLOSE` (active = primary) → `POST /api/damper/open|close`. Local state starts closed.
3. **Fan controls** — three `FanRow`s: `LED Cooling Airflow` (`led_cooling`), `Chamber Intake Fan` (`chamber_intake`), `Chamber Heating Fan` (`chamber_heating`).
   * Row: 130 px label (10 px), `{value}%` (9 px), `Progress h-1.5` with a transparent `input[range] 0..100` on top, static text `100% PWM`, outline `Test` button with `Fan`10 (spins while testing), and the result `{rpm} RPM **OK|FAIL**` (green-400 / destructive, 72 px right-aligned).
   * Slider change → local state immediately, **debounced 400 ms** → `POST /api/fans/{id}?speed={v}`.
   * `Test` → `POST /api/diagnostics/fan-test?fan={id}` (20 s). `ok = status === 'OK'` — a missing status (timeout) is a **failure**, message `no answer from the machine`. Fallback RPM display when the API gives none: `led_cooling 2850`, `chamber_intake 3050`, `chamber_heating 2780`.
   * For the LED group a failure line is rendered under the row (10 px destructive bold, indented 130 px): the failing fans by label (`FAN_LEFT→Left LED fan`, `FAN_RIGHT→Right LED fan`, `FAN_BACK→Back LED fan`, `FAN_DOOR→Door LED fan`) + ` — not rotating`, else the raw message.
4. **Chamber Heating** — label + a 16 px-tall gradient bar (`from-blue-500 via-yellow-500 to-orange-500`, rounded-full) with an invisible range input (25–80, step 1) and a 20 px white knob with a 2 px primary border positioned at `10px + (100% − 20px) × (v−25)/55`; plus a `TouchNumber` (25–80, step 1, suffix `°C`, 120 px).
   * Below 30 °C the value **snaps to 25 = OFF**. Debounced 400 ms: `v <= 25` → `POST /api/chamber/stop`; else `POST /api/chamber/temperature?target=v`. A refusal raises `scure-alert` (code `res.code ?? 6015`), resets the slider to 25, and if `code === 9001` or the message mentions `thermistor` opens `HeaterFaultModal(when:'start', stopLabel:'OK')`.
5. **LED Test** — label + purple `405 nm` button and blue `450 nm` button (both `Zap`11, 28 px high, disabled while running), `Running…` hint, then results: `{wavelength} nm` + **PASS** (green-400) / **FAIL** (destructive); on failure the panel names that did not heat are appended (`{wl} nm — Left, Door`), or `no answer`.
   * Calls `POST /api/diagnostics/led-test?seconds=15&min_rise=0.8&wavelength=405` (or `seconds=30…&wavelength=450`), 120 s timeout.
6. **Component Counters** — 3-column grid of `InfoItem`s with `{h.toFixed(1)}h`: `LED 405nm`, `LED 450nm`, `Cooling Fan`, `Heater`, `Heater Fan` (from `state.counters`).
7. **Info grid** (3 columns)
   * (`LED On Time` removed from the native UI in sCureBox 1.0.19, user decision 2026-09-16; `leadOnTimeHours` stays in system.json, unused.)
   * `N₂ Pressure` = `{n2LinePressure.toFixed(1)} bar` or `N/A`.
   * `Nitrogen Mode` + `Switch`: label gains `(min 6 bar)` in 9 px destructive when `n2LinePressure < 6`; the switch is **disabled** (and turning on is refused) while off and below 6 bar. Local/UI only — `setNitrogenMode` has no API call.
   * `NFC` + `Switch`: label gains `(no reader)` when the API reports `nfcReader.detected === false`; disabled while off and no reader. Change → `POST /api/nfc?on=` ; a refusal raises the returned code (9052) as an alert.
   * `BOFA Control` + `Switch` (default **on**) → `POST /api/bofa?on=`.

#### Right column
1. **Date & Time** — `Auto Sync` switch (default on).
   * Auto: read-only rows `Date` (`dd MMM yyyy`), `Time` (`HH:mm`), `Timezone` (resolved IANA zone, truncated).
   * Manual: native `date` and `time` inputs (11 px mono, 130 px) + full-width outline `Apply` → `POST /api/system/datetime` `{date,time}`; the button then shows `✓ Applied` / `✗ Failed` for 3 s.
2. **S/N** = `config.serialNumber`.
3. **Export Logs (USB)** — outline button `Download`13 + `Export Logs` → `POST /api/system/export-logs`; states `Exporting...` (bouncing icon) → `✓ Done!` / `✗ No USB drive found`, reset after 3 s.
4. **Software Update (USB)** — outline `Upload`13 + `Update Software` → `UpdateModal`.
5. **Compliance (CRA / EN 18031)** — outline `ShieldCheck`13 green-500 + `{n} controls active` (`control`/`controls` singular/plural; currently 2 of 4) → `ComplianceModal`.
6. **Organization**
   * Linked: the UUID in an 8 px mono inset box; outline `Building2`11 + `Change` (file picker) and a destructive outline `Unlink`11 icon button → `resetSetup()` (**clears setupComplete → the app returns to Setup**).
   * Not linked: outline `Building2`13 + `Link Organization`.
   * CSV parsing identical to Setup; failure text (9 px destructive): **`No valid ID found`**.
7. **Versions card** — `Software Version` (`config.firmware`), `Last Boot` (`dd MMM yyyy`), `Device` (`config.deviceName`).
   * Tapping the **version row** (stops propagation) opens `VersionsModal`.
   * Tapping **anywhere else on the card 10 times** performs a factory reset: `resetSetup()` (org cleared, `setupComplete=false`).

Modals mounted: `UpdateModal`, `HeaterFaultModal`, `VersionsModal`, `ComplianceModal`, `OnScreenKeyboard`.

**Not persisted anywhere**: damper state, fan percentages, chamber-heating slider, BOFA, date/time form, auto-sync, LED/fan test results (all reset on navigation).

---

### 3.8 NetworkPage (`pages/NetworkPage.tsx`)
`main.p-3`. Two tabs (`TabBtn`, 12 px medium, active = `bg-card border-border text-foreground`): **`STATUS`**, **`DIAGNOSTICS`**.

`GET /api/network/status` is polled every **3000 ms** (3 s) and maps to
`{ip (— when empty/0.0.0.0), mac, gateway (—), interfaces[], lanConnected = data.connected, internet, statusKnown}`. A failed poll sets `statusKnown=false`.

**STATUS tab** (cards `bg-card rounded-lg p-3 space-y-1.5`)
1. Connection: 10 px dot + label — `Status unavailable` (orange-400) when the API never answered, `Connected` (green) when `lanConnected`, `No Network` (destructive) otherwise; plus `API: OK` (9 px muted) when `hw.apiConnected`.
2. Network info rows (`InfoRow`: 12 px muted label / 12 px mono value): `IP Address`, `MAC`, `WireGuard IP` (always `—`; never populated).
3. Connection details: `Name` (`—`, or `static-eth0` after applying a static IP), `Protocol` (`ethernet`), `IP` (`{ip}/24`), `Gateway`.
4. Change Connection: label `Change Connection` + two buttons. **`STATIC IP`** pre-fills the form from the live values and opens the dialog. **`DHCP`** sets the local mode and posts `POST /api/network/static` `{dhcp:true}`. The highlighted button reflects the local `connectionMode` (default `dhcp`).

**Static IP Configuration dialog** (`sm:max-w-[380px] p-4`, no close button)
* Title 16 px `Static IP Configuration`.
* Four fields (11 px muted labels, mono 12 px inputs, 36 px): `IP Address *` (ph `<internal-ip>`), `Gateway *` (ph `<internal-ip>`), `Subnet Mask` (default & ph `255.255.255.0`), `DNS Server` (default & ph `8.8.8.8`).
* Validation: `Apply` enabled only when IP **and** Gateway match `/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/` (no range check, no inline error message).
* Footer: outline `Cancel`, primary `Apply` → optimistic local update (`ip`, `gateway`, `connectionName='static-eth0'`) + `POST /api/network/static` `{ip,gateway,subnet,dns}` (fire and forget).
* No on-screen keyboard here — these are real text inputs (on the device the kiosk has no soft keyboard, so a numeric keypad/OSK is a **porting gap worth fixing** in Avalonia).

**DIAGNOSTICS tab** — `grid-cols-[280px_1fr]`
* Left "Parameters" card: `Tool` radio group (custom 20 px square boxes, primary when chosen, 8 px white inner square): `Ping`, `Traceroute`, `DNS Lookup`. Address field is a `bg-secondary rounded-lg h-10` box showing the address; tapping it opens a **native `prompt('IP address or hostname:')`** (replace with a keyboard dialog in Avalonia). Default `8.8.8.8`. Caption `IP address or hostname`. Full-width primary `EXECUTE` (`Running...` while busy; disabled when busy or address empty).
* Right "Result" card: `bg-secondary rounded-lg p-3`, monospace 11 px **green-400** `<pre>` output. Placeholders: `Select a tool and press EXECUTE`; while running `Executing {tool} {address}...` (pulsing).
* `POST /api/network/diagnostics` `{tool,address}`, **60 s** timeout.
  * ok → `data.result` or `(no output — host unreachable or command produced nothing)`.
  * non-200 → `Diagnostics failed: API returned {status}`.
  * throw → `Diagnostics unavailable: the hardware API is not reachable.`
  * Server-side failures also produce alerts 9080 / 9085.

---

### 3.9 Developer pages

#### DevLayout (`pages/dev/DevLayout.tsx`)
Guard: `!devMode` → `Navigate to="/" replace`.
Banner (`px-3 py-1.5 bg-amber-500/15 border-y border-amber-500/40`): `TerminalSquare`16 amber-400 + `DEVELOPER MODE` (12 px bold `tracking-[0.2em]` amber-400) + (when not on the menu) an underlined link `Dev Menu`; right: amber outline button `LogOut`12 + **`Exit Developer Mode`** → `exitDevMode()`.
Below: scrollable `Outlet`.

#### DevMenuPage (`pages/dev/DevMenuPage.tsx`)
`main.p-4`, heading `Developer Tools` (12 px semibold `tracking-widest uppercase` muted), then one card-link per tool (`bg-card rounded-xl p-4`, 48 px amber icon tile, title 16 px semibold, description 12 px muted, `ChevronRight`20):
1. `LED Intensity Calibration` — `Per-zone calibration factors (Back / Door / Left / Right) that define the calibrated system LED power.` (`SlidersHorizontal`) → `/dev/led-calibration`
2. `Material HDT Calibration` — `Automatic 10–90% power sweep against a material HDT limit, measured on the PicoLog TC-08 (CH1).` (`ThermometerSun`) → `/dev/hdt-calibration`

#### LedCalibrationPage (`pages/dev/LedCalibrationPage.tsx`)
Model: `zoneOutput = clamp(requestedPower × factor, 0..100)`; zones `back, door, left, right`; labels `Back`, `Door`, `Left`, `Right`; `FACTOR_MIN 0`, `FACTOR_MAX 1.5`, `FACTOR_STEP 0.01`; factors loaded from `GET /api/dev/led-calibration` (default 1.00 each).
* Top card: `Requested System Power` (150 px label) + `Progress` with an invisible range (0–100, step 1) + `TouchNumber` (0–100, step 5, suffix `%`, 120 px) + a button `Zap`12 `Apply to LEDs` / (destructive) `ZapOff`12 **`LEDs ON — Turn Off`**. Default power **80 %**.
* While live, power/factor changes are pushed **debounced 300 ms** to `POST /api/dev/led-power {power, factors}`; leaving the screen always calls `POST /api/dev/led-power {power:0}` (`devLedOff`).
* 2×2 grid, one card per zone: zone label (14 px semibold) + `Actual Output: {x.x}%` (amber-400 bold); below, `Factor` + `Progress` at `factor/1.5` with an invisible range (0–1.5, step 0.01) + `TouchNumber` (2 decimals, 110 px). Every change is clamped, rounded to 2 dp and `devLog('{Zone} LED factor changed', {factor})`.
* Actions row: primary `Save`13 + `Save Calibration` → `POST /api/dev/led-calibration {factors}`; label becomes `✓ Calibration Saved` / `✗ Save Failed — Retry` for 3 s; disabled unless dirty (or after an error). Outline `RotateCcw`13 `Reset to Default` → `POST /api/dev/led-calibration/reset`. Outline `LogOut`13 `Exit` → `/dev`.
* Dirty hint (10 px amber-400): `Unsaved changes — the cure process and HDT calibration use the last saved factors.`

#### HdtCalibrationPage (`pages/dev/HdtCalibrationPage.tsx`)
Three modes: **setup** (`!running && !finished`), **running**, **finished**. One 1 Hz poll of `GET /api/dev/hdt/status?samplesFrom=N` drives status, PicoLog health and incremental samples; while in setup an extra 2 s poll of `GET /api/dev/picolog/status`.

* **Config card** (`Thermometer`16 amber): 4-column label/field grid — `Material HDT` (TouchNumber 30–150, step 1, `°C`; default **65**), `Stability Band` (0.5–10, step 0.5, `°C`; default **2**), `Safety Margin` (0–10, step 0.5, `°C`; default **2**), `Stability Time` (1–30, step 1, `min`; default **5**), `Recommended Max Temp` (read-only orange-400 `{hdt − margin}°C`), `Max Rate` (0–5, step 0.1, `°C/min`; default **0.5**, `0 = off`).
  While running/finished these become read-only values, and the `Stability Time` slot is replaced by `Rate now: ±x.xx°C/min` (amber when it exceeds the configured max).
* **PicoLog card** (250 px): `PicoLog TC-08` → `Connected`/`Not Connected`; `Channel 1` → `Available`/`Not Available`; `CH1 Temperature` → `{x.x}°C` or `N/A`; `pico.error` in 9 px destructive. Status rows show a 6 px dot + bold green/destructive text.
* **Live stats bar** (running/finished): `Activity`16 (amber pulsing while running) + `Test {i} of {n}`, `Test Power {p}%` (amber), `Raw CH1`, `Average`, `Step Time mm:ss`, `Total {h}h {m}m {s}s`; right side shows `status.message` or the final verdict.
  Final statuses: `COMPLETED` (green, `CheckCircle2`), `HDT_LIMIT_REACHED` (orange, `CircleAlert`), `ABORTED_BY_USER` (destructive, `XCircle`), `SENSOR_ERROR` (destructive, `XCircle`), `NOT_CONVERGED` (orange, `CircleAlert`).
* **Calibrated Physical Outputs** toggle (`Eye`/`EyeOff` 11): `Back: 80.0% (×1.00)` … per zone.
* **Chart** (recharts `LineChart`, `Model Temperature [°C] vs Time`): X = seconds formatted `mm:ss`; Y auto-domain always spanning past `HDT + 4`; grid `#333` dashed; two series — `Raw CH1` `#60a5fa` 1 px and `Average` `#facc15` 2 px (no dots, no animation); reference lines `HDT {x}°C` (`#ef4444`, dashed 6 3) and `HDT−{m}°C` (`#f97316`, dashed 4 3); a vertical dashed marker at each power-step transition labelled `{power}%`; tooltip `t = mm:ss` / `{x.x}°C`. Downsampled to ≤ 900 points. Placeholders: `Collecting temperature data…` / `No temperature data yet`.
* **Results panel** (290 px, when results exist): when finished — `Recommended System LED Power` + a 24 px green value (`{p}%` or `None`), the per-zone physical outputs at that power, and an optional **Boost** block (`Boost {p}%: {start}°C → {target}°C (HDT − margin)` + the time in amber + method + note). Then a table `Power | Stable | Time | Status` with per-step status labels `PASS` (green), `RUNNING` (amber), `NOT CONVERGED` (orange), `HDT LIMIT` (destructive), `ABORTED` (destructive), `NOT TESTED` (muted). Footer facts: `Duration:`, `Max measured temp:`, `Device: {info} · CH1`, `Factors: Back 1.00, …`.
* **Actions**
  * Setup: primary `Play`15 `Start Calibration`, enabled only when `hdtC >= 30` **and** PicoLog connected **and** CH1 available **and** a temperature is being read. Gate hints (10 px muted): `Connect the PicoLog TC-08 to enable calibration.` / `CH1 is not available — check the thermocouple.` / `Waiting for a valid CH1 temperature…` / `Enter a material HDT (≥ 30°C)`. Start → `devLog('Material HDT entered', {...})` + `POST /api/dev/hdt/start`; failure text = `res.message` or `Failed to start calibration (API unreachable)`.
  * Running: destructive `OctagonX`15 `Abort Calibration` → native `confirm('Abort HDT calibration? LEDs turn off immediately; collected data is preserved.')` → `POST /api/dev/hdt/abort`.
  * Finished: primary `Export Report (CSV)` (`GET /api/dev/hdt/report.csv` → `POST /api/system/export-csv` to USB, browser download off-device; filename `hdt-calibration-{ISO}.csv`; states `Exporting…` / `✓ CSV Exported` / `✗ Export Failed`), outline `Export Report (HTML)` (`lib/hdt-report.ts`; filename `hdt-calibration-report-{yyyy-MM-dd}.html`; sections `Material HDT Calibration Report`, `LED calibration factors · physical outputs at {p}% system power`, `Model temperature vs time`, `Results per calibrated system power level`), outline `RotateCcw`13 `New Calibration` → `POST /api/dev/hdt/reset` and clears local samples.

#### Developer log
There is **no dev-log screen**. `devLog(event, detail)` (`services/dev-api.ts:165-167`) fire-and-forgets `POST /api/dev/log {event, detail}`. Events emitted: `Developer Mode requested`, `Developer Mode authentication successful`, `Developer Mode authentication failed`, `Developer Mode entered`, `Developer Mode exited`, `{Zone} LED factor changed`, `LED calibration saved`, `LED calibration reset`, `Material HDT entered`, `Report exported`.

---

### 3.10 CsvBuilderModal — program editor (`components/CsvBuilderModal.tsx`)
The **real** program editor (New / Edit / Edit-a-duplicate), opened from Home.

Dialog: fixed **550 × 460 px**, `p-0`, no close button, column layout.
* **Top bar** (`px-4 py-2`, bottom border): title `New Program` / `Edit Program` (18 px); right `Name` label + a 260×40 tappable bordered box showing the name or `Tap to enter a name...` → replaces the dialog with `OnScreenKeyboard` while open.
* **Steps strip**: horizontal scroll (`touch-action: pan-x`), each step a 240 px bordered card (`rounded-xl p-3`, internally scrollable):
  * Header: `Step {n}` (primary 14 px) + ghost `Trash2`14 destructive (disabled when only one step remains).
  * `Process` — `Select` (140×36) limited to the allowed set (see below); option labels: `Drying`, `Heating`, **`Cure (405nm)`**, **`Bleaching (450nm)`**, `Cooling`, **`N₂ Purge`**.
  * Nitrogen → note only: `The N₂ purge runs automatically if nitrogen is enabled; otherwise it is skipped.`
  * Cooling → `Target Temp` TouchNumber (min **30**, max `max(30, prevTemp − 5)`, step 5, `°C`) and `Cooling Mode` Select (`Fast` / `Medium` / `Slow`, default medium).
  * Cure/Bleacher → `Chamber Heating` Select (`On` / **`Off (UV only)`**). When Off: `Ventilation` Select (`Off` / **`On (fresh air)`**). When On: `Temperature` TouchNumber (min = running minimum, max **80**, step 5).
  * Heating/Drying → `Temperature` TouchNumber (min = running minimum, max 80, step 5).
  * `Time` TouchNumber (min **1**, max **720** for Bleacher else **120**, step 1, suffix ` min`) — hidden for Cooling/Nitrogen.
  * Cure/Bleacher extras: `Timer Start` Select (`On ramp start` = `on-ramp` / **`At temperature`** = `on-target`) — only when heating is on; `UV Intensity` TouchNumber (min **10**, max **100**, step 5, `%`, default 30) — always; `UV Start` Select (`On ramp start` = `at-start` / **`At temperature`** = `at-target`) — only when heating is on.
  * (A legacy `Intensity` field exists but is disabled with `false &&`.)
  * `Add Step` tile: 70 px dashed button, `Plus`20 + `Add Step`; auto-scrolls the new card into view; auto-picks the process the sequence rules force (`Cure` after Nitrogen; `Cooling` after the Cure/Bleach that followed Nitrogen).
* **Bottom bar** (`px-4 py-2`, top border): outline `Download`14 `CSV`; summary `**{n}** steps · **{holdMinutes} min** holds · ~**{totalDuration} min** total`; spacer; outline `Cancel`; primary `Save Program` / `Update Program`.
* Validation (`saveError`, shown 12 px destructive centred above the bar when Save is pressed/held): `Enter a material name` · `Add at least one step` · `After an N₂ purge, add a Cure or Bleaching step` · `Add a Cooling step after the Cure/Bleaching step that follows the N₂ purge`.
* Sequence rules enforced by the allowed-process list: after `Nitrogen` only `Cure`/`Bleacher`; after that pair only `Cooling`; `Nitrogen` only if there has been a `Cooling` since the last `Nitrogen` and `nitrogenCount < 2`. Temperature monotonicity is enforced by clamping (later heat steps are pushed up; a following Cooling target is clamped to `prev − 5`, floor 30).
* CSV export: `stepsToCsv` (10 columns `Step,Process,Temperature,Time,TimerMode,UVIntensity,UVStart,UVRampPercent,CoolingMode,Ventilation`) then `POST /api/system/export-csv` (filename `{name|untitled}.csv`).
  Messages (12 px, green when ok, yellow when not): `Saved to USB` (or the server message) · **`No Disk-on-Key connected — connect one and try again`** (code 9081) · the server message for other codes · `File downloaded` (dev fallback). Failure codes are also raised as alerts.
* Save: `updateMaterial` (edit) or `addMaterial` (new) with `totalDuration = estimateProgramMinutes(steps)`; the modal resets to a single default step (`Heating 40 °C / 10 min`) and closes.

### 3.11 ImportCsvModal (`components/ImportCsvModal.tsx`)
Dialog `sm:max-w-[90vw] max-h-[85vh] p-4`, no close button.
* Title `Import from CSV`; description `Upload CSV files. Each file becomes a material in your list.`
* Left: dashed drop zone (also click → native multi-file picker, `accept=".csv"`): `Folder`36 yellow-400, `Tap to browse or drag files here` (12 px muted), `Unlimited files` (10 px).
* Right: `Expected CSV Format` table (10 px) with columns `Step | Process | Temp | Time | UV% | Mode` and the sample rows `1 Drying 40 10`, `2 Heating 60 5`, `3 Nitrogen`, `4 Cure 60 15 30`, `5 Bleacher 60 10 40`, `6 Cooling 30 · medium`; footnote: `Temp: 30-80°C (Cooling 30-75°C) · Time: 1-120 min (Bleaching up to 720) · UV: 10-100% · Mode: fast/medium/slow`.
* Results list (per file): `CheckCircle`14 green / `XCircle`14 destructive + `{fileName} — Added` / `— Failed`, with each parser error on its own 10 px destructive line.
* Footer: outline `Cancel`; primary `Done` (disabled while there are no results or any failure).
* Parser messages (`MaterialContext.parseCsv`, all user-visible here): `CSV must have a header row and at least one data row` · `Missing required header: "Step" or "Process"` · `Row {i}: Not enough columns (need at least 4)` · `Row {i}: Invalid process "{x}" (must be Heating, Drying, Cure, Cooling, Bleacher, or Nitrogen)` · `Row {i}: Invalid time "{x}" (must be 1-{120|720})` · `Row {i}: Invalid temperature "{x}" (must be {30}-{80|75} for {process})` · `Row {i}: Invalid UV intensity "{x}" (must be 10-100)` · `Step {n}: A maximum of 2 nitrogen purge steps is allowed` · `Step {n}: After nitrogen, only Cure or Bleaching is allowed` · `Step {n}: Only Cooling is allowed after the Cure/Bleaching step that follows the N₂ purge` · `Step {n}: Temperature ({t}°C) cannot be lower than the previous step ({p}°C) without a Cooling step` · `Step {n}: Cooling target ({t}°C) must be at least 5°C below the previous step ({p}°C)` · `Nitrogen must be vented — add a Cooling step after the N₂ purge` · `Add a Cure or Bleaching step after the N₂ purge` · `No valid steps found`.
* The imported material's name is the file name minus `.csv`; duration = `estimateProgramMinutes`.

### 3.12 PrintHistoryModal (`components/PrintHistoryModal.tsx`)
Dialog `sm:max-w-[90vw] max-h-[85vh] p-4`, no close button.
* Header: `Print History ({filtered}{/total when filtered})` + `— {n} selected`; right: `Filter`12 + `Filters` button with a count badge.
* Filter bar (`bg-secondary/50 rounded-lg p-2`): material Select (`All Materials` + distinct names), printer Select (`All Printers` + distinct), `From:` / `To:` date inputs, ghost `X`12 `Clear` (only when filters are active).
* Selection message strip: `Ready to cure {material}` (1 selected, green) · `Ready to cure {n}× {material}` (n of the same material, green) · **`⚠ Cannot cure different materials together!`** (destructive).
* Rows: 24 px checkbox (`Check`14 when selected), status icon, `printName` + `materialName`, `formatDate(date)` = `dd MMM yyyy HH:mm`, `{duration} min` cyan, `printerName` (only when an org is linked), `ChevronRight`. Tap with nothing selected = **pick that material and close**; tap with a selection = toggle; right-click/long-press = toggle.
* Empty: `No print history yet.` / `No results match the filters.`
* Footer: ghost `Clear Selection` (when any), spacer, outline `Close`, primary `Play`14 + **`Cure Together`** (only when the selection is curable) → set the material, store the selected ids in `sessionStorage['scure-pending-cure-logs']`, close, `navigate('/cure-process')`. Those print rows are deleted from history when the cure completes.

### 3.13 UpdateModal (`components/UpdateModal.tsx`)
Dialog `sm:max-w-[400px] p-4`, no close button. Title `Upload`16 + `Software Update`.
* Idle: `Insert a USB drive with a **.scu** update file, then press Update.` + a `bg-secondary` box: `The update will:` / `1. Find the update file on USB` / `2. Verify integrity (SHA-256)` / `3. Back up current version` / `4. Install new version` / `5. Restart services`.
* Running: step list with `Loader2` spinner / `CheckCircle` green / `XCircle` destructive. Steps in order: `Finding USB drive...` (700 ms synthetic), `Looking for update package...` (`GET /api/system/update/manifest` + `/package`), `Verifying integrity (SHA-256)...` (`lib/compliance.verifyUpdatePackage`), `Installing update...` (`POST /api/system/update`).
* Success box (`bg-green-500/10`): `Update successful!` / `Version: {v}` / `The system will restart.`
* Error box (`bg-destructive/10`): `Update failed` / `{message}` / `The previous version was restored.`
  Verification failures: `Missing or malformed checksum — update rejected` · `Checksum mismatch — the package is corrupt or has been tampered with`. Package lookup failure: `No update package found ({error})`.
* Footer: outline `Cancel` / **`Restart Now`** (after success; closing then triggers `window.location.reload()`), primary `RefreshCw`13 `Update` (idle) or `Retry` (error). Closing is blocked while running.

### 3.14 VersionsModal (`components/VersionsModal.tsx`)
Dialog `sm:max-w-[440px] p-4 max-h-[85vh]`, with close button. Title `Versions`.
* Live block (`bg-secondary`), from `GET /api/system/version`: `Software` (bold), `Build (git)` (`{commit} · {date}`), `OS`, `Kernel`, `Python`, `Last Boot`; `—` when unknown.
* `VERSION HISTORY` (11 px muted) from `/config/versions.json` → `history[]` newest first; each entry a `bg-secondary` card: `Tag`13 cyan + `v{version}` (14 px bold) + the date (10 px mono, right) + a bulleted `·` list of `notes`.
* Empty: `No version history available.`

### 3.15 ComplianceModal (`components/ComplianceModal.tsx`)
Dialog `sm:max-w-[520px] p-4 max-h-[90vh]`. Title `ShieldCheck`16 + `Cybersecurity Compliance`.
Sections (11 px uppercase headings): **`Standards`** (`CRA`, `EN 18031`, `EN 40000` with their long names), **`Controls in software`** (per control: `CheckCircle2` green / `Clock` muted, label, `ACTIVE`/`PLANNED` pill, detail text, and the mapped requirement ids in mono), **`Requirements (SRS §22)`** (`REQ-CRA-01…08` id + text + effective date `dd MMM yyyy`). Footer note: `Full EN 18031 / CRA conformity is a certification process; this panel reflects the code-level controls and the requirements they map to.`
Data is static in `lib/compliance.ts` (2 active controls: `Secure update — SHA-256 integrity verification`, `Software Bill of Materials (SBOM)`; 2 planned: `Network interface access control (RBAC)`, `Vulnerability & incident reporting (CRA Art. 14)`).

### 3.16 DevAuthModal (`components/DevAuthModal.tsx`)
Mounted globally in `App`. Dialog `sm:max-w-xs text-center`, **with** close button.
* Header: 48 px amber-500 tile + `TerminalSquare`26 black; title `Developer Mode` (18 px); description `Enter the Developer Mode password`.
* Four 14 px dots, filled amber when entered, destructive border on error; error line `Incorrect password` (12 px destructive, reserved height, invisible when no error).
* 3-column PIN pad: `1..9`, blank, `0`, `Delete`18 backspace. Keys 48 px, `bg-secondary`, 18 px semibold, `rounded-xl`.
* On the 4th digit, after a **150 ms** delay, `tryPassword`. Wrong → error + clear. Correct → dev mode + `/dev`.
* Outline full-width `Cancel` (and the X) close without entering dev mode. Content unmounts while closed, so state is always fresh.

### 3.17 MaterialEditorPage (`pages/MaterialEditorPage.tsx`) — legacy/orphan
Reachable only by typing `/material-editor`; nothing links to it and **Save Material does nothing** (no handler). Layout: `Program Name:` + read-only `Input` (tap → OnScreenKeyboard, default `Untitled`); pill button `+ Import CSV`; heading `Process Sequence`; a horizontal row of `StepCard`s (newest first) separated by `ArrowRight`16 and terminated by an 80 px dashed circular `Plus`28 button; floating `Save Material` button bottom-right. Opens `StepModal`, `ImportCsvModal`, `OnScreenKeyboard`. **Recommendation for the port: drop it** (its editing model is superseded by CsvBuilderModal), or re-implement as the same editor.

### 3.18 StepModal (`components/StepModal.tsx`) — used only by the legacy editor
Dialog `sm:max-w-[380px] p-6`, no close button. Header `Add Step` / `Edit Step` + `Step {n}`.
Fields (label left, 160 px control right): `Process Type` Select (`Drying`, `Heating`, `Cure (405nm)`, `Bleaching (450nm)`, `Cooling`, `Nitrogen`; default **Cooling**); `Chamber Heating` (`On`/`Off (UV only)`, Cure/Bleacher only); `Ventilation` (`Off`/`On (fresh air)`, no-heat only); `Temperature` / `Target Temp` TouchNumber (Cooling: 30…`maxCoolingTemp` default 75; others: `max(minTemp,30)`…80; step 5); Nitrogen note (same text as the builder); `Cooling Mode` (`Fast`/`Medium`/`Slow`); `Time` TouchNumber (1…720 Bleacher / 120 others, step 1, ` min`, default 10); `UV Intensity` TouchNumber (10–100, step 5, default 30); `Timer Start` and `UV Start` Selects (hidden on no-heat steps). Constants: `HEAT_MIN_TEMP 30`, `UV_MIN_INTENSITY 10`.
Footer: destructive `Delete` (edit only), spacer, outline `Cancel`, primary `Save`.

### 3.19 OnScreenKeyboard (`components/OnScreenKeyboard.tsx`)
Full-screen (`fixed inset-0`, z 99999, `#0a0a0a`), portalled into `#root` so it scales with the canvas.
* Top strip (bottom border `#222`): the live value in 24 px semibold white + a pulsing `#0ea5e9` caret `|`; right a `bg-#1a1a1a` button **`Close Keyboard`** (16 px).
* Four equal-height key rows, keys `bg-#1a1a1a`, white 24 px, `rounded-lg`, `active:bg-#333`, `select-none`:
  * Letters mode: `q w e r t y u i o p` + red-600 `⌫`; `a s d f g h j k l` (indented 3 %); `⇧` + `z x c v b n m ! ?` + `⇧`.
  * Numbers mode (`?123`): `1 2 3 4 5 6 7 8 9 0` + `⌫`; `@ # $ % & * - + ( )`; spacers + `" ' : ; / \ = _ ~` + spacers.
  * Bottom row: 60 px mode toggle `?123` / `ABC`, 48 px `,`, wide blank **space** bar, 48 px `.`, 90 px `bg-sky-500` **`Done`**.
* Shift is single-shot (auto-clears after a key). `Done` and `Close Keyboard` both call `onClose` — **there is no cancel**: the value has already been written through `onChange` on every keystroke. No length limit, no validation.
* In Avalonia: a modal overlay with the same 800×480 geometry; feed a bound string; `Done` = commit (callers persist on close).

---

## 4. Shared components (props & behaviour)

| Component | Props | Behaviour / geometry |
|---|---|---|
| `Button` (`ui/button.tsx`) | `variant` (default/outline/secondary/ghost/destructive/link), `size` (default/xs/sm/lg/icon/icon-xs/icon-sm/icon-lg), `asChild`, `disabled` | see §2.4; `active:translate-y-px`, disabled 50 % opacity, icons 16 px (14/12 px at sm/xs) |
| `Card` + `CardHeader/Title/Description/Content/Footer/Action` (`ui/card.tsx`) | `size: 'default'|'sm'` | `rounded-xl bg-card py-4 ring-1 ring-foreground/10`, content `px-4`, footer `border-t bg-muted/50`. **Only used indirectly** — Settings and Network define their own local `Card` (`bg-card rounded-lg p-2.5` / `p-3`) |
| `Dialog*` (`ui/dialog.tsx`) | `open`, `onOpenChange`, `showCloseButton` (default true), `onPointerDownOutside` | Portal into `#root`; overlay `bg-black/10` + `backdrop-blur-xs`; content centred, `bg-popover`, `rounded-xl`, `p-4`, `gap-4`, `ring-1`, default `sm:max-w-sm`; footer `-mx-4 -mb-4 border-t bg-muted/50 p-4`, column-reverse on narrow / row-end on `sm`; close button = ghost `icon-sm` `XIcon` at top-right |
| `Badge` (`ui/badge.tsx`) | `variant` (default/secondary/destructive/outline/ghost/link) | 20 px high pill, `rounded-4xl`, `px-2`, 12 px medium, 12 px icons |
| `Progress` (`ui/progress.tsx`) | `value` 0–100 | `h-1` track `bg-muted`, `rounded-full`, indicator `bg-primary` translated by `-(100−value)%`, `transition-all` |
| `Switch` (`ui/switch.tsx`) | `checked`, `onCheckedChange`, `disabled`, `size 'default'|'sm'` | 32×18.4 px (sm 24×14), thumb 16 px (sm 12), checked `bg-primary`, unchecked `bg-input`, thumb `bg-background`; enlarged invisible hit-area (`after:-inset-x-3 -inset-y-2`) |
| `Input` (`ui/input.tsx`) | native input props | 32 px, `rounded-lg`, `border-input`, transparent/`bg-input/30`, 16 px text (14 px ≥ md), focus ring 3 px `ring-ring/50` |
| `Separator` (`ui/separator.tsx`) | `orientation` | 1 px `bg-border` |
| `Select*` (`ui/select.tsx`) | `value`, `onValueChange`, `SelectTrigger/Value/Content/Item`, `position`, `side`, `sideOffset`, `disabled` per item | Radix select portalled like dialogs; triggers used at 140×36 / 160×40 / 140×32 |
| `TouchNumber` (`ui/touch-number.tsx`) | `value: number|null`, `onChange`, `min=0`, `max=100`, `step=1`, `disabled`, `placeholder='—'`, `suffix`, `className`, `decimals` | `rounded-lg border-input`, 36×36 `bg-secondary` `Minus`/`Plus` buttons, centred value (14 px medium, min 48 px); increments clamp to `[min,max]`; null starts from `min`. **The primary numeric input of the app — no keypad.** |
| `TouchSpinner` (`ui/touch-spinner.tsx`) | same minus `decimals` | 40 px tall field with stacked `ChevronUp/Down`; **currently unused** |
| `CircularGauge` (`components/CircularGauge.tsx`) | `value: string`, `label: string`, `progress: number`, `color` (stroke class), `size=90` | Two SVG circles, `strokeWidth 6`, `r=(size−6)/2`, rotated −90°, `strokeDasharray = circumference`, `strokeDashoffset = C − progress/100·C`, `strokeLinecap round`; track `#222`; centre: value 20 px bold white + label 9 px uppercase `tracking-wider` gray-400 |
| `PhaseCard` (`components/PhaseCard.tsx`) | `type` (heating/drying/cure/cooling/bleacher/nitrogen), `status` (active/completed/pending), `gaugeValue`, `gaugeLabel`, `gaugeProgress`, `minElapsed`, `secElapsed`, `percentComplete`, `onAbort?`, `onPause?`, `centerLabel?` | 240 px fixed width, `rounded-xl p-3 bg-card snap-start`; border: 2 px phase colour when active/completed, 1 px dashed border when pending. Badge (28 px pill) = icon + label (`Heating 🔥`, `Drying ⏱`, `Cure ✦`, `Cooling ❄`, `Bleaching ☀`, `N₂ Purge N₂`), `bg-secondary` muted when pending. Gauge 130 px: `cure`/`cooling` render a ring with a 40×2 px dash + centre caption (`UV + HEAT` / `COOL`, overridable) instead of a number; others use `CircularGauge`. Pending gauge at 40 % opacity and 0 progress. Bottom stats: three columns `MIN` / `SEC` / `DONE` (18 px bold values) with 1 px dividers above a `border-t`. Active cards show `Pause` (white button, 2 px phase-coloured border, `PauseCircle`14) and `Abort` (solid destructive) |
| `MaterialItem` (`components/MaterialItem.tsx`) | `label`, `duration?`, `isCommand?`, `isSelected?`, `isPreset?`, `isFavorite?`, `onToggleFavorite?`, `onClick?` | `rounded-2xl px-4 py-3 mb-2`; selected `bg-accent border-primary/60`, else `bg-card` hover `bg-accent`; `Star`18 (filled yellow-400 when favourite, else muted/60; tooltip `Add to favorites`/`Remove from favorites`, stops propagation), `Lock`16 for presets else `PlusCircle`20, label 17.5 px white, duration cyan-400 12 px, `ChevronRight`16 |
| `StepCard` (`components/StepCard.tsx`) | `step: StepData`, `onEdit` | 140–160 px card with a phase-coloured 1 px border; header = numbered circle + glyph + process name (`Bleaching` for `Bleacher`) + ghost `Pencil`12; info lines `Temp/Target`, `Heat: Off · Vent: On/Off`, `Mode:`, `Intensity:`, `UV:` (purple), `Time: {n} min`, `Timer: on ramp start` (orange 9 px); a decorative 1 px bar fixed at 15 % width |
| `SectionHeader` (`components/SectionHeader.tsx`) | `title`, `showActions`, `onAdd`, `onEdit` | 16 px semibold heading + optional ghost `Pencil`/`Plus` icon buttons. **Unused** |
| `StartCureButton` (`components/StartCureButton.tsx`) | — | Older/unused variant of the Home button (`rounded-xl px-5 py-2.5`, `Play`16) |
| `SCureLogo` | `size=24`, `color='currentColor'`, `className` | §2.6 |
| `WakeScreen` | `onWake`, `blank=false` | §1.5 |
| `BootScreen` | `onComplete` | §1.6 |
| `OnScreenKeyboard` | `isOpen`, `value`, `onChange`, `onClose` | §3.19 |
| `AbortModal` + exports `ABORT_HOT_CHAMBER_C = 40`, `HotSurfaceSign`, `HotChamberCaution` | `isOpen`, `onClose`, `onAbort`, `chamberTemp?` | Centred dialog `sm:max-w-md`: 48 px yellow-400 tile + `AlertTriangle`28 black; title 24 px **`Stop the Cure Process?`**; description `Stopping now **ends the cycle immediately** — it cannot be resumed. To open the door and continue later, use **Pause** instead.`; bullet list: `Eye`16 `The model's **appearance and surface finish** may be affected.`, `Box`16 `A partially cured model may **warp or lose its shape** and dimensional accuracy.`, then `HotChamberCaution`. Footer: outline `Keep Running`, solid destructive `Yes, Stop` |
| `HotSurfaceSign` | `size=36` | ISO 7010 W017 pictogram: triangle `M50 7 L95 88 H5 Z` fill `#F5C400` stroke `#111` 5 px; base bar `rect 30,70 40×7 r1.5 #111`; three heat waves at x 38/50/62 (`c-5 -6 5 -11 0 -17 c-5 -6 5 -11 0 -17`), stroke 5 round |
| `HotChamberCaution` | `chamberTemp?`, `className?` | Rounded row; **hot** (≥ 40 °C): `bg-destructive/15 border-destructive/40`, `Caution — hot surfaces inside.` (destructive) + `The chamber is at **{n}°C**. **Wear heat-resistant gloves** and avoid contact with the chamber and the model.`; **not hot**: `bg-accent/40`, orange heading + `The chamber and the model may still be warm — **wear gloves** when handling.` |
| `PauseModal` | `isOpen`, `onClose`, `onPause`, `chamberTemp?` | 48 px `bg-cyan-500/20` tile + `PauseCircle`30 cyan-400; title 24 px **`Pause the Process?`**; `Heating, UV and gas **stop** and the door is **released**. The current step is held and continues exactly where it stopped when you press Continue.`; yellow note box `AlertTriangle`16 + `**Note —** pausing interrupts the cure and may **affect the quality of the models** in the process (surface finish, shape and dimensional accuracy).`; `HotChamberCaution`; footer outline `Keep Running` + cyan `DoorOpen`16 **`Pause & Open Door`** |
| `PauseOverlay` | `doorClosed: boolean|null`, `chamberTemp`, `phaseName`, `apiConnected`, `onContinue`, `onStop` | Full-screen `bg-background/95`: 64 px cyan circle + `DoorOpen`36; `h2` 20 px **`Process Paused — Door Released`**; `Heating, UV and gas are **off**. The **{phase}** step is on hold and will continue exactly where it stopped.`; `HotChamberCaution`; gate line — green `Door closed — press Continue to resume heating and UV.` / orange `Close the chamber door to continue.`; buttons destructive `Square`18 `Stop Process` and primary `Play`18/`Lock`18 `Continue` (disabled — 40 % opacity — until `doorClosed === true`, always enabled off-API) |
| `FanFailModal` + exports `FAN_NAMES`, `LED_PANEL_NAMES` | `isOpen`, `kind: 'fan'|'led'`, `fans: string[]`, `when: 'preflight'|'running'`, `onContinue`, `onStop` | `max-w-md`, outside-press blocked. Titles: `Cure stopped — LED panel not heating` / `Cure stopped — fan failure` / `Fan failure — process not started`. Red box lists each item `Fan`14 + `{name} — not rotating` / `— did not heat up`. Explanations: LED = `The UV was on for 15 s (30 s at low power) and this panel's temperature sensor did not rise while the others did: the panel is not emitting (unplugged, driver, or its sensor is off the module). Every output was switched off and the program is paused where it was.`; running = `Every output was switched off and the program is paused where it was.`; preflight = `All fans were tested before starting; the one above did not turn.` Consequence line: LED = `**Continue anyway** finishes the cure with this panel dark — the part will be under-cured on that side. Otherwise stop and check the panel connector.`; fan = `**Continue anyway** runs the machine without this fan — the LED or heater it cools can overheat. The choice is recorded. Otherwise stop and check the fan connector and blades.` Footer: outline `Stop process` (running) / `Cancel` (preflight), destructive `Continue anyway`. Dismissing the dialog = Stop. `FAN_NAMES`: `FAN_LEFT/RIGHT/BACK/DOOR → Left/Right/Back/Door LED fan`, `FAN_HEATER → Heater fan`, `FAN_COOLING → Chamber intake fan`. `LED_PANEL_NAMES`: `left/right/back/door → Left/Right/Back/Door LED panel` |
| `HeaterFaultModal` | `isOpen`, `when: 'start'|'running'`, `message?`, `onRetry?`, `onStop`, `stopLabel?` | `max-w-md`, outside-press blocked. Title `Heater switched off — temperature sensor not reading` (running) / `Heater not started — temperature sensor not reading` (start). Red box `Thermometer`14 + `Heater temperature sensor (chamber) — no reading` + the machine's message. Body running = `The sensor the heater is controlled on stopped reading, so the machine switched the heater off at once. Every output is off and the program is paused where it was.`; start = `The heater is only switched on while its temperature sensor reads. The sensor reads open (unplugged) or out of range, so the heater was not started.` Footnote `Check the chamber thermistor cable and its connector on the IO board, then press Retry / try again. Err 9001 is on the Alerts screen.` Buttons: `{stopLabel ?? 'Stop process'|'Cancel'}` and `Retry` (when `onRetry`). **No "continue anyway"** — by design |
| `DevAuthModal` | — | §3.16 |
| QR codes | `QRCodeSVG value size` (qrcode.react) | 28 px in the alert list, 80 px in the detail, always on a white pad |
| Charts | recharts `LineChart` | only on the HDT page (§3.9) and inside the exported HTML reports (Chart.js-style canvases) |

**Toasts / banners**: there is **no toast system**. All feedback is either (a) inline text that reverts after 2.5–3 s (export/save/clock buttons), (b) an inline coloured banner (`phaseError`, CSV message, org error), or (c) a modal/full-screen overlay. The only persistent notification surface is the TopBar bell badge + Alerts page.

---

## 5. Client-side logic that must move into the native UI

1. **Program estimate** (`lib/program-estimate.ts`) — `AMBIENT_TEMP = 25`; heat bands s/°C `≤45 → 13`, `≤75 → 50`, else `80`; cool °C/min `fast 2.5 / medium 1.5 / slow 0.8`; `estimateProgram()` sums hold + ramp + cool + nitrogen, and for `timerMode === 'on-ramp'` adds only `max(0, ramp − hold)`; `estimateProgramMinutes = ceil(total/60)`. Consumers:
   * Home material rows `~{n} min`;
   * CsvBuilderModal footer (`holdMinutes` vs `~total`);
   * `addMaterialFromCsv` stores it as `totalDuration`;
   * CureProcess overall-progress denominator (with `nitrogenSeconds = nitrogenMode ? nitrogenDuration : 0`);
   * `estimateHeatSeconds` drives the simulated/estimated ramp duration and the ramp gauge off-API.
   Already summarised in `03-ui-and-qa.md §Program estimate` — keep one implementation in the Domain layer and have the UI call it.
2. **Phase sequencing state machine** — the whole of `CureProcessPage` (`03-ui-and-qa.md` line 12 documents it). Must be reproduced exactly (per-phase endpoint, ramp end at `target − 0.5`, cooling end at `target + 0.5`, hold clocks anchored to a monotonic clock, `on-ramp` vs `on-target`, deferred UV, pause/resume anchor shifting, phase-timing POST, pre-flight fan test, override lifecycle). The C# server also offers `/api/recipe/*`; if the Avalonia UI uses that instead, the UI must still render the same states, gauges and dialogs.
3. **Temperature-stall alert 7004** — two mechanisms: the UI's 5 min × 5-retry stall detector that raises the *Temperature Warning* overlay (Continue / Abort), and `HardwareContext`'s raise of registry code **7004** whenever a new `faults.heater` or `faults.cooling` string appears in `/api/state`.
4. **LED-not-heating check (9004)** — entirely client-side: snapshot panels < 30 °C when the UV turns on (skip `door` while bleaching), wait 15 s (30 s if intensity < 60 % or bleaching), require `max(0.35, 0.8 × intensity/100 × window/15)` °C rise, pause + modal + alert with the per-panel delta detail, allow per-panel override for the rest of the run.
5. **Alert persistence & lifecycle** (`AlertsContext`)
   * localStorage **`scure-active-alerts`**: `[{id, code, timestamp, dismissed, detail?}]`; written whenever the list is non-empty.
   * On load: drop codes missing from the registry; **drop undismissed 9052** (live condition, re-raised by the machine); if nothing undismissed remains, dev builds seed demo alerts `9082, 9089, 9084, 9080, 9085` (production seeds nothing — never fabricate alerts).
   * `triggerAlert(code, detail)` de-duplicates on `code` while undismissed but refreshes `detail`.
   * Global event bus: `window.dispatchEvent(new CustomEvent('scure-alert', {detail:{code, detail}}))` — used by HardwareContext, CureProcessPage, SettingsPage, CsvBuilderModal. In Avalonia: an `IAlertService.Raise(code, detail)`.
   * Dismissing **6016** (or `clearAll` with a live 6016) calls `POST /api/door-abort/ack`.
   * `POST /api/rgb/alerts?critical=&warning=` on every count change **and every 30 s** (the machine ignores a report older than 90 s).
   * `alertCount` counts only undismissed alerts that resolve in the registry.
6. **Favourites** — localStorage **`scure-favorite-materials`** (`string[]` of material ids, presets included); favourites sort first on Home; removing a material removes its id.
7. **System name** — localStorage **`scure-system-name`** (default `sCure`); set from Setup step 1 and Settings; shown in the TopBar; never sent to the API.
8. **Organisation / setup config** — localStorage **`scure-org`** = `{organizationId, setupComplete}`, layered over `/config/system.json`, plus live overrides of `firmware`/`lastBoot` from `GET /api/system/version`. Org id is extracted from a CSV by UUID regex. Presence of an org gates the Recent-Prints list, the `View All` button and the printer column.
9. **Other client state keys**
   * `sessionStorage['scure-shutdown']` — sleep flag (skips the boot screen on resume).
   * `sessionStorage['scure-pending-cure-logs']` — print-history rows to delete when the next cure completes.
10. **Everything else that is UI-only** (no server persistence): selected material/print, edit mode, dev-mode session flag and press counter, Settings fan/damper/heater/BOFA/date-time form values, LED & fan test results, network tab/mode/diagnostics, HDT setup values.
11. **Simulation fallbacks** — when `/api/state` is unreachable the UI fakes ramps, cooling and LED temperatures and falls back to bundled demo data (`data/demo-data.ts`: presets `ST45`, `Carbon Fiber`, `ABS-Like`, `Dental Model`, `Fiberglass`, `Flexible` + user programs, and demo prints). In the .NET port the *server* owns simulation (`03-ui-and-qa.md §Simulation thermal model`), so the UI-side fakery can be dropped — but the **API-down behaviour (alert 9089, "Status unavailable", `—` placeholders)** must stay.

---

## 6. Text strings (all user-visible strings, grouped by screen)

### Boot / wake
`sCure` · `System Diagnostics` · `CPU & Memory` · `GPIO Interface` · `Temperature Sensor` · `Heater Module` · `UV LED 405nm` · `UV LED 450nm` · `Cooling Fan` · `Heater Fan` · `Door Lock Sensor` · `Damper Motor` · `N₂ Line Pressure` · `Network Interface` · `Storage & Config` · `API Server` · `All systems operational` · `Starting sCure...` · `Tap to wake` · `Tap again to start`

### Setup
`sCure` · `Congratulations on your new sCure curing system.` · `Let's set it up in just a few steps.` · `Get Started` · `Name Your Cure Box` · `Choose a name to identify this device` · `Device Name` · `Tap to enter name...` · `Next` · `Give your cure box a name` · `NAME ME` · `???` · `Link Organization` · `Link {name} to your organization` · `Upload Organization CSV` · `Select the CSV file from the USB drive` · `Organization Found` · `from {file}` · `Change` · `No valid organization ID found in CSV file` · `Continue without organization`

### TopBar
`Open Door` · `Door Open` · `Target: {n}°C` · `N₂` · `DEV`

### Home
`Recent Prints` · `View All` · `No organization` · `Link an organization in Settings to view print history` · `No prints yet.` · `{n} min` · `{n}m ago` / `{n}h ago` / `{n}d ago` · `Program List` · `({n})` · `Edit` · `Done` · `CSV` · `+ New` · `Loading materials...` · `No materials yet. Upload a CSV or create a new material.` · `~{n} min` · `Duplicate` · `Delete` · `Add to favorites` · `Remove from favorites` · `Start Cure` · `Close the door to start the cure` · `A critical alert is active` · `Critical alert active` · `A cure cannot start while a critical alert is active. Handle it/them on the Alerts screen first:` · `{code} — {message} ({detail})` · `Close` · `Go to alerts` · `Cannot Start Cure` · `This material contains only nitrogen purge steps, but nitrogen is not enabled on the system.` · `Enable nitrogen in Settings or choose a different material.` · `OK`

### Cure process
`Cure` · `— {material}` · `{i}/{n}` · `Done` · `Cure complete!` · `N₂` · `Nitrogen Purge` · `{n}s remaining` · `{a}°C → {b}°C` · `Timer running — started with the ramp` · `Timer starts at target` · `Next` · `Final phase` · `Starting` · `Initializing...` · `Hold at {n}°C` · `Intensity {n}%` · `for {n} min` · `Process complete` · `Hardware: {message}` · `The hardware refused the command` · `UV command refused` · `Nitrogen valve command refused` · `Checking all fans before starting…`
Gauges/cards: `Heating` · `Drying` · `Cure` · `Cooling` · `Bleaching` · `N₂ Purge` · `RAMP °C` · `REMAINING` · `HOLD °C` · `COOL °C` · `SEC` · `MIN` · `DONE` · `UV + HEAT` · `UV ONLY` · `UV + VENT` · `COOL` · `Ramping...` · `Heating...` · `Drying...` · `Cooling to {n}°C...` · `UV curing at {n}%...` · `UV curing at {n}% (no heat)...` · `UV curing at {n}% (no heat, vented)...` · `N₂ purging...` · `Waiting...` · `Pause` · `Abort`
Overlays: `Temperature Warning` · `The system is unable to reach the target temperature of {n}°C. Current temperature: {n}°C.` · `Continuing may cause distortion of the printed models.` · `Do you want to continue?` · `Abort` · `Continue` · `Cure Complete!` · `The curing process for {material} has been completed successfully.` · `Total time: {mm:ss}` · `{n} steps` · `Open Door` · `Door Open — Process Paused` · `The chamber door was opened during an active process. The process cannot continue while the door is open.` · `Close the door now, or the process will be aborted in` · `seconds`

### Abort / pause / fault dialogs
`Stop the Cure Process?` · `Stopping now ends the cycle immediately — it cannot be resumed. To open the door and continue later, use Pause instead.` · `The model's appearance and surface finish may be affected.` · `A partially cured model may warp or lose its shape and dimensional accuracy.` · `Caution — hot surfaces inside.` · `The chamber is at {n}°C. Wear heat-resistant gloves and avoid contact with the chamber and the model.` · `The chamber and the model may still be warm — wear gloves when handling.` · `Caution — hot surface` (a11y) · `Keep Running` · `Yes, Stop` · `Pause the Process?` · `Heating, UV and gas stop and the door is released. The current step is held and continues exactly where it stopped when you press Continue.` · `Note — pausing interrupts the cure and may affect the quality of the models in the process (surface finish, shape and dimensional accuracy).` · `Pause & Open Door` · `Process Paused — Door Released` · `Heating, UV and gas are off. The {phase} step is on hold and will continue exactly where it stopped.` · `Door closed — press Continue to resume heating and UV.` · `Close the chamber door to continue.` · `Stop Process` · `Continue`
`Cure stopped — fan failure` · `Fan failure — process not started` · `Cure stopped — LED panel not heating` · `{fan} — not rotating` · `{panel} — did not heat up` · `Every output was switched off and the program is paused where it was.` · `All fans were tested before starting; the one above did not turn.` · `The UV was on for 15 s (30 s at low power) and this panel's temperature sensor did not rise while the others did: the panel is not emitting (unplugged, driver, or its sensor is off the module). Every output was switched off and the program is paused where it was.` · `Continue anyway runs the machine without this fan — the LED or heater it cools can overheat. The choice is recorded. Otherwise stop and check the fan connector and blades.` · `Continue anyway finishes the cure with this panel dark — the part will be under-cured on that side. Otherwise stop and check the panel connector.` · `Stop process` · `Cancel` · `Continue anyway`
`Heater switched off — temperature sensor not reading` · `Heater not started — temperature sensor not reading` · `Heater temperature sensor (chamber) — no reading` · `The sensor the heater is controlled on stopped reading, so the machine switched the heater off at once. Every output is off and the program is paused where it was.` · `The heater is only switched on while its temperature sensor reads. The sensor reads open (unplugged) or out of range, so the heater was not started.` · `Check the chamber thermistor cable and its connector on the IO board, then press Retry / try again. Err 9001 is on the Alerts screen.` · `Retry` · `OK`
Fan / LED labels: `Left LED fan` · `Right LED fan` · `Back LED fan` · `Door LED fan` · `Heater fan` · `Chamber intake fan` · `Chamber cooling fan` · `Left LED panel` · `Right LED panel` · `Back LED panel` · `Door LED panel`

### Cure history
`Cure History` · `({n})` · `No cure sessions yet.` · `Completed` · `Stopped` · `Error` · `Running` · `to {HH:mm}` · `Sensor disconnected during run: {list}` · `Fan below nominal during run: {fan} (-{n} %)` · `{n}/{n} steps` · `--:--` · `{n}s` / `{n}m {n}s` / `{n}h {n}m` · sensor labels `Chamber`, `Left LED`, `Right LED`, `Back LED`, `Door LED` · report messages `No telemetry recorded` · `Saved to USB` · `Downloaded in browser`

### Alerts
`Critical Errors` · `Warnings` · `All Clear` · `No active alerts.` · `Status:` · `Critical` · `Warning` · `Problem Description` · `Troubleshooting Steps` · `Scan for detailed documentation` · `Need Help?` · `Live Chat` · `Back` · `Dismiss Alert` · plus all 46 registry `message` / `description` / `troubleshooting` strings from `public/config/errors.json`, and support values `support@scure.com`, `+1-800-123-4567`, `https://docs.scure.com/errors`

### Settings
`System Name` · `Power Options` · `REBOOT` · `SLEEP` · `Reboot device?` · `Damper` · `OPEN` · `CLOSE` · `LED Cooling Airflow` · `Chamber Intake Fan` · `Chamber Heating Fan` · `100% PWM` · `Test` · `{n} RPM` · `OK` · `FAIL` · `— not rotating` · `no answer from the machine` · `Chamber Heating` · `LED Test` · `405 nm` · `450 nm` · `Running…` · `PASS` · `FAIL` · `no answer` · `Component Counters` · `LED 405nm` · `LED 450nm` · `Cooling Fan` · `Heater` · `Heater Fan` · `LED On Time` · `{n} hours` · `N₂ Pressure` · `{n} bar` · `N/A` · `Nitrogen Mode` · `(min 6 bar)` · `NFC` · `(no reader)` · `BOFA Control` · `Date & Time` · `Auto Sync` · `Date` · `Time` · `Timezone` · `Apply` · `✓ Applied` · `✗ Failed` · `S/N` · `Export Logs` · `(USB)` · `Exporting...` · `✓ Done!` · `✗ No USB drive found` · `Software Update` · `Update Software` · `Compliance` · `(CRA / EN 18031)` · `{n} control active` / `{n} controls active` · `Organization` · `Link Organization` · `Change` · `No valid ID found` · `Software Version` · `Last Boot` · `Device`

### Network
`STATUS` · `DIAGNOSTICS` · `Connected` · `No Network` · `Status unavailable` · `API: OK` · `IP Address` · `MAC` · `WireGuard IP` · `Name` · `Protocol` · `IP` · `Gateway` · `Change Connection` · `STATIC IP` · `DHCP` · `Static IP Configuration` · `IP Address *` · `Gateway *` · `Subnet Mask` · `DNS Server` · `<internal-ip>` · `<internal-ip>` · `255.255.255.0` · `8.8.8.8` · `Cancel` · `Apply` · `Parameters` · `Tool` · `Ping` · `Traceroute` · `DNS Lookup` · `Enter address...` · `IP address or hostname` · `IP address or hostname:` · `EXECUTE` · `Running...` · `Result` · `Select a tool and press EXECUTE` · `Executing {tool} {address}...` · `(no output — host unreachable or command produced nothing)` · `Diagnostics failed: API returned {status}` · `Diagnostics unavailable: the hardware API is not reachable.`

### Program editor (CsvBuilderModal / StepModal / StepCard)
`New Program` · `Edit Program` · `Name` · `Tap to enter a name...` · `Step {n}` · `Process` · `Process Type` · `Drying` · `Heating` · `Cure (405nm)` · `Bleaching (450nm)` · `Cooling` · `N₂ Purge` · `Nitrogen` · `Bleaching` · `The N₂ purge runs automatically if nitrogen is enabled; otherwise it is skipped.` · `Target Temp` · `Temperature` · `Cooling Mode` · `Fast` · `Medium` · `Slow` · `Chamber Heating` · `On` · `Off (UV only)` · `Ventilation` · `Off` · `On (fresh air)` · `Time` · `UV Intensity` · `Intensity` · `Timer Start` · `On ramp start` · `At temperature` · `UV Start` · `Add Step` · `CSV` · `{n} steps · {n} min holds · ~{n} min total` · `Cancel` · `Save Program` · `Update Program` · `Save` · `Delete` · `Add Step` / `Edit Step` · `Enter a material name` · `Add at least one step` · `After an N₂ purge, add a Cure or Bleaching step` · `Add a Cooling step after the Cure/Bleaching step that follows the N₂ purge` · `Saved to USB` · `No Disk-on-Key connected — connect one and try again` · `Could not save to the Disk-on-Key` · `File downloaded` · StepCard: `Temp:` `Target:` `Heat:` `Vent:` `Mode:` `Intensity:` `UV:` `Time: {n} min` `Timer: on ramp start`

### Import CSV
`Import from CSV` · `Upload CSV files. Each file becomes a material in your list.` · `Tap to browse or drag files here` · `Unlimited files` · `Expected CSV Format` · `Step` `Process` `Temp` `Time` `UV%` `Mode` · `Temp: 30-80°C (Cooling 30-75°C) · Time: 1-120 min (Bleaching up to 720) · UV: 10-100% · Mode: fast/medium/slow` · `{file} — Added` · `{file} — Failed` · `Cancel` · `Done` · plus every parser error listed in §3.11

### Print history modal
`Print History ({n})` / `({n}/{n})` · `— {n} selected` · `Filters` · `All Materials` · `All Printers` · `Material` · `Printer` · `From:` · `To:` · `Clear` · `Ready to cure {material}` · `Ready to cure {n}× {material}` · `⚠ Cannot cure different materials together!` · `No print history yet.` · `No results match the filters.` · `Clear Selection` · `Close` · `Cure Together`

### Update / versions / compliance
`Software Update` · `Insert a USB drive with a .scu update file, then press Update.` · `The update will:` · `1. Find the update file on USB` · `2. Verify integrity (SHA-256)` · `3. Back up current version` · `4. Install new version` · `5. Restart services` · `Finding USB drive...` · `Looking for update package...` · `Verifying integrity (SHA-256)...` · `Installing update...` · `Update successful!` · `Version: {v}` · `The system will restart.` · `Update failed` · `The previous version was restored.` · `Missing or malformed checksum — update rejected` · `Checksum mismatch — the package is corrupt or has been tampered with` · `Integrity verified (SHA-256)` · `No update package found ({err})` · `Cancel` · `Restart Now` · `Update` · `Retry`
`Versions` · `Software` · `Build (git)` · `OS` · `Kernel` · `Python` · `Last Boot` · `VERSION HISTORY` · `No version history available.` · `v{version}`
`Cybersecurity Compliance` · `Standards` · `Controls in software` · `Requirements (SRS §22)` · `ACTIVE` · `PLANNED` · `Full EN 18031 / CRA conformity is a certification process; this panel reflects the code-level controls and the requirements they map to.` · the `CRA` / `EN 18031` / `EN 40000` names, the four control labels/details, and `REQ-CRA-01…08` texts from `lib/compliance.ts`

### Developer mode
`Developer Mode` · `Enter the Developer Mode password` · `Incorrect password` · `Cancel` · `DEVELOPER MODE` · `Dev Menu` · `Exit Developer Mode` · `Developer Tools` · `LED Intensity Calibration` · `Per-zone calibration factors (Back / Door / Left / Right) that define the calibrated system LED power.` · `Material HDT Calibration` · `Automatic 10–90% power sweep against a material HDT limit, measured on the PicoLog TC-08 (CH1).`
LED page: `Requested System Power` · `Apply to LEDs` · `LEDs ON — Turn Off` · `Back` `Door` `Left` `Right` · `Actual Output:` · `Factor` · `Save Calibration` · `✓ Calibration Saved` · `✗ Save Failed — Retry` · `Reset to Default` · `Exit` · `Unsaved changes — the cure process and HDT calibration use the last saved factors.`
HDT page: `Material HDT` · `Stability Band` · `Safety Margin` · `Stability Time` · `Max Rate` · `Recommended Max Temp` · `Rate now:` · `off` · `≤ {n}°C/min` · `PicoLog TC-08` · `Connected` · `Not Connected` · `Channel 1` · `Available` · `Not Available` · `CH1 Temperature` · `N/A` · `Test` · `Test Power` · `Raw CH1` · `Average` · `Step Time` · `Total` · `PASS` · `RUNNING` · `NOT CONVERGED` · `HDT LIMIT` · `ABORTED` · `NOT TESTED` · `COMPLETED` · `HDT LIMIT REACHED` · `ABORTED BY USER` · `SENSOR ERROR` · `Calibrated Physical Outputs` · `Model Temperature [°C] vs Time` · `HDT {n}°C` · `HDT−{n}°C` · `Collecting temperature data…` · `No temperature data yet` · `Recommended System LED Power` · `None` · `Boost {n}%: {a}°C → {b}°C (HDT − margin)` · `Power` `Stable` `Time` `Status` · `Duration:` · `Max measured temp:` · `Device: {info} · CH1` · `Factors: {list}` · `Start Calibration` · `Connect the PicoLog TC-08 to enable calibration.` · `CH1 is not available — check the thermocouple.` · `Waiting for a valid CH1 temperature…` · `Enter a material HDT (≥ 30°C)` · `Failed to start calibration (API unreachable)` · `Abort Calibration` · `Abort HDT calibration? LEDs turn off immediately; collected data is preserved.` · `Export Report (CSV)` · `Export Report (HTML)` · `Exporting…` · `✓ CSV Exported` · `✓ HTML Exported` · `✗ Export Failed` · `New Calibration`

### Keyboard
`Close Keyboard` · `Done` · `?123` · `ABC` · `⇧` · `⌫`

### Legacy editor (only if kept)
`Program Name:` · `Untitled` · `+ Import CSV` · `Process Sequence` · `Save Material`

---

## 7. Porting notes / gaps worth deciding before implementation

1. **Non-uniform canvas scaling** — the React app stretches X and Y independently. On a 1280×800 panel that is 1.6× / 1.667×, i.e. ~4 % vertical distortion. Decide whether Avalonia reproduces this exactly (fidelity) or uses uniform scaling with letterboxing (looks better).
2. **Native browser dialogs** must be replaced: `confirm('Reboot device?')`, `confirm('Abort HDT calibration? …')`, `prompt('IP address or hostname:')`.
3. **Text inputs without an on-screen keyboard**: the Static IP dialog and the Settings date/time inputs rely on browser widgets. On a touch kiosk these need the OSK / a numeric keypad.
4. **File pickers**: Setup org CSV, Settings org CSV, ImportCsvModal (multi-select + drag & drop) all use the browser file dialog. Replace with a USB-drive browser served by the backend, or an Avalonia file dialog.
5. **`/material-editor`, `StepModal`, `StepCard`, `SectionHeader`, `StartCureButton`, `TouchSpinner`** are dead or near-dead code — confirm before porting.
6. **Print-log duration** is rendered as `"{duration} min"` in the UI while the API contract defines it in seconds (`01-api-contract.md §4`). Decide the unit and fix it in one place.
7. **BootScreen checks are cosmetic.** If the .NET app should show real diagnostics, wire the 14 items to actual probes — but keep the same labels, order and progress display.
8. **`WireGuard IP`** is displayed but never populated; `connectionName` only ever shows `—` or `static-eth0`.
9. **Sleep is a UI state, not a power state** — no `/api/system/shutdown` call exists anywhere in the UI.
10. **Report generation is HTML produced client-side** (`lib/cure-report.ts`, `lib/hdt-report.ts`) then written to USB / persisted. In .NET this is a natural server-side responsibility; if it moves, the button states and messages above must still be reproduced.

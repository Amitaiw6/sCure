---
name: shutdown-proof-on-the-output
description: DVT rule from the user (2026-09-06) — every test that expects a shutdown proves it on the output, not the controller: heater cut-off on the heater-body thermocouple (TC-08), LED cut-off on the Ophir StarBright trace
metadata:
  type: feedback
---

The user (2026-09-06, on DVT-SAF-003): "the test is done with a thermocouple on the heater body — important to do this on every test where we want to see a shutdown, it is more correct."

**Why:** the SSR command / software log only says what the controller *thinks* it did; the heater-body temperature turning from rising to falling is the physical proof power was removed. Same logic for LEDs: the Ophir irradiance trace, not the uvOn flag.

**How to apply:** any DVT test that expects the heater to cut (SAF-003/004/005/013/014/015 already converted) must: equipment = PicoLog TC-08 + type-K thermocouple bonded to the heater body (the DVT-SAF-013 bond, logged at 1 Hz, TC-08 clock as time base); inject the fault in the heat-up phase with the heater at FULL output so the rise-to-fall turn is unmistakable; capture heater_body_drop_observed + heater_off_time (fault → turn) and put both in pass_criteria; note the measurement is conservative (thermal lag) and a trace FAIL is cross-checked at the SSR output. LED shutdown tests use the Ophir trace (< 10 % of plateau) — see [[dvt-campaign-tool]].

---
name: feedback-no-rpm-damper-check
description: Do not build a damper-position check from chamber cooling fan RPM - user judged it not strong enough
metadata:
  node_type: memory
  type: feedback
  originSessionId: 9c39147e-10c2-4f32-85a8-dbb9744f95b3
  modified: 2026-10-01T12:10:08.505Z
---

Do not add a check/alarm that infers the damper position from FAN_COOLING RPM. Logging the RPM and damper_open in DVT traces is fine.

**Why:** user, 2026-10-01: "I wouldn't add such a check, it's not strong enough" - even though the bench showed a clean, repeatable difference (60 %: open ~2,470 vs closed ~2,690 RPM; 100 %: ~4,075 vs ~4,735).

**How to apply:** if damper position must be verified, propose a direct means (limit switch / position feedback), not RPM inference. Separate open issue: components.json FAN_COOLING nominal RPM matches the damper CLOSED, so fast cooling (damper open, ~15 % below nominal) can trip the 10 % wear warning 9051 - not decided. See [[project-io-board-confirmed-wiring]].

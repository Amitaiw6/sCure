# QA report

2026-10-11 00:47 - **141/141 checks passed**

| Result | Check | Detail |
|---|---|---|
| PASS | README reference present: 01-api-contract.md |  |
| PASS | README reference present: 01-working-rules/ |  |
| PASS | README reference present: 02-hardware-map.md |  |
| PASS | README reference present: 02-port-specs/ |  |
| PASS | README reference present: 03-qa/ |  |
| PASS | README reference present: 03-ui-and-qa.md |  |
| PASS | README reference present: 04-ui-spec.md |  |
| PASS | README reference present: 04-versioning/sCureBox-CS-versions.json |  |
| PASS | README reference present: 05-native-ui.md |  |
| PASS | README reference present: 05-original-repo-bmad/ |  |
| PASS | README reference present: 06-examples/ |  |
| PASS | README reference present: 06-srs.md |  |
| PASS | README reference present: 3-cure-history-delete.png |  |
| PASS | README reference present: 4-drying-wind-icon.png |  |
| PASS | README reference present: AGENTS.md |  |
| PASS | README reference present: CLAUDE.md |  |
| PASS | README reference present: MANIFEST.md |  |
| PASS | README reference present: QA-REPORT.md |  |
| PASS | README reference present: _bmad-manifest.yaml |  |
| PASS | README reference present: feedback_bash_backslashes.md |  |
| PASS | README reference present: feedback_no_rpm_damper_check.md |  |
| PASS | README reference present: feedback_pi_bench_scripts.md |  |
| PASS | README reference present: feedback_qa_tests.md |  |
| PASS | README reference present: feedback_shutdown_proof.md |  |
| PASS | README reference present: feedback_srs_authoring.md |  |
| PASS | README reference present: feedback_ui_consistency.md |  |
| PASS | README reference present: feedback_version_bump.md |  |
| PASS | README reference present: feedback_worktree_junction.md |  |
| PASS | README reference present: project_parallel_sessions.md |  |
| PASS | README reference present: project_srs_diagrams.md |  |
| PASS | README reference present: project_ui_english_conventions.md |  |
| PASS | README reference present: project_versioning.md |  |
| PASS | README reference present: qa_count_tests.mjs |  |
| PASS | README reference present: qa_package.py |  |
| PASS | README reference present: redact.py |  |
| PASS | README reference present: run-all.ps1 |  |
| PASS | README reference present: sCure-A-qa-tool.html |  |
| PASS | README reference present: sCureBox-CS-README.md |  |
| PASS | example screenshot 1a- |  |
| PASS | example screenshot 1b- |  |
| PASS | example screenshot 2a- |  |
| PASS | example screenshot 2b- |  |
| PASS | example screenshot 2c- |  |
| PASS | example screenshot 3-cure-history-delete.png |  |
| PASS | example screenshot 4-drying-wind-icon.png |  |
| PASS | port spec 01-api-contract.md |  |
| PASS | port spec 02-hardware-map.md |  |
| PASS | port spec 03-ui-and-qa.md |  |
| PASS | port spec 04-ui-spec.md |  |
| PASS | port spec 05-native-ui.md |  |
| PASS | port spec 06-srs.md |  |
| PASS | non-empty qa_count_tests.mjs |  |
| PASS | non-empty qa_package.py |  |
| PASS | non-empty README.md |  |
| PASS | non-empty redact.py |  |
| PASS | non-empty 01-working-rules/feedback_bash_backslashes.md |  |
| PASS | non-empty 01-working-rules/feedback_no_rpm_damper_check.md |  |
| PASS | non-empty 01-working-rules/feedback_pi_bench_scripts.md |  |
| PASS | non-empty 01-working-rules/feedback_qa_tests.md |  |
| PASS | non-empty 01-working-rules/feedback_reply_in_hebrew.md |  |
| PASS | non-empty 01-working-rules/feedback_shutdown_proof.md |  |
| PASS | non-empty 01-working-rules/feedback_srs_authoring.md |  |
| PASS | non-empty 01-working-rules/feedback_ui_consistency.md |  |
| PASS | non-empty 01-working-rules/feedback_version_bump.md |  |
| PASS | non-empty 01-working-rules/feedback_worktree_junction.md |  |
| PASS | non-empty 01-working-rules/project_error_registry.md |  |
| PASS | non-empty 01-working-rules/project_parallel_sessions.md |  |
| PASS | non-empty 01-working-rules/project_srs_diagrams.md |  |
| PASS | non-empty 01-working-rules/project_ui_english_conventions.md |  |
| PASS | non-empty 01-working-rules/project_versioning.md |  |
| PASS | non-empty 02-port-specs/01-api-contract.md |  |
| PASS | non-empty 02-port-specs/02-hardware-map.md |  |
| PASS | non-empty 02-port-specs/03-ui-and-qa.md |  |
| PASS | non-empty 02-port-specs/04-ui-spec.md |  |
| PASS | non-empty 02-port-specs/05-native-ui.md |  |
| PASS | non-empty 02-port-specs/06-srs.md |  |
| PASS | non-empty 02-port-specs/sCureBox-CS-README.md |  |
| PASS | non-empty 03-qa/qa-tests.js |  |
| PASS | non-empty 03-qa/README.md |  |
| PASS | non-empty 03-qa/run-all.ps1 |  |
| PASS | non-empty 03-qa/run-qa.mjs |  |
| PASS | non-empty 03-qa/sCure-A-qa-tool.html |  |
| PASS | non-empty 04-versioning/sCureBox-CS-errors.json |  |
| PASS | valid JSON 04-versioning/sCureBox-CS-errors.json |  |
| PASS | non-empty 04-versioning/sCureBox-CS-versions.json |  |
| PASS | valid JSON 04-versioning/sCureBox-CS-versions.json |  |
| PASS | non-empty 05-original-repo-bmad/AGENTS.md |  |
| PASS | non-empty 05-original-repo-bmad/bmad-skills-installed.txt |  |
| PASS | non-empty 05-original-repo-bmad/claude-settings.json |  |
| PASS | valid JSON 05-original-repo-bmad/claude-settings.json |  |
| PASS | non-empty 05-original-repo-bmad/CLAUDE.md |  |
| PASS | non-empty 05-original-repo-bmad/project-context.md |  |
| PASS | non-empty 05-original-repo-bmad/_bmad-manifest.yaml |  |
| PASS | non-empty 05-original-repo-bmad/_bmad-custom/bmad-agent-architect.toml |  |
| PASS | non-empty 05-original-repo-bmad/_bmad-custom/bmad-agent-dev.toml |  |
| PASS | non-empty 05-original-repo-bmad/_bmad-custom/bmad-build.toml |  |
| PASS | non-empty 05-original-repo-bmad/_bmad-custom/bmad-code-review.toml |  |
| PASS | non-empty 05-original-repo-bmad/_bmad-custom/bmad-review.toml |  |
| PASS | non-empty 05-original-repo-bmad/_bmad-custom/config.toml |  |
| PASS | non-empty 05-original-repo-bmad/_bmad-output-planning-artifacts/deferred-findings.md |  |
| PASS | non-empty 05-original-repo-bmad/_bmad-output-planning-artifacts/final-review.md |  |
| PASS | non-empty 05-original-repo-bmad/_bmad-output-planning-artifacts/performance-review.md |  |
| PASS | non-empty 05-original-repo-bmad/_bmad-output-planning-artifacts/qa-report.md |  |
| PASS | non-empty 05-original-repo-bmad/_bmad-output-planning-artifacts/refactor-architecture-plan.md |  |
| PASS | non-empty 06-examples/screenshots/1a-dropdown-before-clipped.png |  |
| PASS | non-empty 06-examples/screenshots/1b-dropdown-after-floating.png |  |
| PASS | non-empty 06-examples/screenshots/2a-precheck-before-overlapping-fades.png |  |
| PASS | non-empty 06-examples/screenshots/2b-precheck-after-holds-spinner.png |  |
| PASS | non-empty 06-examples/screenshots/2c-precheck-after-cure-page-already-running.png |  |
| PASS | non-empty 06-examples/screenshots/3-cure-history-delete.png |  |
| PASS | non-empty 06-examples/screenshots/4-drying-wind-icon.png |  |
| PASS | spec copy current (after redaction): 01-api-contract.md |  |
| PASS | spec copy current (after redaction): 02-hardware-map.md |  |
| PASS | spec copy current (after redaction): 03-ui-and-qa.md |  |
| PASS | spec copy current (after redaction): 04-ui-spec.md |  |
| PASS | spec copy current (after redaction): 05-native-ui.md |  |
| PASS | spec copy current (after redaction): 06-srs.md |  |
| PASS | secret scan ran on all text files |  |
| PASS | sCureBox-CS commits (60) in README as 60 | git says 60 |
| PASS | sCure-A commits (89) in README as 89 | git says 89 |
| PASS | sCureBox-CS co-authored 50 | git says 50 |
| PASS | sCure-A co-authored 82 | git says 82 |
| PASS | no commit mentions BMAD (both repos) |  |
| PASS | no BMAD / CLAUDE.md / AGENTS.md in sCureBox-CS |  |
| PASS | no BMAD / CLAUDE.md / AGENTS.md in sCure-A |  |
| PASS | C# test attributes total 607 (README says 607) | {"SCureBox.Api.Tests": 50, "SCureBox.Application.Tests": 189, "SCureBox.Domain.Tests": 139, "SCureBox.Hardware.Tests": 59, "SCureBox.Ui.Tests": 170} |
| PASS | sCureBox-CS QA tests 110 in 16 categories (README 110 / 16) |  |
| PASS | sCure-A QA tests 290 in 29 categories (README 290 / 29) |  |
| PASS | versions.json entries CS 194 (README 194) | 194 |
| PASS | versions.json entries sCure-A 201 (README 201) | 201 |
| PASS | sCureBox-CS VERSION 1.0.81 (README 1.0.81) | 1.0.81 |
| PASS | BMAD skills in original repo: 49 (README 49) |  |
| PASS | BMAD planning artifacts: 5 (README 5) |  |
| PASS | no other BMAD outputs (PRD/epics/stories/specs) |  |
| PASS | BMAD version 6.11.0, installed 2026-08-17 |  |
| PASS | package skills list matches zip |  |
| PASS | artifact copy identical: deferred-findings.md |  |
| PASS | artifact copy identical: final-review.md |  |
| PASS | artifact copy identical: performance-review.md |  |
| PASS | artifact copy identical: qa-report.md |  |
| PASS | artifact copy identical: refactor-architecture-plan.md |  |

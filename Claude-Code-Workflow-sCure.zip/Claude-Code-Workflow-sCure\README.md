# How the sCure software was built with Claude Code

**For:** Denys Pavliuk.
**From:** Amitai Wecker.
**Date:** 2026-10-11.
**Scope:**
- the Python / React app (`sCure-A`);
- the snapshot of it that went to the team repo (`origin_hw-main` → `sCure IOB/SW_BR_EMB`, v0.4.9);
- the .NET 8 port (`sCureBox-CS`, now v1.0.81).

You asked two things:

1. Show me how you worked with Claude Code and the workflow behind the implementation.
2. Did the older Python app use the same approach? It used to have BMAD artifacts inside.

The short answers are below, followed by the details and a map of the files in this package. Every number comes from the repos or from git, not from memory. Section 9 explains how they were checked.

---

## 1. Short answers

**Workflow.** There was no formal process framework. The work ran as one tight loop between the engineer (me) and Claude Code, repeated hundreds of times:

1. **Ask.** I state the request, often with a screenshot from the machine or the demo.
2. **Change.** Claude reads the code and makes the change.
3. **Test.** The change comes with automated tests.
4. **Verify.** Claude runs the change, in the simulator or on the real unit.
5. **Ship.** Claude bumps the version, writes a changelog entry, commits and pushes.

What keeps the loop safe is a small set of **standing rules** and the **test and QA harnesses**, not a planning phase.
- The rules are stored as Claude Code memory files. They are in `01-working-rules/`.
- The test and QA harnesses are described in sections 4–5.

**BMAD.** BMAD was used in the **team repo snapshot only**, and only once, for one refactor.
- In `SW_BR_EMB`, BMAD **v6.11.0** was installed on **2026-08-17**, with 49 `bmad-*` skills plus team customizations.
- Its only outputs are **5 planning/review documents** from that same day, all for one refactor (`refactor/clean-architecture`):
  - architecture plan;
  - final review (APPROVE);
  - QA report;
  - performance review;
  - deferred findings.
- It produced no PRD, epics, stories or implementation specs.

Neither repo the work continued in uses BMAD: `sCure-A` and `sCureBox-CS` have no `_bmad`, `CLAUDE.md` or `AGENTS.md`, and no commit mentions BMAD. The C# port was **not** built with BMAD. It was built with the approach in sections 2–6. Everything BMAD-related is in `05-original-repo-bmad/` so you can see exactly what it was.

---

## 2. Setup

| Item | What was used |
|---|---|
| Tool | Claude Code, mostly the VS Code extension on Windows 11, some terminal sessions |
| Models (from commit trailers) | sCure-A: Fable 5 ×74, Fable 5.1 ×4, Opus 4.6 ×3, Opus 4.8 ×1. sCureBox-CS: Opus 5.5 ×24, Fable 5.1 ×17, Opus 5 (1M context) ×9 |
| Share of commits co-authored by Claude | sCure-A **82 of 89**; sCureBox-CS **50 of 60** (those commit messages end with a `Co-Authored-By: Claude …` line) |
| Repos | `sCure-A`: 89 commits, 2026-03-02 → 2026-09-15, plus uncommitted work up to v0.9.92. `sCureBox-CS`: 60 commits, 2026-09-10 → 2026-10-11, v1.0.81 |
| Hardware access | Real test unit (CM5 on the sCure IO board) over SSH / NetBird; PicoLog TC-08 thermocouples and an Ophir StarBright UV meter on the bench PC |
| Language | Requests in Hebrew; code, docs, UI text and commits in English |

**No `CLAUDE.md` was used.** The standing instructions live in Claude Code's **project memory**: one Markdown file per rule, plus an index that loads into every session. The process-relevant ones are copied into `01-working-rules/`. Machine addresses and credentials are left out.

---

## 3. The loop, step by step

This is what one change looks like in practice. Four real examples from the last two days, with before/after screenshots, are in `06-examples/` (see section 7).

1. **Request.** A short instruction, usually with a screenshot of the problem: "the drop-down should float above everything", "drying max 50 °C", "delete a run from the history".
2. **Read before writing.** Claude finds the code involved: view, view model, store, API, tests. It reports what it found when that matters (for example: "the start call runs on the UI thread, that is why the spinner freezes"). Wide searches go to a sub-agent so the main context stays clean.
3. **Change, minimal and local.** Follow the existing patterns and comment density. No new frameworks, no speculative abstractions.
4. **Tests with the change.** In sCureBox-CS, xUnit, including headless Avalonia UI tests. In sCure-A, a QA test in `qa-tool/index.html` (standing rule: every feature gets QA tests).
5. **Run it.**
   - **Simulation.** The C# UI runs on the PC with `SCURE_SIMULATE=1`. It exposes QA endpoints (`/api/ui/navigate`, `/api/ui/tap?x=&y=`, `/api/ui/screenshot`), so Claude drives the real UI and reads the screenshots to check the result visually.
   - **Real unit.** Claude reads live state, logs and bench instruments over SSH. Safety-relevant behavior is verified on the machine: heater cut-off on the heater-body thermocouple, UV cut-off on the StarBright trace.
6. **Version + changelog.** Standing rule: every code change bumps `VERSION` and adds an entry to `config/versions.json` (shown in Settings → Versions). sCureBox-CS has **194** entries; sCure-A has **201**.
7. **Commit + push.** The commit message describes the user-visible behavior and ends with the Claude co-author line.
8. **Deploy, when asked.**
   - `deploy/publish.ps1` builds the release.
   - The installer pushes it to the unit.
   - The unit's live config stays separate from the shipped one: `/etc/scurebox/components.json` is never overwritten by an update.

The human stays in charge of:
- what to build;
- what counts as correct (for example, the exact fault criteria);
- when something goes to the machine;
- every hardware action.

Claude asks before anything outward-facing or hard to undo.

---

## 4. The C# port (`sCureBox-CS`): a spec-first strategy

The port is where a "method" is most visible.

1. **Contracts first.**
   - On **2026-09-14** one commit created the solution skeleton together with the port specs:
     - `01-api-contract.md`: the HTTP API ported from Flask; the JSON must match exactly.
     - `02-hardware-map.md`: GPIO / I2C / PWM register sequences and polarities, from `io_controller.py`.
     - `03-ui-and-qa.md`: how the existing React UI and QA suite are reused unchanged.
   - It also created `reference/`: the original Python sources, kept read-only as the source of truth for porting.
   - All of these are in `02-port-specs/`. The `reference/` sources are in the repo only.
2. **Step A: same API, same UI.**
   - Because the API contract was byte-compatible, the React UI (`ui/dist`) and the QA suite ran unchanged against the new .NET host.
   - That gave a working machine and a regression net before any UI was rewritten (commit `1eba1f8`, 2026-09-15).
3. **Step B: native UI.**
   - `04-ui-spec.md` (a 1:1 spec of every React screen) and `05-native-ui.md` drove an Avalonia UI.
   - It runs in the same process as the firmware, on DRM/KMS with no window manager.
4. **Layering.** As described in `sCureBox-CS-README.md`: UI → Application → Domain (pure) → Hardware (GPIO / I2C / PWM / PIO, simulation, safety) → Host (ASP.NET Core + systemd).
5. **Descriptive SRS afterwards.** `06-srs.md` (Rev A, 2026-09-23, written against v1.0.32) documents what the code does. Every statement points to its source location, and there is a known-gaps list. It is also generated as a Word file in the Stratasys template (`docs/srs/`).

---

## 5. Quality gates

| Layer | sCureBox-CS | sCure-A |
|---|---|---|
| Unit / integration | **607** test attributes across 5 test projects: Domain 139, Application 189, Hardware 59, Api 50, Ui 170 (headless Avalonia) | pytest / vitest gates (per the original AGENTS.md) |
| Live API QA | `qa/run-qa.mjs` + `qa-tests.js`: **110** tests in 16 categories against a running server; `run-all.ps1` chains unit → integration → headless QA in simulation | `qa-tool/index.html`: **290** tests in 29 categories, browser harness against the live API |
| UI checks | Simulation + `/api/ui/*` QA endpoints + screenshots read by Claude | Same idea, with Puppeteer screenshot scripts in `tools/` (`shoot.mjs`, `ui-preview.cjs`) |
| Hardware | Bench scripts on the unit (nohup + done-flag, config always restored); DVT tool | DVT campaign tool (`DVT/`, 40 tests, PySide6 app) |
| Errors | Central `errors.json` registry: every fault code, title and description in one file, used by UI, reports and SRS | Same registry (48 codes) |

The harnesses are in `03-qa/`. The test projects themselves are in the repo under `tests/`.

---

## 6. Working rules that shaped the code

These are the persistent rules. Each one exists because a specific problem happened, and the files in `01-working-rules/` say why.

- **Version bump on every change.** `feedback_version_bump.md`, `project_versioning.md`.
- **Every feature gets QA tests.** `feedback_qa_tests.md`.
- **One visual language across the UI**, and US-English UI conventions. `feedback_ui_consistency.md`, `project_ui_english_conventions.md`.
- **Prove a shutdown on the output.** Heater cut-off is proven on the heater-body thermocouple and UV cut-off on the optical trace, never on the controller's own state. `feedback_shutdown_proof.md`.
- **No guessed requirements in the SRS.** Unknowns go to an Open Issues list. `feedback_srs_authoring.md`, `project_srs_diagrams.md`.
- **No inferred safety checks the engineer rejected** (for example, no damper position derived from fan RPM). `feedback_no_rpm_damper_check.md`.
- **Bench discipline on the Pi.** nohup + done-flag, never kill the SSH session, always restore config. `feedback_pi_bench_scripts.md`.
- **Parallel sessions.** Several Claude sessions sometimes work on the same repo and the same Pi at once. The rule is to re-read `VERSION`, error codes and process state before writing, and never to stop another session's processes. `project_parallel_sessions.md`.
- **Tool quirks.** `feedback_bash_backslashes.md`, `feedback_worktree_junction.md`.

---

## 7. Examples in this package

`06-examples/screenshots/` shows four changes made on 2026-10-10/11. Each followed section 3 end to end.

| # | Request | What was found / done | Files |
|---|---|---|---|
| 1 | "The drop-down should be a floating window above everything" | The list lived inside the step card and was clipped by its ScrollViewer. A `FloatingList` control was added that moves the list to a shell-level layer and aligns it to the field. Process, Timer Start and UV Start all use it. Headless test checks the position. v1.0.77 | `1a-…before…`, `1b-…after…` |
| 2 | "Keep the pre-check spinning until the checks finish; smoother transitions" | The program start (fan spin-up + RPM check, several seconds) ran on the UI thread, and a page change closed the dialog. The start now runs on a worker and the dialog stays up across the page change until the run's first status arrives. Fades are eased. v1.0.80 | `2a-…before…`, `2b`, `2c` |
| 3 | "Delete one run or all; keep the last 25; delete in the cloud too" | Store `Delete` / `DeleteAll` (JSON + Postgres), retention of 25 runs, a cloud deletion queue sent on the next sync, and a portal endpoint. Tests at store, sync-agent and UI level. v1.0.78 | `3-cure-history-delete.png` |
| 4 | "A real drying icon, same for N₂" | New vector glyphs (wind, gas cylinder) in the existing icon set. v1.0.81 | `4-drying-wind-icon.png` |

The full history of such changes is the changelog: `04-versioning/sCureBox-CS-versions.json`, newest first.

---

## 8. If you want to work the same way

1. Open the repo in Claude Code and let it read `docs/01–06` first. They are the map.
2. Run `qa/run-all.ps1` once, so you have a green baseline in simulation.
3. Copy the rules from `01-working-rules/` you agree with into your own Claude Code memory or a `CLAUDE.md`. At minimum: version bump, tests with every change, the shutdown-proof rule.
4. For UI work, run the simulator (`SCURE_SIMULATE=1`) and let Claude drive it through `/api/ui/*` and check screenshots.
5. Keep the human decisions human: fault criteria, limits, what goes to the machine.

---

## 9. How the numbers were checked

- **Commits and authors:** `git log` / `git shortlog` / `git log --grep "Co-Authored-By"` in each repo, on 2026-10-11.
- **Tests:** a count of `[Fact]` / `[Theory]` / `[AvaloniaFact]` / `[AvaloniaTheory]` attributes per test project. The QA tests were counted by loading the real test tables in Node (`qa_count_tests.mjs`), not by text search.
- **BMAD:** read from `origin_hw-main.zip`: the BMAD manifest (copied here as `_bmad-manifest.yaml`), `.claude/skills/`, `_bmad-output/`. Then a search for `_bmad`, `CLAUDE.md`, `AGENTS.md` and "bmad" in commit messages of both working repos (none found).
- **Package contents:** listed in `MANIFEST.md`. They were checked against this document by `qa_package.py` (see `QA-REPORT.md`).
- **Redaction:** copied text files had internal machine addresses, the NetBird host, the SSH key file name and the developer-mode PIN replaced by placeholders (`redact.py`). The originals in the repos are unchanged. Because the PIN is a placeholder, developer-mode login in the copied `sCure-A-qa-tool.html` will not work as-is.

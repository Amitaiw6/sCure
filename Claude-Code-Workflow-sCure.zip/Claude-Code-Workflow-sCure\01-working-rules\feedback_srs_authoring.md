---
name: feedback-srs-authoring
description: How the user wants the sCure Box SRS written — requirements/logic only, HTML is the UI reference, editable flow charts, never guess
metadata:
  type: feedback
---

When writing the sCure Box SRS, follow this approach (the user is building it collaboratively, screen by screen):

- **Focus on system requirements and logic.** Do NOT describe architecture or technical implementation.
- **An HTML file is the reference source for the UI/UX and screen structure.** Do NOT describe screen visual design and do NOT create/generate images. To explain how the user moves between screens, rely on the provided HTML only.
- **Flow charts are required and must be in an editable format** so the user can change them himself later. Use Mermaid (editable text); adapt to the exact flow-chart style the user provides.
- **Never guess missing information.** Mark gaps as an **Open Issue** and ask the user questions until it is clear.
- **The application source code (`src/`) is the authoritative source for screen LOGIC** — derive behavior from it instead of inventing. E.g. the onboarding screens (Setup welcome / Setup Name / Connect Organization) live in `src/pages/SetupPage.tsx`; persistence in `src/context/SystemConfigContext.tsx`; later org change in `src/pages/SettingsPage.tsx`. When the user says "take the logic from the code," read the relevant component. Domain facts the code doesn't capture (e.g. that `organizationId` is mirrored to both Storage and SD) come from the user — incorporate them.
- The document must be professional and ready for software, QA, and systems teams.

**Why:** The user owns the domain knowledge and the UI design; the SRS must reflect what he actually specifies, not invented detail.

**How to apply:** Write each screen's purpose + logic + functional requirements + an editable flow chart, reference the HTML for UI/navigation, and collect every uncertainty in an Open Issues section with concrete questions. Related: [[feedback-ui-consistency]].

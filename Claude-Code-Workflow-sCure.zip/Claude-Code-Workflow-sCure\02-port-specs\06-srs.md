# sCureBox software requirements specification (SRS)

**Product:** sCure Box post-curing unit — CM5 firmware and operator UI (`sCureBox-CS`)
**Document:** `docs/06-srs.md`, revision A, 2026-09-23, written against software version **1.0.32**
**Status:** descriptive SRS — it states what the software in this repository does today, with the source
location of every statement. Where behaviour is missing, partial or contradictory it is listed in §12
instead of being smoothed over.

## How to read this document

| If you want | Go to |
|---|---|
| What the product is and what it runs on | §1–§3 |
| How the software is put together | §4 |
| How a cure program actually runs, step by step, with flow charts | §5 |
| What the operator may build and what is refused | §6 |
| Every external interface: HTTP, hardware, files | §7 |
| How a unit is imaged, installed, updated and reached remotely | §8 |
| Numbered requirements to review or test against | §9, §10 |
| How each area is verified | §11 |
| What is *not* implemented | §12 |

Companion documents, not repeated here:
`01-api-contract.md` (every endpoint and JSON payload), `02-hardware-map.md` (chips, channels, registers),
`03-ui-and-qa.md` (React-era UI and QA conventions), `04-ui-spec.md` (screen-by-screen UI specification),
`05-native-ui.md` (Avalonia hosting model).

Flow charts are Mermaid, so they are editable text and render in GitHub and VS Code.
Requirement identifiers are stable: `SRS-<area>-<n>`. Every requirement names its source file so a
reviewer can check the claim.

---

## 1. Purpose and scope

### 1.1 Purpose

The software drives a post-curing appliance for 3D-printed resin parts. It heats a chamber, exposes the
part to 405 nm or 450 nm UV light, optionally purges with nitrogen, cools the chamber down, records what
happened, and refuses or stops anything that would be unsafe or out of specification.

This SRS covers the software only: the .NET 8 firmware, the operator UI, the local HTTP API, the
supervision and safety logic, persistence, and the installation and update tooling in this repository.

### 1.2 Scope of the delivered software

In scope:

* Execution of a multi-step cure program on the machine's hardware.
* The touchscreen operator UI on the machine, including program building and history.
* Local HTTP API on port 3001 used by QA tooling, the legacy browser UI and remote support.
* Supervision: sensors, fans, door, LED panels, and an out-of-process output watchdog.
* Persistence of programs, runs, phase timings, print history, calibration and counters.
* Imaging, installation, update and remote access tooling for a unit.

Out of scope for this document: the mechanical design, the IO board schematic (see `02-hardware-map.md`),
the certification test plan, and the DVT campaign tooling that lives in the sibling repository.

### 1.3 Definitions

| Term | Meaning |
|---|---|
| Unit | One machine: Raspberry Pi CM5 on the IO board, inside the appliance |
| Firmware | The .NET process that owns the hardware and the API (`scurebox` / `scurebox-ui`) |
| Program (material) | An ordered list of steps the operator can save, name and re-run |
| Step | One process phase with its own parameters, for example "Cure 60 °C, 20 min, 80 %" |
| Run | One execution of a program, with its own identifier, timings and report |
| Process type | Heating, Drying, Cure, Cooling, Bleacher, Nitrogen |
| Ramp | The part of a step spent reaching the target temperature |
| Hold | The part of a step spent at the target temperature |
| Simulation | Mode in which no IO board is present and the hardware layer is emulated |
| `hwSource` | Reported hardware source: `io_controller` for a real board, `simulation` otherwise |

---

## 2. System context

```mermaid
graph LR
  OP["Operator at the touchscreen"] --> UI["sCureBox UI, Avalonia on DRM/KMS"]
  UI --> FW["Firmware: process engine, supervision, stores"]
  FW --> HW["IO board: PCA9685, TCA6424A, ADS1115, GPIO, PIO"]
  HW --> MACH["Machine: heater, UV panels, fans, damper, N2 valve, door magnet"]
  QA["QA tool / headless QA runner"] --> API["HTTP API on :3001"]
  SUP["Remote support over NetBird"] --> API
  PC["Windows installer on a PC"] -->|"SSH / USB"| FW
  API --- FW
  WD["Watchdog process: scurebox --watchdog"] -->|"reads heartbeat"| FW
  WD -->|"cuts heater and UV on silence"| HW
```

The firmware and the UI are **one process**; the API is hosted inside it. The watchdog is a **second,
independent process** so that it survives a firmware crash.

---

## 3. Operating environment and modes

### 3.1 Target

| Item | Value |
|---|---|
| Computer | Raspberry Pi Compute Module 5 with eMMC |
| OS | Raspberry Pi OS, Debian 13 "trixie", 64-bit |
| Runtime | .NET 8, self-contained `linux-arm64` publish, no SDK on the unit |
| Display | 10.1" DSI Touch Display 2, portrait panel driven rotated |
| Network | Wired Ethernet; remote access through NetBird when enrolled |
| Install path | `/opt/scurebox` |

### 3.2 Execution modes

| Mode | How it starts | What differs |
|---|---|---|
| Normal (native UI) | `scurebox-ui.service` | UI plus firmware plus API in one process |
| Headless firmware | `scurebox.service` | API plus the bundled browser UI, no Avalonia |
| Watchdog | `scurebox-watchdog.service` | Only the output watchdog, no hardware ownership except the cut path |
| Simulation | `SCURE_SIMULATE=1`, or no IO board present | Hardware emulated, `hwSource` reports `simulation` |
| QA | Any of the above plus the QA tooling in `qa/` | Adds UI automation endpoints |

### 3.3 Users

| User | Uses |
|---|---|
| Operator | Touchscreen: pick or build a program, run it, read the report |
| Service technician | Settings, diagnostics, LED and fan tests, calibration, update |
| QA / engineering | HTTP API, QA tool, headless runner, simulation on a PC |
| Manufacturing | Imaging and installer tooling on a Windows PC |

---

## 4. Software architecture

### 4.1 Layers

Dependencies point downward only. The domain layer is pure: no I/O, no timers, no hardware.

```mermaid
graph TD
  UIL["SCureBox.Ui — Avalonia screens, dialogs, view models"]
  APIL["SCureBox.Api — ASP.NET Core minimal API, hosting, systemd integration"]
  APPL["SCureBox.Application — process execution, supervision, stores, platform services"]
  HWL["SCureBox.Hardware — I2C, GPIO, PWM, PIO, simulation, safety cut"]
  DOM["SCureBox.Domain — rules, state machines, validation, error registry"]
  UIL --> APIL
  UIL --> APPL
  APIL --> APPL
  APPL --> HWL
  APPL --> DOM
  HWL --> DOM
```

| Project | Files | Lines | Owns |
|---|---|---|---|
| `SCureBox.Domain` | 46 | 2 653 | Recipe state machine, validators, estimator, sensor and fan rules, error codes |
| `SCureBox.Application` | 106 | 9 303 | Cure controller, recipe runner, supervision, device loops, stores, platform services |
| `SCureBox.Hardware` | 36 | 3 752 | Board drivers, sensor conversion, simulation, safety cut, watchdog |
| `SCureBox.Api` | 24 | 1 402 | Host, DI composition, HTTP endpoints, heartbeat, systemd |
| `SCureBox.Ui` | 135 | 12 455 | Shell, pages, dialogs, editor, boot screen, report rendering |

### 4.2 Process and hosting model

* `SCureBox.Ui/Program.cs` builds the firmware host through `ScureApiHost.Build(...)`, starts it on a
  background thread, then runs Avalonia on the main thread. Stopping either side stops the other.
* View models resolve the **same** singleton services the API uses, so a command from the screen and the
  same command over HTTP go through one code path and one `CureController` instance.
* Composition root for the process layer: `SCureBox.Application/ProcessServiceCollectionExtensions.cs`.

### 4.3 Periodic loops

| Loop | Period | Owner | Purpose |
|---|---|---|---|
| Recipe tick | 1 s | `RecipeRunner` | Advance the step state machine, issue commands |
| Supervision tick | 1 s | `SupervisionService` | Sensors, fans, LED panels, door watchdog |
| Telemetry sample | 2 s | `RecipeRunner` | Append a sample to the run record |
| Heartbeat write | 1 s | `HeartbeatService` | Prove the firmware is alive to the watchdog |
| Watchdog poll | 500 ms | `OutputWatchdog` (separate process) | Cut outputs when the heartbeat goes stale |
| UI state poll | 1 s | `MachineStateStore` | Refresh screens |
| systemd notify | half of `WATCHDOG_USEC` | `SystemdWatchdogService` | Process liveness to systemd |

### 4.4 Key components

| Component | File | Responsibility |
|---|---|---|
| `RecipeStateMachine` | `Domain/Control/RecipeStateMachine.cs` | Pure sequencer: states, phases, timers, which command to emit |
| `RecipeRunner` | `Application/Recipe/RecipeRunner.cs` | Hosted 1 Hz loop: validates, drives the machine, records timings and telemetry |
| `CureController` | `Application/Process/CureController.cs` | The machine command surface: heat, dry, cure, cool, nitrogen, stop, door, tests |
| `HeatingLoop` / `CoolingLoop` | `Application/Devices/*.cs` | Closed-loop heating with PI delta-sigma, and the cooling mode logic |
| `SupervisionService` | `Application/Supervision/SupervisionService.cs` | 1 Hz safety evaluation and the door watchdog |
| `IoBoardHardwareSystem` | `Hardware/IoBoardHardwareSystem.cs` | Board access, sensor reads, glitch hold, UV routing and interlocks |
| `OutputWatchdog` + `SafetyCut` | `Hardware/Safety/*.cs` | Out-of-process cut of heater and UV |
| `ProgramValidator` / `EditorRules` | `Domain/Programs`, `Ui/ViewModels/Editor` | What a legal program is, and what the editor offers |
| `ProgramEstimator` | `Domain/Programs/ProgramEstimator.cs` | Predicted ramp, hold, cooling and total time |
| `ErrorRegistry` | `Domain/Errors`, `config/errors.json` | Code, severity, message and remedy for every alert |

---

## 5. Process flows

### 5.1 Power-on to ready

```mermaid
flowchart TD
  P["Power on"] --> IO["io-safe service: LED supply relays and routing pins driven low before the firmware starts"]
  IO --> FW["Firmware starts, hardware layer opens the board or falls back to simulation"]
  FW --> L["Boot screen: logo, then the self-test list"]
  L --> C1["1. Door closed"]
  C1 --> C2["2. Temperature sensors"]
  C2 --> C3["3. UV LEDs 405 nm"]
  C3 --> C4["4. UV LEDs 450 nm"]
  C4 --> C5["5. Chamber fans"]
  C5 --> C6["6. API server"]
  C6 --> Q{"All checks passed"}
  Q -->|yes| R{"Setup already completed"}
  R -->|yes| H["Home screen"]
  R -->|no| SU["First-run setup wizard"]
  Q -->|no| F["Shows how many checks failed, offers Retry or Continue anyway"]
  F --> H
```

| Check | How it passes | If it fails |
|---|---|---|
| Door closed | The door sensor reads closed; the screen waits up to 60 s for the operator to close it | Reported as open or unreadable |
| Temperature sensors | Every supervised thermistor reads, including both LED panel sensors, within 5 s | Lists the sensors that are not reading |
| UV LEDs 405 nm | A 15 s lit test raises the panel temperature by at least 0.8 °C | Reported with the controller's message |
| UV LEDs 450 nm | The same test over 30 s | As above |
| Chamber fans | Every fan reaches at least 100 RPM | Lists the fans and their measured speed |
| API server | The last state read succeeded | Reports that the firmware is not answering |

The two LED checks are reported as failures when the door check did not pass, because they cannot be run
with the door open. A failed self-test does not lock the machine: the operator can retry or continue.

### 5.2 Who sequences a run

The **server** sequences a run. `RecipeRunner` ticks once per second, asks `RecipeStateMachine` what to do
next, and translates the answer into `CureController` calls. The UI starts the run, renders status, and
sends Pause, Resume, Abort and Skip. The same control surface exists over HTTP at
`/api/recipe/{status,start,pause,resume,abort,skip}`, so a run behaves identically whether it was started
from the screen or from a test harness.

### 5.3 Run lifecycle

```mermaid
stateDiagram-v2
  [*] --> Idle
  Idle --> Preflight : Start
  Preflight --> Completed : program has no steps
  Preflight --> Running : first step begins
  Running --> Running : step complete, next step begins
  Running --> Completed : last step complete
  Running --> Paused : Pause
  Paused --> Running : Resume
  Running --> Aborted : Abort
  Paused --> Aborted : Abort
  Preflight --> Aborted : Abort
  Running --> Error : refused command, door abort, supervision stop
  Completed --> [*]
  Aborted --> [*]
  Error --> [*]
```

Inside `Running`, each step carries its own phase: `Ramping`, `Holding`, `Cooling` or `Nitrogen`.
While paused the status reports the pseudo-phase `paused` and every progress clock is frozen.

Start is refused, with error 6015, when a run is already in `preflight`, `running` or `paused`, or when any
process is already active on the machine. An invalid program is refused with the validator's own code.
Pause requires `running`, Resume requires `paused`, Abort requires `preflight`, `running` or `paused`, and
Skip requires `running`.

### 5.4 Step execution

```mermaid
flowchart TD
  A["Begin step i"] --> B{"Process type"}
  B -->|Nitrogen| N1["Open N2 valve"] --> N2["Wait 120 s fixed"] --> Z["End step"]
  B -->|Cooling| C1["Stop UV and heater, open damper, fans per cooling mode"]
  C1 --> C2{"Chamber at or below target plus 0.5 C"}
  C2 -->|no| C2
  C2 -->|yes| Z
  B -->|"Cure or Bleacher, no temperature"| U1["UV on at once, optional ventilation"] --> U2["Hold for the step time"] --> Z
  B -->|"Heating, Drying, or UV with temperature"| H1["Close damper, heater loop to target"]
  H1 --> H2{"Chamber at or above target minus 0.5 C"}
  H2 -->|no| H2
  H2 -->|yes| H3["Ramp complete"]
  H3 --> H4{"UV step with uvStartMode at-target"}
  H4 -->|yes| H5["Light UV panels now"] --> H6
  H4 -->|no| H6["Hold at target"]
  H6 --> H7{"Hold time elapsed"}
  H7 -->|no| H6
  H7 -->|yes| Z
  Z --> Y{"More steps"}
  Y -->|yes| A
  Y -->|no| W["Stop all outputs, run completed"]
```

Per-type detail, as implemented:

| Step type | Outputs driven | Ends when |
|---|---|---|
| Heating | UV off, cooling stopped, damper closed, heater PI loop to target, heater fan 100 % | Ramp reached, then hold time elapsed |
| Drying | As Heating, plus: once at temperature the damper opens and the intake fan runs at 30 % | Same as Heating |
| Cure, 405 nm | Heater to target, UV mode 405 selected, LED fan pre-flight, panels lit at intensity times calibration factor, panel fans 100 % | Same as Heating |
| Bleacher, 450 nm | As Cure but UV mode 450; in the shipped configuration only the door panel is allowed at 450 nm | Same as Heating |
| Cure or Bleacher without a temperature | Heater stopped, UV on immediately, ventilation only if the step asks for it | Hold time elapsed, no ramp |
| Cooling | UV off, heater shut down, damper open, heater fan 100 %, intake fan per mode: fast 100 %, medium 60 %, slow 30 %; fast also boosts the four LED fans | Chamber at or below target plus 0.5 °C |
| Nitrogen | N₂ valve only; no other output touched | Fixed 120 s |

Thresholds and fixed times:

| Quantity | Value |
|---|---|
| Ramp complete band | target − 0.5 °C |
| Cooling complete band | target + 0.5 °C |
| Nitrogen purge duration | 120 s |
| Assumed ambient when no reading exists | 25 °C |
| Heater "at temperature" band used for the drying damper trigger | 1.5 °C |
| Ramp fallback when no temperature can be read | estimated ramp seconds elapsed |

**Timer mode.** With `on-target`, the default, the hold clock starts when the ramp completes. With
`on-ramp` the hold clock starts at the beginning of the step, but the step still never ends before the
target has been reached.

**UV start mode.** With `at-target`, the default, the panels are dark during the ramp and are lit at ramp
completion. With `at-start` the panels are lit from the first second of the step.

### 5.5 Pause, resume, abort, skip and finish

| Action | What happens |
|---|---|
| Pause | All cure outputs stop, the heater fan is allowed to run on, clocks freeze, phase reported as `paused`. The UI also pulses the door magnet so the operator can open the chamber |
| Resume | Every clock anchor is shifted by the pause duration and the phase command is re-issued, so the step continues where it stopped |
| Abort | State becomes `aborted`, outputs stop immediately, the run is closed with status `aborted` |
| Skip | The current step is ended now and the next one begins; if it was the last one the run completes |
| Finish | On the last step all outputs stop, fans and damper are closed down, the run is closed with status `completed`, and the UI offers the report |

Leaving the cure screen while a run is live aborts the run.

**Heater fan run-on.** A normal stop switches the heater element off at once and keeps the heater fan at
30 % for up to 15 minutes to carry the residual heat away. Only a door abort skips the run-on and stops the
fan immediately.

### 5.6 Pre-flight checks before and during a start

```mermaid
flowchart TD
  S["Operator presses Start"] --> A{"Critical alert active"}
  A -->|yes| X["Refused, alert shown"]
  A -->|no| D{"Door closed"}
  D -->|no| X
  D -->|yes| F["System pre-check: run all chamber fans, measure RPM"]
  F --> G{"Every fan at or above 100 RPM"}
  G -->|no| H{"Operator chooses"}
  H -->|"Continue anyway"| I
  H -->|Cancel| X
  G -->|yes| I["Navigate to the cure screen and start the run"]
  I --> J["Per step: sensor pre-flight"]
  J --> K{"Critical fan latched or required sensor unreadable"}
  K -->|yes| L["Step refused, run fails with 9002 or 9001"]
  K -->|no| M{"Step lights UV"}
  M -->|yes| N["LED fan pre-flight: fans to 100 %, wait 1.5 s, measure"]
  N --> O{"Every LED fan at or above 100 RPM"}
  O -->|no| P["UV refused with 9003"]
  O -->|yes| Q["Step runs"]
  M -->|no| Q
```

The operator-visible pre-check drives every chamber fan to 100 %, waits 2 s for spin-up, and measures each
fan's speed over 1 s. The sensor pre-flight retries a failed thermistor read three times, half a second
apart, before refusing. The LED fan pre-flight is skipped if UV is already lit or if it passed within the
last 30 seconds.

### 5.7 Safety supervision

Three independent mechanisms protect the machine, at different levels.

```mermaid
flowchart LR
  subgraph T["Supervision tick, once per second"]
    S1["Read sensors, fan speeds, panel temperatures, door"]
    S1 --> S2{"Door open and outputs live for more than 10 s"}
    S2 -->|yes| S3["Door abort: heater and its fan off now, UV, N2, cooling, fans, extractor off, run fails 6016"]
    S1 --> S4{"Fan more than 20 % below nominal for 60 s"}
    S4 -->|yes| S5["Stop every cure output, block further starts, alert 9002"]
    S1 --> S6{"Chamber sensor open while heating"}
    S6 -->|yes| S7["Shut the heater down, alert 9001"]
    S1 --> S8{"Other critical sensor open for 60 s"}
    S8 -->|yes| S9["Alert 9001"]
  end
  subgraph W["Watchdog process, independent"]
    W1["Poll the heartbeat file every 500 ms"] --> W2{"Older than 20 s"}
    W2 -->|yes| W3["Cut the heater SSR and the four UV dimming channels, drop both LED supply relays, repeat every 5 s"]
  end
  subgraph B["Board level"]
    B1["Any command that lights UV with the door open is refused by the hardware layer"]
  end
```

**Door interlock** exists at three levels: the hardware layer refuses to light any LED while the door is
open; the heating loop refuses to start with the door open; and the supervision tick aborts a live process
if the door stays open for 10 seconds. Closing the door within those 10 seconds cancels the abort.

**Output watchdog.** The firmware writes a heartbeat file once a second. A separate process polls it. If
the heartbeat is older than 20 seconds the watchdog cuts the heater and the UV drivers and repeats the cut
every 5 seconds while the silence lasts. Fans, damper and valves are deliberately left alone so that the
fans keep removing heat. A clean shutdown deletes the heartbeat file, which disarms the watchdog instead of
tripping it.

**Sensor glitch hold.** A reading outside −20…120 °C is not passed on. The last good value is held for up
to 15 seconds, which absorbs electrical noise without starting the 60-second open-sensor timer. Readings
still bad after the hold end the heating or cooling mode with code 9001.

**Fan speed policy.** Expected RPM per duty comes from a per-fan table. More than 10 % below nominal for
60 seconds is a maintenance warning, 9051. More than 20 % below, or effectively stopped for 5 seconds, is
critical, 9002: every cure output stops and further starts are blocked until the fan recovers or the
operator overrides it.

**Temperature stall.** If the chamber fails to move 1 °C in 5 minutes, five windows in a row, the UI pauses
the run and asks the operator whether to continue or stop, alert 7004. This check runs in the UI only.

### 5.8 What a run records

| Record | When | Contents |
|---|---|---|
| Telemetry sample | Every 2 s | Chamber and panel temperatures, fan speed and duty, heater PWM, UV outputs, damper, nitrogen, door |
| Phase timing | End of every step | Program, step, process, target, planned minutes, start and end, total and ramp seconds, start and end temperature, cooling mode, intensity, timer mode, run id |
| Run record | End of the run | Status, steps completed, sensor and fan issues seen during the run |
| Report | On request after the run | HTML report built from the run record, exportable to USB |

---

## 6. Building and validating a program

### 6.1 Editing

```mermaid
flowchart TD
  A["New or edit program"] --> B["Add step"]
  B --> C["Editor offers only the process types the rules allow at this position"]
  C --> D["Operator sets temperature, time, intensity, cooling mode, timer and UV start"]
  D --> E["Values clamped to the running limits on every change"]
  E --> F{"Save"}
  F --> G["Normalize: renumber, clamp, apply per-type fixed fields"]
  G --> H{"Validator"}
  H -->|errors| I["Save refused, first error shown in editor wording"]
  H -->|ok| J["Stored in the user program list with an estimated duration"]
```

The editor restricts the process list by position: after a nitrogen purge only Cure or Bleacher may follow,
after that UV step only Cooling, and a purge is offered only while fewer than two purges exist and a
cooling step has happened since the last one. Defaults for a new step are Heating, 40 °C, 10 minutes; a UV
step defaults to 30 % intensity, timer on target, UV at target.

### 6.2 Validation rules

| Rule | Limit | Code |
|---|---|---|
| Program must have at least one step | — | 6015 |
| Heating, drying and UV target temperature | 30…80 °C | 7001 |
| Cooling target temperature, editor | 30…75 °C | 7001 |
| Cooling target must be at least 5 °C below the running temperature | — | 7001 |
| Temperature may not fall from step to step without a cooling step | — | 7001 |
| Hold time | 1…120 min, or 1…720 min for bleaching | 6015 |
| UV intensity | 10…100 % | 7002 |
| Nitrogen purges per program | at most 2 | 6015 |
| A purge must be followed by a Cure or Bleaching step | — | 6015 |
| That UV step must be followed by a Cooling step | — | 7003 |

A nitrogen step carries no temperature and no time. A cooling step carries no hold time. A UV step with no
temperature is legal and means "UV only, no heating".

### 6.3 Time estimation

Heating is estimated with a piecewise rate: 13 s per °C up to 45 °C, 50 s per °C up to 75 °C, 80 s per °C
above. Cooling uses 2.5, 1.5 and 0.8 °C per minute for fast, medium and slow. A nitrogen purge counts as
120 seconds. The estimate is shown per step in the editor, as the program total on the home screen, and as
the remaining-time prediction during a run.

---

## 7. External interfaces

### 7.1 HTTP API

The whole surface is mounted under `/api` on port 3001, bound to every interface over IPv4 and IPv6.
There is **no authentication and no transport security**, and CORS is open to any origin: the API is meant
for the machine's own loopback, the QA tooling and a trusted service network.

| Group | Routes | Purpose |
|---|---|---|
| State | `GET /api/state` | The full machine snapshot polled once per second |
| Cure commands | `POST /api/cure/{heat,dry,cure-405,cure-450,uv-only,cool,nitrogen,stop}` | Drive one process directly |
| Recipe runner | `GET /api/recipe/status`, `POST /api/recipe/{start,pause,resume,abort,skip}` | Run a whole program server-side |
| Hardware | `POST /api/{door/open,door-abort/ack,chamber/temperature,chamber/stop,fans/*,damper/*,uv,bofa,rgb,rgb/alerts}` | Individual actuators, service use |
| Diagnostics | `POST /api/diagnostics/{fan-test,led-test}` | Fan speed test and LED heating test |
| Materials | `GET /api/materials/presets`, `GET`/`POST /api/materials/user` | Bundled and user programs; user list is a full replace |
| History | `GET /api/print-history`, `POST /api/print-history`, `GET /api/cure-history`, `GET /api/phase-timings` | Stored history |
| Cure runs | `POST /api/cure-runs/{id}/{start,telemetry,finish,report,phase}`, `GET /api/cure-runs/{id}/report` | Per-run recording and reports |
| System | `POST /api/system/{reboot,shutdown,datetime,export-logs,export-csv,export-report,update}`, `GET /api/system/{version,update/manifest,update/package}` | Power, clock, exports, update |
| Network | `GET /api/network/status`, `POST /api/network/{diagnostics,static}` | Connection state, ping and DNS tools, static or DHCP |
| Developer | `POST /api/dev/log`, `GET`/`POST /api/dev/led-calibration`, `POST /api/dev/led-power`, `GET /api/dev/picolog/status`, `POST /api/dev/hdt/{start,abort,reset}`, `GET /api/dev/hdt/{status,report.csv}` | LED calibration and material HDT calibration |
| NFC | `GET`/`POST /api/nfc` | Reader presence and enable flag |
| Cloud | `POST /api/cloud/config` | Outbound portal sync settings |
| UI automation | `GET /api/ui/route`, `POST /api/ui/navigate`, `GET /api/ui/screenshot`, `POST /api/ui/tap`, `POST /api/ui/scan` | Present only when the native UI hosts the API |

Conventions:

* Command responses are `{ok, message}` plus `code` when a refusal carries one.
* Almost everything answers **HTTP 200 even when `ok` is false**. Non-200 is used only for malformed
  bodies, a missing report, a missing update package and unknown routes.
* Some responses are bare objects or arrays, not the envelope: state, materials, histories, phase timings,
  version, network status and diagnostics, recipe status, developer status endpoints.
* A refusal message that begins with a bracketed code, for example `[9002] Fan below minimum speed`,
  carries that code to the caller; anything else is reported as 6015.
* A few routes always answer `ok: true` regardless of what the hardware did: fan speed, door open,
  door-abort acknowledgement, chamber stop, cure stop and both diagnostics routes. This is deliberate
  fidelity to the original Python API and must be preserved by clients.
* Unhandled exceptions under `/api` are turned into `{ok: false, message}` with HTTP 200 and never leak a
  stack trace. Every request is logged except the one-second state poll.

### 7.2 Hardware interfaces

| Function | Device and address | Notes |
|---|---|---|
| PWM outputs | PCA9685 at 0x55 on I²C bus 0 | Fans, heater relay, chamber light, extractor, four UV dimming channels; every write is read back and retried |
| Digital outputs | TCA6424A at 0x23 on I²C bus 0 | LED supply relay, valves, door magnet, motor direction, NFC reset; outputs are staged before the pins become outputs so the relay cannot flash on at power-up |
| Analogue inputs | Two ADS1115 at 0x49, buses 0 and 1 | Seven thermistor channels plus the nitrogen pressure input |
| Fan speed | Six tachometer inputs via libgpiod v2 | Each line is requested once with pull-up and rising-edge detection; a background thread counts edges |
| Door sensor | GPIO 27 | High means closed; an unreadable sensor is reported as unknown, never as closed |
| Nitrogen valve | GPIO 13 | On or off |
| UV supply | Two solid-state relays on GPIO plus a routing pin | Verified on every wavelength change |
| Damper servo | GPIO 8 through a PIO helper | Falls back to software PWM, with jitter, when the helper or the PIO device is missing |
| Status strip | 21 addressable LEDs on GPIO 12 through a PIO helper | Never safety relevant: failures are recorded, not thrown |
| Temperature probe for calibration | PicoLog TC-08 over USB | Developer mode only, simulated when requested |
| NFC reader | Eccel Pepper C2 as a USB serial device | Detected by device path; enabling without a reader is refused with 9052 |

The hardware layer refuses illegal operations by throwing a refusal, and reports a mismatch between what
was written and what reads back as a verification failure. Both become refusals with an error code at the
controller boundary.

**Simulation.** The real board is used only on Linux, with the I²C device present and the PWM chip
answering, and when simulation was not forced. Otherwise the layer silently substitutes a deterministic
model of the machine and reports `hwSource: simulation`. Nothing prevents a cure from running in
simulation; the only signal is that field and the boot screen.

### 7.3 Persistence

All state lives under the data directory, `/var/lib/scurebox` on a unit. Every file is written whole,
through a temporary file and a rename, so a power cut cannot leave a half-written file.

| File | Contents |
|---|---|
| `user_materials.json` | Operator programs |
| `cure_history.json` | Runs, newest first, including their telemetry |
| `cure_reports.json` | Stored HTML reports by run id |
| `phase_timings.json` | Per-step timing records, appended |
| `print_history.json` | Print jobs linked to cures |
| `component_counters.json` | On-hours per component |
| `led_calibration.json` | Per-zone UV factors |
| `nfc.json`, `cloud.json`, `dev_events.jsonl` | NFC enable flag, cloud sync settings, developer event trail |
| `ui-settings.json`, `ui-alerts.json` | Screen settings and the active alert list |

A run left in the `running` state by a power cut is rewritten as `error` when the store loads, so history
never shows a run that cannot end. An optional PostgreSQL backend replaces the material, print and run
stores when a connection string is configured; phase timings always stay in the JSON file.

### 7.4 Configuration

| File | Purpose | Location on a unit |
|---|---|---|
| `components.json` | The hardware map and every tunable limit: fan health, sensor filter, heater, cooling, servo, LED power, pressure sensor | `/etc/scurebox/components.json`, kept across updates |
| `presets.json` | Bundled read-only programs | `/opt/scurebox/config`, replaced by each install |
| `errors.json` | The error registry: code, severity, message, troubleshooting, support link | `/opt/scurebox/config` |
| `system.json` | Device identity defaults: serial, model, hardware revision, organisation | `/opt/scurebox/config` |
| `versions.json` | Release history shown in Settings | `/opt/scurebox/config` |
| `VERSION` | The running software version, reported by the API and the UI | Next to the executable |

Environment variables that change behaviour: `PORT`, `ASPNETCORE_URLS`, `SCURE_SIMULATE`,
`SCURE_COMPONENTS`, `SCURE_DATA_DIR`, `SCURE_UI_DIR`, `DATABASE_URL`, `SCURE_HEARTBEAT_FILE`,
`SCURE_SIM_TC08`, `SCURE_SIM_NFC`, and the UI hosting variables `SCURE_UI_WINDOW`, `SCURE_UI_SIZE`,
`SCURE_UI_HIDE_CURSOR`, `SCURE_UI_DRM_CARD`, `SCURE_UI_SHOTS`.

---

## 8. Runtime environment and lifecycle

### 8.1 Services on a unit

| Service | Role | Restart policy |
|---|---|---|
| `scurebox-io-safe` | Runs before the firmware: drives the UV supply pins low and releases the LED relay, closing the power-up window in which the expander's pull-ups could engage it | One shot at boot |
| `scurebox-ui` | The normal application: firmware, API and the touchscreen UI in one process, owning the console | Always, with a 60 s systemd watchdog |
| `scurebox` | The alternative browser-UI build, same firmware without Avalonia | Always; conflicts with `scurebox-ui` |
| `scurebox-watchdog` | The independent output watchdog | Always, at raised priority, deliberately not tied to the firmware units |
| `scurebox-netbird-enroll` | Enrols the unit for remote access when a setup key is present | Retries every minute until it succeeds |

### 8.2 Installing a release on a unit

`deploy/install.sh` runs as root from an extracted release and performs, in order: stop the legacy
service, copy the application and link the data directory, enable I²C and append the boot configuration
and the display profile, patch both A/B boot partitions with the display profile, build the PIO helpers
if possible, install and start the systemd units for the chosen UI, install the branded boot splash, give
the display to the native UI by masking the console login, enrol NetBird when a key is present, install
the output watchdog, and install the wired-network configuration.

Two steps are deliberately non-fatal: building the PIO helpers, after which the damper falls back to
software PWM, and the network configuration, which is not re-applied immediately so that an install over
SSH cannot cut its own connection.

### 8.3 Imaging and flashing a new unit

```mermaid
flowchart LR
  A["Official Raspberry Pi OS image"] --> B["build-image.py: boot partition only"]
  B --> C["Adds boot config, display profile, first-run script, the release payload, user and SSH"]
  C --> D["flash-cm5.ps1 on a Windows PC"]
  D --> E["CM5 in USB boot mode, eMMC exposed as a disk"]
  E --> F["Raw write, partition table written last, first megabytes verified"]
  F --> G["Power cycle without the boot jumper"]
  G --> H["First boot runs the installer from the payload, then reboots into the UI"]
```

The Windows installer bundle does the same job for an existing unit over the network: it copies the
release, runs the on-device installer, and polls the unit until it reports the new version and answers.

### 8.4 Updating in the field

| Path | How |
|---|---|
| Windows installer over SSH | The bundle carries the release; the operator enters the unit address; progress and the result are shown, and remote access can be connected in the same session |
| USB package on the machine | Settings offers an update from a signed `.scu` package on a USB drive: find the package, verify its SHA-256 and its signature against the bundled public key, extract, run the installer's pre and post phases, roll back on failure |
| Developer push | A script copies a freshly built release to a unit over SSH |

### 8.5 Remote access and networking

Remote access uses NetBird. A unit enrols either with a setup key, which may be supplied at imaging time
or by the installer, or by an operator logging in on the NetBird website from the installer, which stores
no key or token on the PC. A key placed on the boot partition is moved into root-only storage on first
boot and deleted afterwards; after a successful enrolment every copy of the key is removed.

The wired interface is configured so that DHCP never times out. Without this a unit connected directly to
a PC dropped its address every 45 seconds and disappeared from the network. Static addressing remains
available from the Network screen.

---

## 9. Functional requirements

Each requirement states what the software does today. "Source" names the file that implements it, so a
reviewer can confirm the statement rather than trust it.

### 9.1 Program execution

| Id | Requirement | Source |
|---|---|---|
| SRS-RUN-1 | The server executes a program without help from the UI, advancing once per second | `Application/Recipe/RecipeRunner.cs` |
| SRS-RUN-2 | A run passes through idle, pre-flight, running, paused and one of completed, aborted or error | `Domain/Control/RecipeStateMachine.cs` |
| SRS-RUN-3 | A start is refused while another run or another process is active | `Application/Recipe/RecipeRunner.cs` |
| SRS-RUN-4 | A start is refused when the program fails validation, reporting the validator's code | `Application/Recipe/RecipeRunner.cs` |
| SRS-RUN-5 | An empty program completes immediately with an explanatory message | `Domain/Control/RecipeStateMachine.cs` |
| SRS-RUN-6 | Pause stops all outputs and freezes every clock; resume shifts all clocks by the pause length and re-issues the step's command | `Domain/Control/RecipeStateMachine.cs` |
| SRS-RUN-7 | Abort stops outputs immediately and closes the run as aborted | `Application/Recipe/RecipeRunner.cs` |
| SRS-RUN-8 | Skip ends the current step now and continues with the next, or completes the run | `Domain/Control/RecipeStateMachine.cs` |
| SRS-RUN-9 | Any refused command during a run fails the run, stops all outputs and reports the refusal's code | `Application/Recipe/RecipeRunner.cs` |
| SRS-RUN-10 | The same run control is available on the screen and over HTTP, sharing one controller instance | `Api/Endpoints/RecipeEndpoints.cs`, `Ui/Program.cs` |
| SRS-RUN-11 | Leaving the cure screen while a run is live aborts that run | `Ui/ViewModels/Pages/CureProcessViewModel.cs` |

### 9.2 Step behaviour

| Id | Requirement | Source |
|---|---|---|
| SRS-STEP-1 | Six process types exist: Heating, Drying, Cure, Cooling, Bleacher, Nitrogen | `Domain/Models/CureProgram.cs` |
| SRS-STEP-2 | A ramp completes when the chamber reaches the target minus 0.5 °C, or when the estimated ramp time has passed with no temperature reading | `Domain/Control/RecipeStateMachine.cs` |
| SRS-STEP-3 | A hold ends when the step's time has elapsed, measured from ramp completion or from the start according to the timer mode, and never before the target is reached | `Domain/Control/RecipeStateMachine.cs` |
| SRS-STEP-4 | Cooling ends when the chamber is at or below the target plus 0.5 °C | `Domain/Control/RecipeStateMachine.cs` |
| SRS-STEP-5 | Cooling drives the intake fan at 100, 60 or 30 % for fast, medium and slow, opens the damper, and in fast mode also boosts the four panel fans | `Application/Process/CureController.cs` |
| SRS-STEP-6 | A nitrogen purge opens the valve for a fixed 120 s and changes no other output | `Domain/Control/RecipeStateMachine.cs` |
| SRS-STEP-7 | Cure uses 405 nm, bleaching uses 450 nm, and only panels permitted for that wavelength are lit | `Application/Process/CureController.cs`, `config/components.json` |
| SRS-STEP-8 | UV is lit at the start of a step or at ramp completion according to the UV start mode, defaulting to at target | `Domain/Control/RecipeStateMachine.cs` |
| SRS-STEP-9 | A UV step without a temperature runs with the heater off and no ramp, optionally with ventilation | `Application/Process/CureController.cs` |
| SRS-STEP-10 | Drying opens the damper and runs the intake fan at 30 % once the chamber is at temperature | `Application/Process/CureController.cs` |
| SRS-STEP-11 | Commanded UV intensity is multiplied by the zone's calibration factor and clamped to the configured maximum duty | `Application/Process/CureController.cs`, `Hardware/IoBoardHardwareSystem.cs` |
| SRS-STEP-12 | At the end of a run every fan is stopped, except fans of panels still lit, and the damper is closed | `Application/Process/CureController.cs` |
| SRS-STEP-13 | After a normal stop the heater element switches off at once and its fan runs on at 30 % for the configured cooldown | `Application/Devices/HeatingLoop.cs` |

### 9.3 Safety

| Id | Requirement | Source |
|---|---|---|
| SRS-SAFE-1 | No UV panel can be lit while the door reads open; the hardware layer refuses the command | `Hardware/IoBoardHardwareSystem.cs` |
| SRS-SAFE-2 | Heating cannot start while the door reads open | `Application/Devices/HeatingLoop.cs` |
| SRS-SAFE-3 | If the door is open for 10 s while outputs are live, the machine aborts: heater and heater fan off at once, UV, nitrogen, cooling, fans and extractor off, run failed with 6016 | `Application/Supervision/SupervisionService.cs`, `Application/Process/CureController.cs` |
| SRS-SAFE-4 | An unreadable door sensor is never treated as closed | `Hardware/IHardwareSystem.cs` |
| SRS-SAFE-5 | The firmware writes a heartbeat file once a second | `Api/Infrastructure/HeartbeatService.cs` |
| SRS-SAFE-6 | A separate process cuts the heater relay, the four UV dimming channels and both UV supply relays when the heartbeat is older than 20 s, and repeats the cut every 5 s while the silence lasts | `Hardware/Safety/OutputWatchdog.cs`, `Hardware/Safety/SafetyCut.cs` |
| SRS-SAFE-7 | The safety cut leaves fans, damper and valves running so heat keeps being removed | `Hardware/Safety/SafetyCut.cs` |
| SRS-SAFE-8 | A clean firmware shutdown deletes the heartbeat file, which disarms the watchdog instead of tripping it | `Hardware/Safety/HeartbeatFile.cs`, `Domain/Control/WatchdogMonitor.cs` |
| SRS-SAFE-9 | Every process start verifies that the required thermistors read, retrying three times, and refuses with 9001 otherwise | `Application/Process/CureController.cs` |
| SRS-SAFE-10 | Every process start is refused while a critical fan fault is latched, with 9002 | `Application/Process/CureController.cs` |
| SRS-SAFE-11 | Before UV is lit, the fans of the panels about to be lit must reach 100 RPM, else the start is refused with 9003 | `Application/Process/CureController.cs` |
| SRS-SAFE-12 | Heating refuses to start, and stops within the ten-second health check, when its fan is below 100 RPM or the chamber thermistor is invalid | `Application/Devices/HeatingLoop.cs` |
| SRS-SAFE-13 | A fan more than 20 % below its nominal speed for 60 s, or stopped for 5 s, stops every cure output and blocks further starts until it recovers or is overridden | `Domain/Control/FanHealthEvaluator.cs`, `Application/Supervision/SupervisionService.cs` |
| SRS-SAFE-14 | A fan 10 to 20 % below nominal for 60 s raises a maintenance warning without stopping the process | `Domain/Control/FanHealthEvaluator.cs` |
| SRS-SAFE-15 | An open chamber thermistor while heating is wanted shuts the heater down at once | `Domain/Control/SensorSupervisionEvaluator.cs` |
| SRS-SAFE-16 | A sensor reading outside −20…120 °C is held at its last good value for up to 15 s before being reported as a fault | `Domain/Control/SensorGlitchHold.cs`, `Hardware/IoBoardHardwareSystem.cs` |
| SRS-SAFE-17 | Fan speed is derived over a window of at least one second shared by all callers, so a healthy fan cannot be reported as stopped | `Domain/Control/TachRateTracker.cs` |
| SRS-SAFE-18 | The operator may override a failed fan check to continue, and the override is recorded in the run | `Application/Process/CureController.cs`, `Ui/ViewModels/Pages/HomeViewModel.cs` |
| SRS-SAFE-19 | Before the firmware starts, a boot service parks the UV supply pins low and releases the LED relay | `deploy/io-safe-boot.sh`, `deploy/scurebox-io-safe.service` |
| SRS-SAFE-20 | On shutdown the firmware switches every output off and flushes its stores | `Api/ScureApiHost.cs` |

### 9.4 Program building and validation

| Id | Requirement | Source |
|---|---|---|
| SRS-VAL-1 | Heating, drying and UV targets are limited to 30…80 °C | `Domain/Programs/ProgramValidator.cs` |
| SRS-VAL-2 | Cooling targets are limited to 30…75 °C in the editor and must be at least 5 °C below the running temperature | `Domain/Programs/ProgramValidator.cs` |
| SRS-VAL-3 | Temperature may not decrease from step to step without a cooling step between them | `Domain/Programs/ProgramValidator.cs` |
| SRS-VAL-4 | Hold time is 1…120 min, or 1…720 min for bleaching | `Domain/Programs/ProgramValidator.cs` |
| SRS-VAL-5 | UV intensity is 10…100 % | `Domain/Programs/ProgramValidator.cs` |
| SRS-VAL-6 | At most two nitrogen purges per program; a purge must be followed by a UV step, and that step by a cooling step | `Domain/Programs/ProgramValidator.cs` |
| SRS-VAL-7 | The editor offers only the process types legal at that position and clamps every value as it is entered | `Ui/ViewModels/Editor/EditorRules.cs` |
| SRS-VAL-8 | Saving normalises a program: steps renumbered, per-type fields fixed, values clamped | `Ui/ViewModels/Editor/EditorRules.cs` |
| SRS-VAL-9 | Programs can be imported from CSV on a USB drive, and each imported program is validated before it is added | `Ui/ViewModels/Dialogs/ImportCsvDialogViewModel.cs`, `Domain/Programs/ProgramCsv.cs` |
| SRS-VAL-10 | The estimated duration uses 13, 50 and 80 s per °C by band for heating, 2.5, 1.5 and 0.8 °C per minute for cooling, and 120 s per purge | `Domain/Programs/ProgramEstimator.cs` |
| SRS-VAL-11 | The API accepts a slightly wider cooling range, 20…80 °C, than the editor | `Api/Infrastructure/RecipeValidation.cs` |

### 9.5 Operator interface

| Id | Requirement | Source |
|---|---|---|
| SRS-UI-1 | The UI runs full screen on the panel with no window manager, and every modal is drawn inside the application | `Ui/Program.cs`, `Ui/Controls/DialogHost.axaml.cs` |
| SRS-UI-2 | The layout is designed on a fixed 1600 by 1000 surface, scaled and, on a portrait panel, rotated with the touch input | `Ui/Views/ShellScaler.cs` |
| SRS-UI-3 | At power-on the boot screen runs the six self-tests and then continues to Setup or Home | `Ui/ViewModels/Pages/BootViewModel.cs` |
| SRS-UI-4 | First-run setup requires a serial number, which is normally scanned; manual entry is deliberately hard to reach | `Ui/ViewModels/Pages/SetupViewModel.cs` |
| SRS-UI-5 | A cure cannot be started while a critical alert is active or the door is open | `Ui/ViewModels/Pages/HomeViewModel.cs` |
| SRS-UI-6 | Starting a cure first runs the fan pre-check and offers to continue when a fan fails | `Ui/ViewModels/Dialogs/PreflightDialogViewModel.cs` |
| SRS-UI-7 | During a run the screen shows the current step, phase, temperatures, remaining time and progress, refreshed once per second | `Ui/ViewModels/Pages/CureProcessViewModel.cs` |
| SRS-UI-8 | Door open, fan failure, heater sensor fault, panel not heating and temperature stall each raise their own dialog during a run | `Ui/ViewModels/Pages/CureProcessViewModel.cs` |
| SRS-UI-9 | At the end of a run the operator is offered the report and the door release | `Ui/ViewModels/Dialogs/CureCompleteDialogViewModel.cs` |
| SRS-UI-10 | Alerts are listed by severity with description, troubleshooting and a support link, and can be dismissed | `Ui/Services/AlertService.cs`, `Ui/ViewModels/Pages/AlertsViewModel.cs` |
| SRS-UI-11 | The screen sleeps after two minutes of inactivity, except during a run, in developer mode and on full-screen routes | `Ui/Services/IdleService.cs` |
| SRS-UI-12 | Developer mode is entered by ten presses and a PIN, and every transition is written to the developer log | `Ui/Services/DevModeService.cs` |
| SRS-UI-13 | Barcodes are read directly from the input devices, because the panel has no focused text field | `Ui/Services/BarcodeScanner.cs` |

### 9.6 Records, reports and system services

| Id | Requirement | Source |
|---|---|---|
| SRS-DATA-1 | A telemetry sample is recorded every 2 s of a run | `Application/Recipe/RecipeRunner.cs` |
| SRS-DATA-2 | Every completed step writes a timing record including ramp seconds and start and end temperature | `Domain/Control/RecipeStateMachine.cs` |
| SRS-DATA-3 | Every run is stored with status, steps completed and the sensor and fan issues seen during it | `Application/Persistence/JsonCureRunStore.cs` |
| SRS-DATA-4 | A run report is a self-contained HTML document with the step table, timing diagram, temperature and UV charts and the issue notes | `Application/Reports/CureReportBuilder.cs` |
| SRS-DATA-5 | Reports and CSV exports are written to a USB drive, reporting 9081 when none is present and 9082 on a write failure | `Application/Platform/SystemService.cs` |
| SRS-DATA-6 | Every data file is written atomically and survives a corrupt or missing file by falling back to an empty list | `Application/Persistence/JsonFileStore.cs` |
| SRS-DATA-7 | A run interrupted by a power cut is marked as an error when history is next loaded | `Application/Persistence/JsonCureRunStore.cs` |
| SRS-DATA-8 | Component on-hours are accumulated for the UV panels, heater, heater fan and cooling fan | `Application/Platform/ComponentCounters.cs` |
| SRS-DATA-9 | The unit reports its software version, commit, operating system, kernel, runtime and eMMC serial | `Application/Platform/SystemService.cs` |
| SRS-DATA-10 | Network status, ping, traceroute and name lookup are available, and addresses never reach a shell | `Application/Platform/NetworkService.cs` |
| SRS-DATA-11 | A USB update package is installed only after its SHA-256 and its signature verify against the bundled public key | `Application/Platform/UpdateService.cs` |

---

## 10. Non-functional requirements

| Id | Requirement |
|---|---|
| SRS-NFR-1 | The recipe and supervision loops each run at 1 Hz; a slow hardware read must not stall the UI thread |
| SRS-NFR-2 | The heartbeat is written every second and the watchdog polls every 500 ms, so the worst-case delay from firmware death to output cut is about 20.5 s |
| SRS-NFR-3 | Every PWM and expander write is verified by reading it back, with up to three retries |
| SRS-NFR-4 | The firmware starts without an IO board and behaves identically in simulation, so QA can run on a PC |
| SRS-NFR-5 | The domain layer contains no I/O and is fully unit-testable |
| SRS-NFR-6 | The UI animates only opacity, because the panel's render stack does not animate transitions reliably |
| SRS-NFR-7 | Data survives power loss: atomic writes, tmpfs heartbeat, and recovery of interrupted runs |
| SRS-NFR-8 | The software runs as a self-contained build with no runtime installed on the unit |
| SRS-NFR-9 | Every error presented to an operator carries a code, a plain description and troubleshooting steps |
| SRS-NFR-10 | The local API has no authentication and no transport security; deployment must keep it on a trusted network |
| SRS-NFR-11 | Default credentials for the unit's operating system and the developer PIN are compile-time or image constants and must be changed for production units |

---

## 11. Error registry

Codes are grouped by the screen they belong to: 6xxx home and pre-cure, 7xxx cure process, 9xxx error
management and system services. The registry file holds the operator-facing text and troubleshooting for
each code, with a built-in fallback if the file is missing.

| Code | Meaning | Raised when |
|---|---|---|
| 6015 | Pre-cure check failed | Any hardware refusal without a more specific code: door open at start, fan or sensor pre-flight, illegal state transition, out-of-range command |
| 6016 | Door opened, process aborted | The door stayed open for 10 s while outputs were live |
| 7001 | Invalid target temperature | Validation of a step or a command outside the allowed range, or a broken temperature chain |
| 7002 | Invalid UV intensity | Intensity outside 10…100 % |
| 7003 | Invalid cooling mode | Unknown cooling mode, and the nitrogen block rules that require a cooling step |
| 7004 | Temperature stall | The chamber failed to move 1 °C in 5 minutes, five windows in a row |
| 7005 | Cure aborted | Defined but never raised; see §12 |
| 9001 | Temperature sensor disconnected | A required thermistor open at a start, an open chamber sensor while heating, or a sensor open for 60 s |
| 9002 | Fan below minimum speed | A critical fan deficit; every cure output stops |
| 9003 | LED cooling fan not spinning | A panel fan below 100 RPM when UV was about to be lit |
| 9004 | LED panel not heating | A lit panel that did not warm its sensor; disabled by default |
| 9005 | LED panel temperature drop | A lit panel that cooled below its peak; disabled by default |
| 9050 | LED temperature sensor disconnected | Back or door panel sensor open for 60 s |
| 9051 | Fan speed low, replace fan | A fan 10 to 20 % below nominal for 60 s |
| 9052 | NFC reader not detected | NFC enabled without a reader, or a reader unplugged while in use |
| 9080–9089 | Diagnostics, USB, network, update and API availability failures | System services |

---

## 12. Verification

| Layer | What it proves | How to run |
|---|---|---|
| Unit tests, domain | Rules, state machine, validation, estimation, sensor and fan policies on a fake clock | `dotnet test tests/SCureBox.Domain.Tests` |
| Unit tests, hardware | Drivers against fake buses, register sequences, safety cut, simulation model | `dotnet test tests/SCureBox.Hardware.Tests` |
| Unit tests, application | Controller, heating and cooling loops, runner, stores, platform services, reports | `dotnet test tests/SCureBox.Application.Tests` |
| Integration tests, API | Every route in simulation, in process | `dotnet test tests/SCureBox.Api.Tests` |
| UI tests | Headless Avalonia: boot self-test order, dialogs, editor, cure screen, scaling and scrolling | `dotnet test tests/SCureBox.Ui.Tests` |
| Live QA | The QA table against a running machine or a simulated server | `node qa/run-qa.mjs --api http://<unit>:3001` |
| Chained QA | Build, all tests, a simulated server, then the live QA table | `qa/run-all.ps1` |

The suite currently contains about 640 cases across the five projects and must pass before a release is
published. The QA table adds about a hundred live checks against a real or simulated unit.

Traceability, by area: program execution and step behaviour are covered by the recipe state machine,
runner and cure-controller tests; safety by the supervision, heating loop, watchdog monitor, glitch hold,
fan health and safety cut tests; validation and estimation by the validator and estimator tests; the
interface by the API integration tests and the QA table; the operator interface by the UI tests.

---

## 13. Known gaps and open issues

These are facts about the code as it stands, not proposals. They are listed so that a reviewer is not
misled by the rest of this document.

1. **No dedicated over-temperature trip.** Protection is indirect: the sensor validity band, the 80 °C
   program ceiling, the heating loop's health check and the output watchdog.
2. **Error 7005, cure aborted, is never raised.** An operator abort ends the run with status `aborted`
   and no code.
3. **`uvRampPercent` is carried on a step but never used.** No UV ramping is implemented.
4. **Immediate stop and normal stop behave identically** except for the message. The only truly immediate
   cut, without heater-fan run-on, is the door abort.
5. **LED panel heating checks, 9004 and 9005, are disabled by default** in the shipped configuration.
6. **Two ramp-time models coexist.** The runtime uses one flat rate chosen by the target; the estimator
   integrates band by band. They disagree when a ramp crosses a band boundary.
7. **Two validators with different cooling ranges.** The editor enforces 30…75 °C, the API 20…80 °C.
8. **Temperature stall detection lives in the UI only.** A run driven purely over HTTP has no stall
   supervision.
9. **Nitrogen steps skip the sensor and fan pre-flight**, so a purge can start with an open critical
   sensor or a latched critical fan.
10. **Simulation is a silent fallback.** A missing or unresponsive IO board is reported only through
    `hwSource`; nothing prevents a cure from running against the simulated machine.
11. **The local API is unauthenticated with open CORS**, and several routes always answer `ok: true`.
12. **Default credentials are baked in**: the image user and password, the installer's default unit
    password, and the developer PIN.
13. **A NetBird setup key written at imaging time sits in clear text on the boot partition** until the
    first boot moves it to root-only storage.
14. **Phase timings have no database backend**; they stay in a JSON file even when PostgreSQL is used.
15. **Material HDT calibration state is not persisted**; a restart during a calibration loses it.
16. **The boot self-test can be skipped**: "continue anyway" proceeds with any number of failed checks,
    and the two LED checks are reported as failures when the door check did not pass.
17. **Two UI stacks still exist**: the native UI and the older browser kiosk, selected at install time.
18. **`/api/recipe/*` and `/api/ui/*` are implemented but absent from the API contract document.**

---

## 14. Document control

* This document describes software version 1.0.32 and is kept next to the code it describes.
* Every release bumps `VERSION` and adds an entry to `config/versions.json`; a change in behaviour
  described here should update the matching section in the same commit.
* Flow charts are Mermaid source inside this file: edit the text, not an exported image.




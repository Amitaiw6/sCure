"""QA for the Claude-Code workflow package: every file the README names exists, nothing secret is inside, and every
number in the README is recomputed from the repos / the original zip. Writes MANIFEST.md and QA-REPORT.md.

Run:  python -I qa_package.py   (from this folder; needs git, the two repos and origin_hw-main.zip at their usual paths)
"""
import json, os, re, subprocess, sys, zipfile, datetime
sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from redact import redact

HERE = os.path.dirname(os.path.abspath(__file__))
GH = os.path.expanduser(r"~/Documents/GitHub")
CS = os.path.join(GH, "sCureBox-CS")
SA = os.path.join(GH, "sCure-A")
ZIP = os.path.expanduser(r"~/Downloads/origin_hw-main.zip")
BASE = "origin_hw-main/sCure IOB/SW_BR_EMB/"

results = []
def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))

def git(repo, *args):
    return subprocess.run(["git", "-C", repo, *args], capture_output=True, text=True, encoding="utf-8").stdout

readme = open(os.path.join(HERE, "README.md"), encoding="utf-8").read()

# ---- 1. every file / folder the README names is in the package
names = set(re.findall(r"`([0-9A-Za-z_./-]+\.(?:md|json|png|ps1|mjs|js|html|py|txt|yaml|toml))`", readme))
names |= set(re.findall(r"`(0[1-6]-[a-z-]+/)`", readme))
in_repo_only = {"VERSION", "errors.json", "qa/run-all.ps1", "qa/run-qa.mjs", "shoot.mjs", "ui-preview.cjs", "config/versions.json", "qa-tool/index.html", "/etc/scurebox/components.json", "deploy/publish.ps1",
                "ui/dist", "tests/", "docs/srs/", "reference/", "app.py", "io_controller.py", "qa-tests.js", "run-qa.mjs"}
all_files = []
for root, _, files in os.walk(HERE):
    if "__pycache__" in root:
        continue
    for f in files:
        rel = os.path.relpath(os.path.join(root, f), HERE).replace("\\", "/")
        if rel not in ("MANIFEST.md", "QA-REPORT.md"):
            all_files.append(rel)
for n in sorted(names):
    if n in in_repo_only:
        continue
    found = any(p == n or p.endswith("/" + n) or (n.endswith("/") and p.startswith(n)) for p in all_files)
    check(f"README reference present: {n}", found or n in ("MANIFEST.md", "QA-REPORT.md"))
for prefix in ["1a-", "1b-", "2a-", "2b-", "2c-", "3-cure-history-delete.png", "4-drying-wind-icon.png"]:
    check(f"example screenshot {prefix}", any(p.startswith("06-examples/screenshots/" + prefix) for p in all_files))
for doc in ["01-api-contract.md", "02-hardware-map.md", "03-ui-and-qa.md", "04-ui-spec.md", "05-native-ui.md", "06-srs.md"]:
    check(f"port spec {doc}", f"02-port-specs/{doc}" in all_files)

# ---- 2. no empty files, JSON parses, copies identical to the source
for p in all_files:
    full = os.path.join(HERE, p)
    if p in ("MANIFEST.md", "QA-REPORT.md"):
        continue
    check(f"non-empty {p}", os.path.getsize(full) > 0)
    if p.endswith(".json"):
        try:
            json.load(open(full, encoding="utf-8")); check(f"valid JSON {p}", True)
        except Exception as e:
            check(f"valid JSON {p}", False, str(e))
for doc in ["01-api-contract.md", "02-hardware-map.md", "03-ui-and-qa.md", "04-ui-spec.md", "05-native-ui.md", "06-srs.md"]:
    src = redact(open(os.path.join(CS, "docs", doc), encoding="utf-8", errors="surrogateescape", newline="").read())
    cpy = open(os.path.join(HERE, "02-port-specs", doc), encoding="utf-8", errors="surrogateescape", newline="").read()
    check(f"spec copy current (after redaction): {doc}", src == cpy)

# ---- 3. secret scan (credentials, machine addresses, keys)
patterns = {
    "IPv4 private/overlay": r"\b(?:192\.168|10\.0|100\.10[0-9]|172\.(?:1[6-9]|2\d|3[01]))\.\d{1,3}\.\d{1,3}\b",
    "netbird host": r"netbird\.cloud",
    "password assignment": r"(?i)password\s*[:=]\s*(?!['\"]?<redacted>)\S+|passwd\s*[:=]",
    "ssh private key": r"BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY",
    "ssh key file name": r"scure_pi\b",
    "machine key literal": r"(?i)machine[_ ]?key\s*[:=]\s*['\"][A-Za-z0-9_-]{16,}",
    "apps script deployment id": r"AKfycb[A-Za-z0-9_-]{20,}",
}
for p in all_files:
    if p.endswith(".png") or p in ("qa_package.py", "redact.py"):
        continue
    text = open(os.path.join(HERE, p), encoding="utf-8", errors="ignore").read()
    for label, rx in patterns.items():
        hits = re.findall(rx, text)
        if hits:
            check(f"no secrets: {p} ({label})", False, f"{len(hits)} hit(s)")   # never echo the value itself
check("secret scan ran on all text files", True)

# ---- 4. numbers in the README, recomputed
def count(repo):
    return int(git(repo, "rev-list", "--count", "HEAD").strip())
def coauth(repo):
    return len([l for l in git(repo, "log", "--format=%H", "--grep=Co-Authored-By: Claude").splitlines() if l])
cs_n, sa_n = count(CS), count(SA)
check(f"sCureBox-CS commits ({cs_n}) in README as 60", cs_n == 60 and "60 commits" in readme, f"git says {cs_n}")
check(f"sCure-A commits ({sa_n}) in README as 89", sa_n == 89 and "89 commits" in readme, f"git says {sa_n}")
check("sCureBox-CS co-authored 50", coauth(CS) == 50, f"git says {coauth(CS)}")
check("sCure-A co-authored 82", coauth(SA) == 82, f"git says {coauth(SA)}")
check("no commit mentions BMAD (both repos)", not git(CS, "log", "-i", "--grep=bmad", "--format=%h").strip() and not git(SA, "log", "-i", "--grep=bmad", "--format=%h").strip())
for repo in (CS, SA):
    hit = [os.path.join(r, d) for r, ds, _ in os.walk(repo) if "node_modules" not in r and ".git" not in r for d in ds if d in ("_bmad", "_bmad-output")]
    hit += [os.path.join(repo, f) for f in ("CLAUDE.md", "AGENTS.md") if os.path.exists(os.path.join(repo, f))]
    check(f"no BMAD / CLAUDE.md / AGENTS.md in {os.path.basename(repo)}", not hit, "; ".join(hit[:3]))

attrs = {}
for proj in sorted(os.listdir(os.path.join(CS, "tests"))):
    n = 0
    for r, _, fs in os.walk(os.path.join(CS, "tests", proj)):
        if os.sep + "bin" in r or os.sep + "obj" in r:
            continue
        for f in fs:
            if f.endswith(".cs"):
                n += len(re.findall(r"\[(?:Fact|Theory|AvaloniaFact|AvaloniaTheory)\b", open(os.path.join(r, f), encoding="utf-8", errors="ignore").read()))
    attrs[proj] = n
total = sum(attrs.values())
check(f"C# test attributes total {total} (README says 607)", total >= 607, json.dumps(attrs))
counts = json.loads(subprocess.run(["node", os.path.join(HERE, "qa_count_tests.mjs"), os.path.join(CS, "qa", "qa-tests.js"),
                                   os.path.join(SA, "qa-tool", "index.html")], capture_output=True, text=True).stdout)
check(f"sCureBox-CS QA tests {counts['cs']['tests']} in {counts['cs']['categories']} categories (README 110 / 16)",
      counts["cs"] == {"categories": 16, "tests": 110} and "**110** tests in 16 categories" in readme)
check(f"sCure-A QA tests {counts['sa']['tests']} in {counts['sa']['categories']} categories (README 290 / 29)",
      counts["sa"] == {"categories": 29, "tests": 290} and "**290** tests in 29 categories" in readme)
v_cs = len(json.load(open(os.path.join(CS, "config", "versions.json"), encoding="utf-8"))["history"])
v_sa = len(json.load(open(os.path.join(SA, "public", "config", "versions.json"), encoding="utf-8"))["history"])
check(f"versions.json entries CS {v_cs} (README 194)", v_cs == 194, str(v_cs))
check(f"versions.json entries sCure-A {v_sa} (README 201)", v_sa == 201, str(v_sa))
cs_ver = open(os.path.join(CS, "VERSION")).read().strip()
check(f"sCureBox-CS VERSION {cs_ver} (README 1.0.81)", cs_ver == "1.0.81", cs_ver)

with zipfile.ZipFile(ZIP) as z:
    names_z = z.namelist()
    skills = sorted({n.split("/.claude/skills/")[1].split("/")[0] for n in names_z if n.startswith(BASE + ".claude/skills/") and n.count("/") > BASE.count("/") + 2})
    check(f"BMAD skills in original repo: {len(skills)} (README 49)", len(skills) == 49)
    pa = [n for n in names_z if n.startswith(BASE + "_bmad-output/planning-artifacts/") and n.endswith(".md")]
    check(f"BMAD planning artifacts: {len(pa)} (README 5)", len(pa) == 5)
    other_out = [n for n in names_z if n.startswith(BASE + "_bmad-output/") and not n.startswith(BASE + "_bmad-output/planning-artifacts/") and not n.endswith("/")]
    check("no other BMAD outputs (PRD/epics/stories/specs)", not other_out, "; ".join(other_out[:3]))
    manifest = z.read(BASE + "_bmad/_config/manifest.yaml").decode()
    check("BMAD version 6.11.0, installed 2026-08-17", "6.11.0" in manifest and "2026-08-17" in manifest)
    check("package skills list matches zip", open(os.path.join(HERE, "05-original-repo-bmad", "bmad-skills-installed.txt")).read().split() == skills)
    for f in os.listdir(os.path.join(HERE, "05-original-repo-bmad", "_bmad-output-planning-artifacts")):
        check(f"artifact copy identical: {f}", z.read(BASE + "_bmad-output/planning-artifacts/" + f) == open(os.path.join(HERE, "05-original-repo-bmad", "_bmad-output-planning-artifacts", f), "rb").read())

# ---- 5. MANIFEST.md
desc = {
    "01-working-rules": "Claude Code project-memory notes that acted as standing instructions (process-relevant ones only; files with machine addresses / credentials left out).",
    "02-port-specs": "sCureBox-CS specs that drove the port (01-05), the descriptive SRS (06) and the repo README.",
    "03-qa": "QA harnesses: sCureBox-CS live-API suite (README, run-all.ps1, run-qa.mjs, qa-tests.js) and the sCure-A browser QA tool.",
    "04-versioning": "sCureBox-CS changelog (versions.json, newest first) and the central error registry (errors.json).",
    "05-original-repo-bmad": "Everything BMAD-related from origin_hw-main.zip (SW_BR_EMB 0.4.9): CLAUDE.md, AGENTS.md, settings, BMAD manifest + team customizations, the 5 planning artifacts, the list of 49 installed skills.",
    "06-examples": "Before/after screenshots of four recent changes (README section 7).",
}
lines = ["# Package manifest", "", f"Generated {datetime.date.today()} by `qa_package.py`.", ""]
for top in sorted({p.split("/")[0] for p in all_files if "/" in p}):
    lines += [f"## {top}/", "", desc.get(top, ""), "", "| File | Bytes |", "|---|---|"]
    for p in sorted(x for x in all_files if x.startswith(top + "/")):
        lines.append(f"| `{p}` | {os.path.getsize(os.path.join(HERE, p)):,} |")
    lines.append("")
lines += ["## Root", "", "| File | Purpose |", "|---|---|", "| `README.md` | The write-up |", "| `MANIFEST.md` | This list |",
          "| `QA-REPORT.md` | Result of the package checks |", "| `qa_package.py` | The checks themselves |",
          "| `redact.py` | Redaction applied to the copied files |", "| `qa_count_tests.mjs` | Counts QA tests by loading the real test tables |"]
open(os.path.join(HERE, "MANIFEST.md"), "w", encoding="utf-8").write("\n".join(lines) + "\n")

# ---- 6. QA-REPORT.md
passed = sum(1 for _, ok, _ in results if ok)
rep = ["# QA report", "", f"{datetime.datetime.now():%Y-%m-%d %H:%M} - **{passed}/{len(results)} checks passed**", "",
       "| Result | Check | Detail |", "|---|---|---|"]
for name, ok, detail in results:
    rep.append(f"| {'PASS' if ok else 'FAIL'} | {name} | {detail} |")
open(os.path.join(HERE, "QA-REPORT.md"), "w", encoding="utf-8").write("\n".join(rep) + "\n")
print(f"{passed}/{len(results)} passed")
for name, ok, detail in results:
    if not ok:
        print("FAIL", name, detail)

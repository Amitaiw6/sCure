# sCureBox QA

Four layers, from fastest to slowest. All of them run on this Windows PC with the user-local .NET SDK
(`%LOCALAPPDATA%\Microsoft\dotnet\dotnet.exe`) and Node ≥ 18.

| Layer | What | How |
|---|---|---|
| 1. Unit tests | Domain, Hardware, Application (fake clock, fake board) | `dotnet test tests/SCureBox.Domain.Tests` (also `Hardware.Tests`, `Application.Tests`) |
| 2. Integration tests | Every `/api` route in simulation via `WebApplicationFactory` | `dotnet test tests/SCureBox.Api.Tests` |
| 3. Headless QA | The QA table (`qa-tests.js`) against a **live** server | `node qa/run-qa.mjs --api http://localhost:3001` |
| 4. Browser QA tool | The same table, interactive, exportable report | open `qa/qa-tool.html` |

`qa/run-all.ps1` chains 1 → 2 → 3: build, all four test projects, start the API in simulation on port 3111
with a throw-away data dir, run the headless QA, stop the server, print a PASS/FAIL summary (exit 1 on failure).

```powershell
powershell -ExecutionPolicy Bypass -File qa\run-all.ps1            # everything
powershell -ExecutionPolicy Bypass -File qa\run-all.ps1 -SkipTests # build + live QA only
```

## Headless runner

```
node qa/run-qa.mjs [--api http://host:3001] [--category <id>] [--json out.json] [--quiet]
```

Categories: `connectivity state cure chamber hardware diagnostics data system network nfc dev recipe static performance`.
Exit code 1 when any test **fails**; `warn` and `skip` do not fail the run. `--json` writes the per-test results.

To run it against the machine:

```
node qa/run-qa.mjs --api http://<internal-ip>:3001
```

## Browser tool

Open `qa/qa-tool.html` straight from the file system (it loads `qa-tests.js` next to it — keep the two files
together). Type the machine's address in the **API URL** box (`http://<pi-ip>:3001`) and press **Connect**;
the header shows the server version and the hardware source (`io_controller` or `simulation`).
**Run All**, per-category **Run**, or a single row's **Run**. Tiles count pass / fail / warn / skip;
**Export report** opens the text report in a textarea (copy to clipboard, or download when the browser allows it).

The API has CORS wide open, so the page works from `file://` or from any origin.

## What the table covers

Connectivity, the full `/api/state` key set, every cure operation including the 7001 / 7002 / 7003 rejections
and the always-ok `stop`, manual chamber heating, fans / override / damper / door (with the 5 s simulated
re-close) / door-abort ack / UV / BOFA / RGB, fan-test and LED-test shapes, materials / print-history /
cure-run round trips with the id `qa-test-run`, phase-timing validation, system version / date-time
validation / USB exports (9081 without a drive counts as pass) / update manifest, network status and
diagnostics (unknown tool 9080, shell-injection string rejected 9085), NFC (9052 without a reader),
developer-mode LED calibration + reset + LED power validation, PicoLog / HDT status, the server-side
recipe runner (start preset ST45, second start 6015, pause / resume / abort), the static UI + `/config/*.json`,
and latency (state < 200 ms pass / < 500 ms warn).

Never executed by QA (rows are marked *skip*): `system/reboot`, `system/shutdown`, `network/static`.
`system/datetime` with a valid value only runs against a Windows host (on the machine it would set the clock).

## On the machine

Tests that change outputs leave the machine idle again (every cure sequence ends with `cure/stop`, the recipe
run is aborted, fans go back to 0). Run with the door closed and nothing in the chamber; the LED test lights
the panels for 2 s. The door test opens the door magnet — on the real machine close the door again afterwards.

## Record shape

```js
{ id, name, desc, endpoint, method, body, expect | expectArray | check, code?, url?, timeout? }
```

`expect: 'ok'` → `ok === true`; `expect: '<field>'` → the field exists; `expectArray` → the body is an array;
`check: '<name>'` → `SCURE_QA.CHECKS[name](ctx, test, response)` returns `{status, msg}`; `url` fetches a static
asset (no `/api` prefix). Both runners call `SCURE_QA.runTest(test, ctx)` from `qa-tests.js`.

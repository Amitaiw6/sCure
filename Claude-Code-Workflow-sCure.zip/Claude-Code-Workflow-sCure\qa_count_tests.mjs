// Count QA tests by loading the real test tables (no regex guessing).
import fs from 'fs';
import vm from 'vm';

const [csPath, saPath] = process.argv.slice(2);

// sCureBox-CS: plain script that sets globalThis.SCURE_QA
const ctx = { globalThis: {}, console };
ctx.globalThis = ctx;
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(csPath, 'utf8'), ctx);
const cats = ctx.SCURE_QA.CATEGORIES;
const cs = cats.reduce((n, c) => n + c.tests.length, 0);

// sCure-A: the TEST_CATEGORIES literal inside the HTML
const html = fs.readFileSync(saPath, 'utf8');
const start = html.indexOf('const TEST_CATEGORIES = [');
let i = html.indexOf('[', start), depth = 0, end = -1;
for (let j = i; j < html.length; j++) {
  const ch = html[j];
  if (ch === '"' || ch === "'" || ch === '`') { const q = ch; j++; while (html[j] !== q) { if (html[j] === '\\') j++; j++; } continue; }
  if (ch === '/' && html[j + 1] === '/') { while (html[j] !== '\n') j++; continue; }
  if (ch === '[' || ch === '{' || ch === '(') depth++;
  if (ch === ']' || ch === '}' || ch === ')') { depth--; if (depth === 0) { end = j; break; } }
}
const saCats = vm.runInNewContext('(' + html.slice(i, end + 1) + ')');
const sa = saCats.reduce((n, c) => n + c.tests.length, 0);
console.log(JSON.stringify({ cs: { categories: cats.length, tests: cs }, sa: { categories: saCats.length, tests: sa } }));

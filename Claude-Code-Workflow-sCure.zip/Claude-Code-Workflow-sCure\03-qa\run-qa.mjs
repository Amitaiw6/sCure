#!/usr/bin/env node
/*
 * Headless sCureBox QA runner — runs the same test table as qa-tool.html against a live server.
 * Node >= 18, no dependencies.
 *
 *   node qa/run-qa.mjs [--api http://host:3001] [--category <id>] [--json out.json] [--quiet]
 *
 * Exit code 1 when any test fails (warn / skip do not fail the run).
 */
import { createRequire } from 'node:module';
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const require = createRequire(import.meta.url);
require(join(dirname(fileURLToPath(import.meta.url)), 'qa-tests.js'));   // defines globalThis.SCURE_QA
const { CATEGORIES, runTest } = globalThis.SCURE_QA;

function parseArgs(argv) {
  const opts = { api: 'http://localhost:3001', category: null, json: null, quiet: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--api') opts.api = argv[++i];
    else if (a === '--category') opts.category = argv[++i];
    else if (a === '--json') opts.json = argv[++i];
    else if (a === '--quiet') opts.quiet = true;
    else if (a === '--help' || a === '-h') { console.log('usage: node run-qa.mjs [--api URL] [--category ID] [--json FILE] [--quiet]'); process.exit(0); }
    else { console.error('unknown argument: ' + a); process.exit(2); }
  }
  opts.api = opts.api.replace(/\/+$/, '');
  return opts;
}

const ICON = { pass: 'PASS', fail: 'FAIL', warn: 'WARN', skip: 'SKIP' };
const COLOR = process.stdout.isTTY ? { pass: '\x1b[32m', fail: '\x1b[31m', warn: '\x1b[33m', skip: '\x1b[90m', off: '\x1b[0m', dim: '\x1b[2m' } : { pass: '', fail: '', warn: '', skip: '', off: '', dim: '' };

async function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (typeof fetch !== 'function') { console.error('Node 18 or newer is required (global fetch)'); process.exit(2); }
  const ctx = { apiUrl: opts.api, fetch: (...a) => fetch(...a), timeoutMs: 10000 };
  const categories = opts.category ? CATEGORIES.filter((c) => c.id === opts.category) : CATEGORIES;
  if (!categories.length) { console.error(`unknown category '${opts.category}'; known: ${CATEGORIES.map((c) => c.id).join(', ')}`); process.exit(2); }

  // connectivity gate
  try {
    const res = await fetch(opts.api + '/api/state', { signal: AbortSignal.timeout(5000) });
    const s = await res.json();
    console.log(`sCureBox QA — ${opts.api} (hwSource=${s.hwSource}, chamber ${s.chamberTemp}°C)`);
  } catch (e) {
    console.error(`API unreachable at ${opts.api}: ${e.message}`);
    process.exit(1);
  }

  const started = Date.now();
  const results = [];
  const counts = { pass: 0, fail: 0, warn: 0, skip: 0 };
  const nameWidth = Math.min(48, Math.max(...categories.flatMap((c) => c.tests.map((t) => t.name.length))));

  for (const cat of categories) {
    console.log(`\n${cat.name}`);
    console.log('-'.repeat(nameWidth + 16));
    for (const test of cat.tests) {
      const r = await runTest(test, ctx);
      counts[r.status] = (counts[r.status] || 0) + 1;
      results.push({ category: cat.id, id: test.id, name: test.name, status: r.status, msg: r.msg, ms: r.ms });
      if (!opts.quiet || r.status === 'fail') {
        const c = COLOR[r.status] || '';
        console.log(`  ${c}${ICON[r.status] || r.status.toUpperCase()}${COLOR.off}  ${test.name.padEnd(nameWidth)}  ${COLOR.dim}${String(r.ms).padStart(5)} ms${COLOR.off}  ${r.msg || ''}`);
      }
      await new Promise((res) => setTimeout(res, 50));
    }
  }

  const seconds = ((Date.now() - started) / 1000).toFixed(1);
  const total = results.length;
  console.log('\n' + '='.repeat(nameWidth + 16));
  console.log(`${counts.fail ? COLOR.fail + 'FAIL' : COLOR.pass + 'PASS'}${COLOR.off}  ${counts.pass} passed, ${counts.fail} failed, ${counts.warn} warnings, ${counts.skip} skipped of ${total} in ${seconds} s`);

  if (opts.json) {
    writeFileSync(opts.json, JSON.stringify({ api: opts.api, date: new Date().toISOString(), seconds: Number(seconds), summary: counts, results }, null, 2));
    console.log(`report written to ${opts.json}`);
  }
  process.exit(counts.fail ? 1 : 0);
}

main().catch((e) => { console.error(e); process.exit(2); });

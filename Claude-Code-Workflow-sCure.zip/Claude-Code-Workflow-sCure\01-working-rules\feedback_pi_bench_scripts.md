---
name: pi-bench-scripts
description: "How to run/stop bench test scripts on the Pi safely (nohup + done-flag, pkill bracket trick, always restore config), and the 2026-09 fan/heater reference numbers"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f5a99b88-1747-4a5a-82ca-817e02e851be
  modified: 2026-09-10T02:56:20.278Z
---

Bench tests on testingcm5 (heat/fan experiments) work best as a self-contained
python script on the Pi launched with `nohup ... &` that logs a CSV, writes a
`~/<name>.done` flag at the end, and restores whatever it changed (e.g.
components.json heater.fan_pwm) in a `finally:`; poll the flag from a local
background `until ssh ... test -f` loop.

**Why:** an interactive ssh that runs the test dies with the connection; and
`pkill -f heat_test.py` over ssh kills the ssh session itself (the pattern
matches the remote `bash -c` command line) so the script's cleanup never runs
(happened 2026-09-09: fan_pwm stayed at 50 %, heating kept going).

**How to apply:** stop scripts with a pattern that cannot match itself, e.g.
`pkill -f "heat_test_fan5[0].py"`; after any stop, re-check `/api/state`
(isHeating, fans) and the config; and remember /tmp is wiped on reboot, so
put backups under ~ (e.g. `~/sCure-A/.rollback-<ts>/`).

Reference numbers measured 2026-09-09 (idle machine, steady state):
heater fan 3,530 RPM @100 % (2,925 @80, 1,870 @50, 915 @30); chamber cooling
fan 4,790 @100 (2,690 @60, 1,235 @30); LED fans ~3,560 @100 (only FAN_LEFT
has an API tach readout). Heating 30->35 C with the PI (kp 0.22, ki 0.00015)
overshoots to ~39.4 C regardless of fan duty (80 % vs 50 %) - controller
issue, not airflow. See [[test-machine-access]].

**Check the machine is idle right before every install/restart (added 2026-09-16):** on the sCureBox CM5, a 1.0.13 install.sh restart aborted a program the operator had started ~90 s earlier ('test', heating step) - the idle check had been done minutes before. Query /api/state (recipe, isHeating, isCooling, uvOn) immediately before running install.sh or restarting the service, and stop if anything runs. Also: stopping scurebox-ui hangs ~90 s until SIGKILL on every install (cause unknown as of 2026-09-16), the screen freezes meanwhile.

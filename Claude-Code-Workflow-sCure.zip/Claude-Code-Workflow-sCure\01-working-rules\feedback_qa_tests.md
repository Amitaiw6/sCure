---
name: Always add QA tests for new features
description: Every new feature must include corresponding QA tests in qa-tool/index.html
type: feedback
originSessionId: 089eff01-a649-473c-966a-5a0de9cb9cdc
---
Every new feature built must include QA tests added to `qa-tool/index.html`.

**Why:** User wants the QA tool to stay in sync with all features so testing coverage is complete and nothing is missed.

**How to apply:** After implementing any new feature (API endpoint, hardware function, UI feature, config change):
1. Add test entries to the appropriate category in `TEST_CATEGORIES` in `qa-tool/index.html`
2. If needed, add a new category
3. If the test needs special validation logic, add a case in `runCheck()`
4. Cover: API endpoints, expected responses, error cases, and performance

---
name: bash-tool-halves-backslashes
description: "On this Windows setup the Bash tool strips one level of backslashes from the command text — literal backslashes (e.g. JS \\' escapes) never reach sed/python heredocs"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 7f6a1b2e-7edd-41c5-92e0-177d850e8724
  modified: 2026-08-31T02:59:38.065Z
---

The Bash tool on this machine (Git Bash on Windows 11) halves backslashes in the command it sends, even inside quoted heredocs: `"model\\'s"` arrives in Python as `"model\'s"` (= `model's`), and `sed "s/x/\\\\'/"` writes a plain `'`. Edits that must insert a backslash silently become no-ops, and read-back checks written in the same command give false positives.

**Why:** Cost me several rounds on 2026-08-31 fixing an unescaped apostrophe in qa-tool/index.html (`model's` inside a single-quoted JS string, which broke the whole QA page script).

**How to apply:** When an edit needs a literal backslash, build it with `chr(92)` in Python, or use the Write/Edit tools instead of Bash. Verify with `od -c` / `repr()` in a *separate* command. Also: run `node --check` on the extracted `<script>` of qa-tool/index.html after editing it — a single bad quote kills every QA test. See [[qa-tests-for-features]].

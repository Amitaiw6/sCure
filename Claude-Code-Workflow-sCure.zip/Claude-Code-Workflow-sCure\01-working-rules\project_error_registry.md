---
name: project-error-registry
description: Central Error Registry for sCure — single source, hierarchical numeric codes, SRS §9, diagram "Err <code>" labels
metadata:
  type: project
---

sCure has a single central **Error Registry**: `public/config/errors.json` (consumed by `src/context/AlertsContext.tsx`; bundled copy is the offline fallback). No hard-coded error strings — code raises an error by its numeric `code`; the displayed text is resolved from the registry, so editing `message` changes the UI with no code change.

- **Record shape:** `code` (number), `key` (UPPER_SNAKE), `message` (CS-editable), `severity` (critical|warning), `category`, `layer` (daemon|backend|ui) + CS-editable `description`/`troubleshooting`/`supportUrl` (+ `legacyCode` for the hardware alerts). `_meta.ranges` mirrors the range table.
- **Numbering by SRS SECTION (v3, the user's explicit rule):** the **first digit = the SRS section/screen the error is documented in**. **3xxx §3 Setup · 4xxx §4 Setup Name · 5xxx §5 Connect Org · 6xxx §6 Home** (builder, CSV import, view-all, start-cure) **· 7xxx §7 Cure Process · 8xxx §8 History (reserved) · 9xxx §9 Error Management** (device/hardware alerts shown on the Alerts screen [9001–9049 critical, 9050–9079 warnings] + cross-cutting system/backend faults [9080–9099]). STRICT: every diagram error node's code must start with its own section's digit — NO cross-section reuse (e.g. setup's "no internet" is §3 `3003 SETUP_NO_INTERNET`, NOT the general `9055 NETWORK_DISCONNECTED`). The originating subsystem lives in the `layer` field, not the number. Code still carried UNCHANGED across layers.
- **Migrations:** v1→v2 old `E-1xx`/`W-3xx` → numeric; v2→v3 first digit re-based from subsystem to SRS section (subsystem moved into `layer`). `legacyCode` (E-/W-) kept for the hardware alerts only.
- **SRS:** documented in `docs/sCure_SRS.html` **§9 (Error Management & Registry)** — principles, record structure, range table, propagation, full catalog, diagram-traceability table. Open item **OI-18**: wire `app.py` / `hardware-api.ts` to return `{ok:false, code}` instead of free-text `message`.
- **Diagrams:** every failure node carries its code as a red **`Err <code>`** label (or `[Err NNNN]` prefix on box-only nodes). Keep registry ↔ SRS §9.5 ↔ diagram labels in sync — adding/moving an error means updating all three. Related: [[project-srs-diagrams]], [[feedback-srs-authoring]].

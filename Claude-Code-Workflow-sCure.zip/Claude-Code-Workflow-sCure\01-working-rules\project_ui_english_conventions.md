---
name: ui-english-conventions
description: "Customer-facing English conventions fixed in July 2026 — product name \"sCure\", terminology standards"
metadata: 
  node_type: memory
  type: project
  originSessionId: bd02f950-ad86-4084-be22-1a597c2daeca
  modified: 2026-08-03T14:58:41.202Z
---

UI English conventions standardized (2026-07-23), keep new strings consistent:
- Product name is **sCure** everywhere (not "S-Cure"/"S-CURE").
- The list entity is a **Program** (renamed from "Material", 2026-08-03: "Program List", "New/Edit Program", "Save/Update Program", "Program Name:"). "Material" remains ONLY where it means the physical print resin (e.g. print-history filter "All Materials", report's materialName). Organization action verb is **Link**.
- Display label is **Bleaching** — but `Bleacher` stays as the literal CSV/process data value (VALID_PROCESSES); map it only for display.
- American spelling (recognized, pressurized, energized, Program), "USB drive" (not stick), "Ethernet" capitalized, "S/N", "LED On Time" (config field is still `leadOnTimeHours`), no space before "..." ellipses, space before units ("45 min", "405 nm").
- Real limits shown to users: heating 30–80°C, cooling 20–75/80°C, UV 10–100%, Bleaching up to 720 min (server/app.py is the source of truth).
- ALL-CAPS buttons (REBOOT, EXECUTE, DHCP…) intentionally left as design style.

**Why:** Customer-facing GUI had Hebrew-influenced English and three product-name spellings.
**How to apply:** New UI strings follow these conventions; see [[feedback-ui-consistency]].

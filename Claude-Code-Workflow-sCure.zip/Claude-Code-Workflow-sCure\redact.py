"""Redaction applied to every text file copied into this package (and to the source when qa_package.py compares a copy
with its original): internal machine addresses, the NetBird host, the SSH key file name and the developer-mode PIN."""
import re

RULES = [
    (re.compile(r"\b(?:192\.168|10\.0|100\.10[0-9]|172\.(?:1[6-9]|2\d|3[01]))\.\d{1,3}\.\d{1,3}\b"), "<internal-ip>"),
    (re.compile(r"[A-Za-z0-9.-]*netbird\.cloud"), "<netbird-host>"),
    (re.compile(r"scure_pi\b"), "<ssh-key>"),
    (re.compile(r"(PASSWORD\s*=\s*)'[^']*'"), r"\1'<redacted>'"),
    (re.compile(r"\b8176\b"), "<dev-pin>"),
]

def redact(text: str) -> str:
    for rx, repl in RULES:
        text = rx.sub(repl, text)
    return text

if __name__ == "__main__":
    import os, sys
    root = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.abspath(__file__))
    for r, _, files in os.walk(root):
        for f in files:
            p = os.path.join(r, f)
            if f.endswith((".png", ".py", ".mjs")) or os.path.relpath(p, root) in ("MANIFEST.md", "QA-REPORT.md", "README.md"):
                continue
            s = open(p, encoding="utf-8", errors="surrogateescape").read()
            t = redact(s)
            if t != s:
                open(p, "w", encoding="utf-8", errors="surrogateescape", newline="").write(t)
                print("redacted", os.path.relpath(p, root))

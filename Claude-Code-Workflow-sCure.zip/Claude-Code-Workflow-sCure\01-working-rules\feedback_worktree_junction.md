---
name: worktree-junction-node-modules
description: "Never junction/symlink node_modules into a git worktree and then `git worktree remove --force` - on Windows it deletes the real node_modules contents"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9c39147e-10c2-4f32-85a8-dbb9744f95b3
  modified: 2026-09-16T19:37:31.467Z
---

On 2026-09-16 I built the sCure-A React UI in a temp worktree (`git worktree add --detach`) with `mklink /J node_modules` pointing at the main checkout's node_modules. `git worktree remove --force` followed the junction and emptied `sCure-A/node_modules`; restored with `npm ci` (605 packages, lockfile unchanged).

**Why:** git on Windows recurses into directory junctions when deleting a worktree.

**How to apply:** before removing such a worktree, delete the junction itself first (`cmd /c rmdir <wt>\node_modules`, which removes only the link), or run `npm ci` inside the worktree instead of linking. Building the bundled UI from a clean commit (so other sessions' uncommitted sCure-A work does not leak into sCureBox-CS ui/dist) is still the right approach. Related: [[scurebox-cs-port]], [[parallel-sessions]].

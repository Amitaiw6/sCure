---
name: version-bump-every-change
description: Every code change must bump the sCure version (VERSION file + versions.json entry)
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c59c6f7c-0f4f-4307-b08f-9539995dc02e
  modified: 2026-08-06T04:11:44.644Z
---

The user requires (2026-08-06): EVERY code-level change I make must bump the app version.

**Why:** Versioning was reset to 0.1.0 on 2026-08-06 with a single source of truth. The user wants the Settings > Versions modal to reflect every change, so the machine's software state is always identifiable.

**How to apply:**
- Bump `VERSION` at the repo root: patch (0.1.0 → 0.1.1) for fixes/small tweaks, minor (0.1.x → 0.2.0) for new features. Group all edits of one task into ONE bump.
- Add a matching entry (version, date, notes[]) at the TOP of `public/config/versions.json` — notes in plain English, what changed from the user's perspective.
- Deploy both together with the code (VERSION to Pi repo root; versions.json ships inside the UI build's config/).
- The version surfaces via `/api/system/version` (reads VERSION) and the Settings > Versions modal (reads /config/versions.json). See [[project-versioning]].
